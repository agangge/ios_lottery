//
//  JCHeader.h
//  JiCaiLottery
//
//  Created by 风外杏林香 on 2017/4/1.
//  Copyright © 2017年 风外杏林香. All rights reserved.
//

#ifndef prefix_h
#define prefix_h

#ifdef DEBUG

#import "SDAutoLayout.h"
#import "JCRequestNetWork.h"
#import "JSONKit.h"
#import "MJRefresh.h"
#import "MBProgressHUD.h"
#import "JCAllUrl.h"
//用户名、密码、账号、service
#define USER_NAME @"username"
#define PASS_WORD @"password"
#define USER_SESSION @"userSession"
#define USER_SERVICE @"com.PhoneNumber.LogIn"

#define allRedColor [UIColor colorWithRed:230/255.0 green:47/255.0 blue:23/255.0 alpha:1]
#define ColorRGB(r,g,b,a) [UIColor colorWithRed:r/255.0 green:g/255.0 blue:b/255.0 alpha:a]

#define ScreenHeight [UIScreen mainScreen].bounds.size.height
#define ScreenWidth  [UIScreen mainScreen].bounds.size.width
//#define MAINJIYUNURL  @"http://client.jicai500.com/"
#define MAINJIYUNURL @"http://client.ydyweipan.com/"


#define APPVERSION    @"1"
#define REQUESTTYPE   @"1" //请求类型 iOS默认为1，
#define VERSION  [[[NSBundle mainBundle] infoDictionary]objectForKey:(NSString *)kCFBundleVersionKey]


#define JCString [NSString stringWithFormat:@"%s", __FILE__].lastPathComponent
#define JCLog(...) printf("%s %d行: %s\n\n",[JCString UTF8String], __LINE__, [[NSString stringWithFormat:__VA_ARGS__] UTF8String]);
#else
#define JCLog(...)
#endif


#endif /* JCHeader */

