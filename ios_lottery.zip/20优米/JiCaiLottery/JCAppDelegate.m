//
//  JCAppDelegate.m
//  JiCaiLottery
//
//  Created by 风外杏林香 on 2017/3/18.
//  Copyright © 2017年 风外杏林香. All rights reserved.
//

#import "JCAppDelegate.h"
#import "JCTabBarViewController.h"
#import "JCLoginViewController.h"
#import <IQKeyboardManager.h>
#import "AFNetworking.h"
#import<CoreTelephony/CTCellularData.h>
#import "JXTAlertManagerHeader.h"
#import "JCRequestNetWork.h"
#import "JCHeader.h"

@interface JCAppDelegate ()

@end

@implementation JCAppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
   
   
    if (__IPHONE_10_0) { //1.获取网络权限 根据权限进行人机交互
        [self networkStatus:application didFinishLaunchingWithOptions:launchOptions];
    }else {//2.2已经开启网络权限 监听网络状态
        
        [self addReachabilityManager:application didFinishLaunchingWithOptions:launchOptions];
    }
    
    self.window = [[UIWindow alloc]init];
    self.window.frame = [UIScreen mainScreen].bounds;
    self.window.backgroundColor = [UIColor whiteColor];
    
    [self.window makeKeyAndVisible];
    
    // 启动页延时
    [NSThread sleepForTimeInterval:1.5f];
    
    [self customLaunchImageView];
    
    JCTabBarViewController *tabBarVC = [[JCTabBarViewController alloc]init];
    [UITabBar appearance].translucent = NO;
   self.window.rootViewController = tabBarVC;
    [IQKeyboardManager sharedManager].enableAutoToolbar = NO;
    [IQKeyboardManager sharedManager].shouldResignOnTouchOutside = YES;


    return YES;
}
//启动图显示版本号
- (void)customLaunchImageView
{
    UIImageView *launchImageView = [[UIImageView alloc] initWithFrame:self.window.bounds];
    launchImageView.image = [self getLaunchImage];
//     JCLog(@"lauchImage = %@",[self getLaunchImage]);
    [self.window addSubview:launchImageView];
    [self.window bringSubviewToFront:launchImageView];
    
    UILabel *vesionLabel = [[UILabel alloc] initWithFrame:CGRectMake(self.window.bounds.size.width/2-50, self.window.bounds.size.height-30, 100, 30)];
//    vesionLabel.backgroundColor = [UIColor redColor];
    //获取当前设备中应用的版本号
    NSDictionary *infoDic = [[NSBundle mainBundle] infoDictionary];
//    JCLog(@"infoDic = %@",infoDic);
    NSString *currentVersion = [infoDic objectForKey:@"CFBundleShortVersionString"];
    vesionLabel.text = [NSString stringWithFormat:@"V %@",currentVersion];
    vesionLabel.textAlignment = NSTextAlignmentCenter;
    vesionLabel.textColor = [UIColor redColor];
    [launchImageView addSubview:vesionLabel];
    
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.8 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [UIView animateWithDuration:1.2 animations:^{
            launchImageView.alpha = 0.0;
            launchImageView.transform = CGAffineTransformMakeScale(1.2, 1.2);
        } completion:^(BOOL finished) {
            [launchImageView removeFromSuperview];
        }];
    });
}

- (UIImage *)getLaunchImage
{
    UIImage *lauchImage = nil;
    NSString *viewOrientation = nil;
    CGSize viewSize = [UIScreen mainScreen].bounds.size;
    UIInterfaceOrientation orientation = [[UIApplication sharedApplication] statusBarOrientation];
    
    if (orientation == UIInterfaceOrientationLandscapeLeft || orientation == UIInterfaceOrientationLandscapeRight) {
        
        viewOrientation = @"Landscape";
        
    } else {
        
        viewOrientation = @"Portrait";
    }
    
    NSArray *imagesDictionary = [[[NSBundle mainBundle] infoDictionary] valueForKey:@"UILaunchImages"];
//     JCLog(@"imagesDictionary = %@",imagesDictionary);
    for (NSDictionary *dict in imagesDictionary) {
        
        CGSize imageSize = CGSizeFromString(dict[@"UILaunchImageSize"]);
        if (CGSizeEqualToSize(imageSize, viewSize) && [viewOrientation isEqualToString:dict[@"UILaunchImageOrientation"]]) {
            
            lauchImage = [UIImage imageNamed:dict[@"UILaunchImageName"]];
        }
    }
    return lauchImage;
    
}

#pragma mark --获取网络权限状态
- (void)networkStatus:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    //2.根据权限执行相应的交互
    CTCellularData *cellularData = [[CTCellularData alloc] init];
    
    /*
     此函数会在网络权限改变时再次调用
     */
    cellularData.cellularDataRestrictionDidUpdateNotifier = ^(CTCellularDataRestrictedState state) {
        switch (state) {
            case kCTCellularDataRestricted:
                
                NSLog(@"Restricted");
                //2.1权限关闭的情况下 再次请求网络数据会弹出设置网络提示
                [self getInfo_application:application didFinishLaunchingWithOptions:launchOptions];
                break;
            case kCTCellularDataNotRestricted:
                
                NSLog(@"NotRestricted");
                //2.2已经开启网络权限 监听网络状态
                [self addReachabilityManager:application didFinishLaunchingWithOptions:launchOptions];
                //                [self getInfo_application:application didFinishLaunchingWithOptions:launchOptions];
                break;
            case kCTCellularDataRestrictedStateUnknown:
                
                NSLog(@"Unknown");
                //2.3未知情况 （还没有遇到推测是有网络但是连接不正常的情况下）
                [self getInfo_application:application didFinishLaunchingWithOptions:launchOptions];
                break;
                
            default:
                break;
        }
    };
}

#pragma mark -- 实时检查当前网络状态

- (void)addReachabilityManager:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    
    AFNetworkReachabilityManager *afNetworkReachabilityManager = [AFNetworkReachabilityManager sharedManager];
 
    [afNetworkReachabilityManager setReachabilityStatusChangeBlock:^(AFNetworkReachabilityStatus status) {
        switch (status) {
            case AFNetworkReachabilityStatusNotReachable:{
                NSLog(@"网络不通：%@",@(status) );
                [self getInfo_application:application didFinishLaunchingWithOptions:launchOptions];
                break;
            }
            case AFNetworkReachabilityStatusReachableViaWiFi:{
                NSLog(@"网络通过WIFI连接：%@",@(status));

                [self getInfo_application:application didFinishLaunchingWithOptions:launchOptions];
   
                
                break;
            }
            case AFNetworkReachabilityStatusReachableViaWWAN:{
                NSLog(@"网络通过蜂窝数据连接：%@",@(status) );

                [self getInfo_application:application didFinishLaunchingWithOptions:launchOptions];
          
                break;
            }
            default:
                break;
        }
    }];
    
    [afNetworkReachabilityManager startMonitoring];  //开启网络监视器；
}

- (void)getInfo_application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {

    
    [self configMainUrl];
   
}

#pragma mark -- 配置动态域名
-(void)configMainUrl {
    NSString *urlString = [NSString stringWithFormat:@"http://client.jicai500.com/domain.do?domain=AImi"];
    [JCRequestNetWork requestWithURLString:urlString parameters:nil type:(HttpRequestTypeGet) success:^(id responseObject) {
        NSMutableDictionary *dict = [NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingMutableLeaves error:nil];
        JCLog(@"dict -- %@", dict);
        if ([[dict objectForKey:@"success"] intValue] == 1) {
            [[NSUserDefaults standardUserDefaults] setObject:[dict objectForKey:@"message"] forKey:@"mainjiyunurl"];
            [[NSNotificationCenter defaultCenter] postNotificationName:@"reloadData" object:nil];
            [[NSNotificationCenter defaultCenter] postNotificationName:@"homeRefreshUrl" object:nil];
        } else {
            [[NSUserDefaults standardUserDefaults] setObject:@"http://client.zucasio.com/" forKey:@"mainjiyunurl"];
            [[NSNotificationCenter defaultCenter] postNotificationName:@"reloadData" object:nil];

        }
    } failure:^(NSError *error) {
        JCLog(@"error -- %@", error);
        [[NSNotificationCenter defaultCenter] postNotificationName:@"reloadData" object:nil];
    } showView:nil];
}

- (void)applicationWillResignActive:(UIApplication *)application {
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and invalidate graphics rendering callbacks. Games should use this method to pause the game.
}


- (void)applicationDidEnterBackground:(UIApplication *)application {
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}


- (void)applicationWillEnterForeground:(UIApplication *)application {
    // Called as part of the transition from the background to the active state; here you can undo many of the changes made on entering the background.
}


- (void)applicationDidBecomeActive:(UIApplication *)application {
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}


- (void)applicationWillTerminate:(UIApplication *)application {
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}

@end
