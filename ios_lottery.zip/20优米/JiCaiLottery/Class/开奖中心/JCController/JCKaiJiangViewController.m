//
//  JCKaiJiangViewController.m
//  JiCaiLottery
//
//  Created by 风外杏林香 on 2017/3/18.
//  Copyright © 2017年 风外杏林香. All rights reserved.
//

#import "JCKaiJiangViewController.h"
#import "JCKaiJiangFirstModel.h"
#import "JCHeader.h"
#import "JCKaiJiangTableViewCell.h"
#import "JCKJSecondViewController.h"
#import "JCJJKJViewController.h"
#import "JCKJTraditionalFootBallViewController.h"
static const CGFloat ballLabelWidth = 23;
@interface JCKaiJiangViewController ()<UITableViewDelegate, UITableViewDataSource>

@property (nonatomic, strong)UITableView *dataTableView;
@property (nonatomic, strong)NSMutableArray *allDataArray;
@property (nonatomic, strong)NSMutableArray *allThingArray;
@property (nonatomic, strong)NSMutableArray *allLottreyIdArray;

@end

@implementation JCKaiJiangViewController



- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.view.backgroundColor = allWhiteColor;
    self.allDataArray = [NSMutableArray array];
    self.allThingArray = [NSMutableArray array];
    self.allLottreyIdArray = [NSMutableArray array];
    __block JCKaiJiangViewController *blockSelf = self;
    //=========下拉刷新
    self.dataTableView.mj_header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
        [blockSelf requestURL];
    }];
    self.dataTableView.mj_header.automaticallyChangeAlpha=YES;
    [self.dataTableView.mj_header beginRefreshing];
    
    [self.view addSubview:self.dataTableView];

    [self initlotteryNameAndImg];
    
}

-(void)initlotteryNameAndImg
{
    NSDictionary *dic0=[[NSDictionary alloc]initWithObjectsAndKeys:@"logo_pl3",@"imgName",@"排列3",@"lotteryName",@"10024",@"lotteryID", nil];
    [self.allThingArray addObject:dic0];
    NSDictionary *dic13=[[NSDictionary alloc]initWithObjectsAndKeys:@"logo_pl5",@"imgName",@"排列5",@"lotteryName",@"100241",@"lotteryID", nil];
    [self.allThingArray addObject:dic13];
    
    NSDictionary *dic1=[[NSDictionary alloc]initWithObjectsAndKeys:@"体彩6+1",@"imgName",@"体彩6+1",@"lotteryName",@"10027",@"lotteryID", nil];
    [self.allThingArray addObject:dic1];
    
    NSDictionary *dic2=[[NSDictionary alloc]initWithObjectsAndKeys:@"logo_qxc",@"imgName",@"七星彩",@"lotteryName",@"10030",@"lotteryID", nil];
    [self.allThingArray addObject:dic2];
    
    NSDictionary *dic3=[[NSDictionary alloc]initWithObjectsAndKeys:@"logo_fc3D",@"imgName",@"福彩3D",@"lotteryName",@"10025",@"lotteryID", nil];
    [self.allThingArray addObject:dic3];
    
    NSDictionary *dic4=[[NSDictionary alloc]initWithObjectsAndKeys:@"logo_11ydj",@"imgName",@"十一运夺金",@"lotteryName",@"10046",@"lotteryID", nil];
    [self.allThingArray addObject:dic4];
    
    NSDictionary *dic5=[[NSDictionary alloc]initWithObjectsAndKeys:@"logo_11x5",@"imgName",@"江西11选5",@"lotteryName",@"10060",@"lotteryID", nil];
    [self.allThingArray addObject:dic5];
    
    NSDictionary *dic6=[[NSDictionary alloc]initWithObjectsAndKeys:@"logo_ssq",@"imgName",@"双色球",@"lotteryName",@"10032",@"lotteryID", nil];
    [self.allThingArray addObject:dic6];
    
    NSDictionary *dic7=[[NSDictionary alloc]initWithObjectsAndKeys:@"20选5",@"imgName",@"20选5",@"lotteryName",@"10028",@"lotteryID", nil];
    [self.allThingArray addObject:dic7];
    
    NSDictionary *dic8=[[NSDictionary alloc]initWithObjectsAndKeys:@"安徽11选5",@"imgName",@"15选5",@"lotteryName",@"10035",@"lotteryID", nil];
    [self.allThingArray addObject:dic8];
    
    NSDictionary *dic9=[[NSDictionary alloc]initWithObjectsAndKeys:@"logo_qlc",@"imgName",@"七乐彩",@"lotteryName",@"10033",@"lotteryID", nil];
    [self.allThingArray addObject:dic9];
    
    NSDictionary *dic10=[[NSDictionary alloc]initWithObjectsAndKeys:@"logo_dlt",@"imgName",@"大乐透",@"lotteryName",@"10026",@"lotteryID", nil];
    [self.allThingArray addObject:dic10];
    
    NSDictionary *dic11=[[NSDictionary alloc]initWithObjectsAndKeys:@"logo_ssc",@"imgName",@"重庆时时彩",@"lotteryName",@"10038",@"lotteryID", nil];
    [self.allThingArray addObject:dic11];
    
    NSDictionary *dic12=[[NSDictionary alloc]initWithObjectsAndKeys:@"logo_jczq_10059",@"imgName",@"竞彩足球",@"lotteryName",@"10059",@"lotteryID", nil];
    [self.allThingArray addObject:dic12];
    
    NSDictionary *dic14=[[NSDictionary alloc]initWithObjectsAndKeys:@"logo_11x5",@"imgName",@"上海11选5",@"lotteryName",@"10066",@"lotteryID", nil];
    [self.allThingArray addObject:dic14];
    
    NSDictionary *dic15=[[NSDictionary alloc]initWithObjectsAndKeys:@"新快乐十分",@"imgName",@"快乐十分",@"lotteryName",@"10064",@"lotteryID", nil];
    [self.allThingArray addObject:dic15];
    
    NSDictionary *dic16=[[NSDictionary alloc]initWithObjectsAndKeys:@"logo_k3",@"imgName",@"内蒙快三",@"lotteryName",@"10065",@"lotteryID", nil];
    [self.allThingArray addObject:dic16];
    
    NSDictionary *dic17=[[NSDictionary alloc]initWithObjectsAndKeys:@"logo_sf14_10039",@"imgName",@"胜负14场",@"lotteryName",@"10039",@"lotteryID", nil];
    [self.allThingArray addObject:dic17];
    
    NSDictionary *dic18=[[NSDictionary alloc]initWithObjectsAndKeys:@"logo_rx9_10040",@"imgName",@"任选9场",@"lotteryName",@"10040",@"lotteryID", nil];
    [self.allThingArray addObject:dic18];
    
    NSDictionary *dic19=[[NSDictionary alloc]initWithObjectsAndKeys:@"幸运赛车",@"imgName",@"幸运赛车",@"lotteryName",@"10067",@"lotteryID", nil];
    [self.allThingArray addObject:dic19];
    
    NSDictionary *dic20=[[NSDictionary alloc]initWithObjectsAndKeys:@"江西时时彩",@"imgName",@"江西时时彩",@"lotteryName",@"10061",@"lotteryID", nil];
    [self.allThingArray addObject:dic20];
    
    NSDictionary *dic21=[[NSDictionary alloc]initWithObjectsAndKeys:@"logo_11x5",@"imgName",@"福建11选5",@"lotteryName",@"10084",@"lotteryID", nil];
    [self.allThingArray addObject:dic21];
    
    NSDictionary *dic22=[[NSDictionary alloc]initWithObjectsAndKeys:@"logo_k3",@"imgName",@"贵州快3",@"lotteryName",@"10087",@"lotteryID", nil];
    [self.allThingArray addObject:dic22];
    
    NSDictionary *dic23=[[NSDictionary alloc]initWithObjectsAndKeys:@"logo_k3",@"imgName",@"福建快3",@"lotteryName",@"10085",@"lotteryID", nil];
    [self.allThingArray addObject:dic23];
    
    NSDictionary *dic24=[[NSDictionary alloc]initWithObjectsAndKeys:@"logo_k3",@"imgName",@"快3",@"lotteryName",@"10074",@"lotteryID", nil];
    [self.allThingArray addObject:dic24];
    
    NSDictionary *dic25=[[NSDictionary alloc]initWithObjectsAndKeys:@"logo_k3",@"imgName",@"安徽快3",@"lotteryName",@"10073",@"lotteryID", nil];
    [self.allThingArray addObject:dic25];
    
    NSDictionary *dic26=[[NSDictionary alloc]initWithObjectsAndKeys:@"logo_x3D",@"imgName",@"新3D",@"lotteryName",@"10088",@"lotteryID", nil];
    [self.allThingArray addObject:dic26];
    
    NSDictionary *dic27 = [[NSDictionary alloc]initWithObjectsAndKeys:@"logo_pk10",@"imgName",@"北京PK拾",@"lotteryName",@"10089",@"lotteryID", nil];
    [self.allThingArray addObject:dic27];
    
    
    NSDictionary *dic28 = [[NSDictionary alloc]initWithObjectsAndKeys:@"logo_11x5",@"imgName",@"内蒙11选5",@"lotteryName",@"10110",@"lotteryID", nil];
    [self.allThingArray addObject:dic28];
    
    NSDictionary *dic29 = [[NSDictionary alloc]initWithObjectsAndKeys:@"安徽11选5",@"imgName",@"安徽11选5",@"lotteryName",@"10109",@"lotteryID", nil];
    [self.allThingArray addObject:dic29];
    
    NSDictionary *dic30 = [[NSDictionary alloc]initWithObjectsAndKeys:@"江苏11选5",@"imgName",@"江苏11选5",@"lotteryName",@"10108",@"lotteryID", nil];
    [self.allThingArray addObject:dic30];
    
    NSDictionary *dic31 = [[NSDictionary alloc]initWithObjectsAndKeys:@"湖北11选5",@"imgName",@"湖北11选5",@"lotteryName",@"10104",@"lotteryID", nil];
    [self.allThingArray addObject:dic31];
    
    NSDictionary *dic32 = [[NSDictionary alloc]initWithObjectsAndKeys:@"logo_11x5",@"imgName",@"河北11选5",@"lotteryName",@"10103",@"lotteryID", nil];
    [self.allThingArray addObject:dic32];
    
    NSDictionary *dic33 = [[NSDictionary alloc]initWithObjectsAndKeys:@"logo_k3",@"imgName",@"河北快3",@"lotteryName",@"10102",@"lotteryID", nil];
    [self.allThingArray addObject:dic33];
    
    NSDictionary *dic34 = [[NSDictionary alloc]initWithObjectsAndKeys:@"logo_k3",@"imgName",@"江苏快3",@"lotteryName",@"10101",@"lotteryID", nil];
    [self.allThingArray addObject:dic34];
    
    NSDictionary *dic35 = [[NSDictionary alloc]initWithObjectsAndKeys:@"logo_k3",@"imgName",@"湖北快3",@"lotteryName",@"10106",@"lotteryID", nil];
    [self.allThingArray addObject:dic35];
    NSDictionary *dic36 = [[NSDictionary alloc]initWithObjectsAndKeys:@"gd11xuan5",@"imgName",@"广东11选5",@"lotteryName",@"10062",@"lotteryID", nil];
    [self.allThingArray addObject:dic36];
    NSDictionary *dic37 = [[NSDictionary alloc]initWithObjectsAndKeys:@"henan11xuan5",@"imgName",@"河南11选5",@"lotteryName",@"10111",@"lotteryID", nil];
    [self.allThingArray addObject:dic37];
//    NSDictionary *dic38 = [[NSDictionary alloc]initWithObjectsAndKeys:@"世界杯",@"imgName",@"世界杯",@"lotteryName",@"10112",@"lotteryID", nil];
//    [self.allThingArray addObject:dic38];
    NSDictionary *dic39 = [[NSDictionary alloc]initWithObjectsAndKeys:@"logo_k3",@"imgName",@"江西快3",@"lotteryName",@"10113",@"lotteryID", nil];
    [self.allThingArray addObject:dic39];
    NSDictionary *dic40 = [[NSDictionary alloc]initWithObjectsAndKeys:@"logo_bjdc.png", @"imgName", @"北京单场",@"lotteryName", @"10057", @"lotteryID", nil];
    [self.allThingArray addObject:dic40];
    NSDictionary *dic41 = [[NSDictionary alloc]initWithObjectsAndKeys:@"logo_jclq_10058", @"imgName", @"竞彩篮球", @"lotteryName", @"10058", @"lotteryID", nil];
    [self.allThingArray addObject:dic41];
    NSDictionary *dic42=[[NSDictionary alloc]initWithObjectsAndKeys:@"logo_6cbqc",@"imgName",@"六场半全场",@"lotteryName",@"10041",@"lotteryID", nil];
    [self.allThingArray addObject:dic42];
    
    NSDictionary *dic43=[[NSDictionary alloc]initWithObjectsAndKeys:@"logo_4cjqc",@"imgName",@"四场进球彩",@"lotteryName",@"10042",@"lotteryID", nil];
    [self.allThingArray addObject:dic43];
    NSDictionary *dic44=[[NSDictionary alloc]initWithObjectsAndKeys:@"logo_k3",@"imgName",@"吉林快3",@"lotteryName",@"10107",@"lotteryID", nil];
    [self.allThingArray addObject:dic44];
    NSDictionary *dic45=[[NSDictionary alloc]initWithObjectsAndKeys:@"logo_k3",@"imgName",@"江西快3",@"lotteryName",@"10113",@"lotteryID", nil];
    [self.allThingArray addObject:dic45];
    NSDictionary *dic46=[[NSDictionary alloc]initWithObjectsAndKeys:@"logo_11x5",@"imgName",@"陕西11选5",@"lotteryName",@"10114",@"lotteryID", nil];
    [self.allThingArray addObject:dic46];
    NSDictionary *dic47=[[NSDictionary alloc]initWithObjectsAndKeys:@"新快乐十分",@"imgName",@"陕西快乐十分",@"lotteryName",@"10201",@"lotteryID", nil];
    [self.allThingArray addObject:dic47];
    NSDictionary *dic48=[[NSDictionary alloc]initWithObjectsAndKeys:@"logo_11x5",@"imgName",@"浙江11选5",@"lotteryName",@"10115",@"lotteryID", nil];
    [self.allThingArray addObject:dic48];
    NSDictionary *dic49=[[NSDictionary alloc]initWithObjectsAndKeys:@"logo_11x5",@"imgName",@"新疆11选5",@"lotteryName",@"10202",@"lotteryID", nil];
    [self.allThingArray addObject:dic49];
    NSDictionary *dic50=[[NSDictionary alloc]initWithObjectsAndKeys:@"logo_11x5",@"imgName",@"贵州11选5",@"lotteryName",@"10086",@"lotteryID", nil];
    [self.allThingArray addObject:dic50];
        NSDictionary *dic51=[[NSDictionary alloc]initWithObjectsAndKeys:@"logo_k3",@"imgName",@"上海快3",@"lotteryName",@"10203",@"lotteryID", nil];
       [self.allThingArray addObject:dic51];
    
    for (int i = 0; i <self.allThingArray.count; i++) {
        NSDictionary *tempDic = self.allThingArray[i];
        [self.allLottreyIdArray addObject:tempDic[@"lotteryID"]];
    }

}

- (void)requestURL
{
    [JCKaiJiangFirstModel requestData:^(NSArray *dataArray, NSError *error) {
        self.allDataArray = [NSMutableArray arrayWithArray:dataArray];
        [self insert100241];
        
        [self deleteNoneLottery];
        [self.dataTableView.mj_header endRefreshing];
        
        [self.dataTableView reloadData];
    }];
}

-(void)insert100241
{
    NSMutableArray *insertArray=[[NSMutableArray alloc]initWithArray:self.allDataArray];
    //插入一组100241
    for (int i=0; i < [self.allDataArray count]; i++) {
        
        JCKaiJiangFirstModel *model = [self.allDataArray objectAtIndex:i];
        
        int lotteryId = [model.lotteryId intValue];
        
        if (lotteryId == 10024) {
            JCKaiJiangFirstModel *model2 = [[JCKaiJiangFirstModel alloc]init];
            model2.lotteryId = @"100241";
            model2.drawTime = model.drawTime;
            model2.issue = model.issue;
            model2.drawNumber = model.drawNumber;
            [insertArray insertObject:model2 atIndex:i + 1];
        }
    }
    
    self.allDataArray = insertArray;
}
- (void)deleteNoneLottery{
    for (int i=0; i < [self.allDataArray count]; i++) {
        JCKaiJiangFirstModel *model = [self.allDataArray objectAtIndex:i];
        NSString *lotteryId =[NSString stringWithFormat:@"%@", model.lotteryId];
        if (![self.allLottreyIdArray containsObject: lotteryId]) {
            [self.allDataArray removeObjectAtIndex:i];
            i = i-1;
        }
    }
}


- (UITableView *)dataTableView
{
    if (!_dataTableView) {
        _dataTableView = [[UITableView alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, ScreenHeight - TabbarSafeBottomMargin) style:(UITableViewStyleGrouped)];
        _dataTableView.delegate = self;
        _dataTableView.dataSource = self;
        if (@available(iOS 11.0, *)) {
            //当有heightForHeader delegate时设置
            _dataTableView.estimatedSectionHeaderHeight = 0;
            //当有heightForFooter delegate时设置
            _dataTableView.estimatedSectionFooterHeight = 0;
        }
    }
    return _dataTableView;
}

#pragma mark -- UITableViewDataSource
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.allDataArray.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
//    static NSString *identifier = @"cell";
    NSString *identifier = [NSString stringWithFormat:@"%ld%ldcell", (long)indexPath.section, (long)indexPath.row];
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (cell == nil) {
        cell = [[UITableViewCell alloc]initWithStyle:(UITableViewCellStyleDefault) reuseIdentifier:identifier];
    }
    JCKaiJiangTableViewCell *kaijiangCell = [[JCKaiJiangTableViewCell alloc]initWithStyle:(UITableViewCellStyleDefault) reuseIdentifier:identifier];
//     kaijiangCell.arrowImage.image =[UIImage imageNamed:@"cell_arrow"];
    if (self.allDataArray.count >0) {
        JCKaiJiangFirstModel *model = self.allDataArray[indexPath.row];
        kaijiangCell.issueLabel.text = [NSString stringWithFormat:@"%@期", model.issue];
        NSString *date = [model.drawTime componentsSeparatedByString:@" "][0];
        kaijiangCell.drawTimeLabel.text = date;
       
        
        for (int i = 0; i < self.allThingArray.count; i ++) {
            if ([model.lotteryId intValue] == [[[self.allThingArray objectAtIndex:i] objectForKey:@"lotteryID"] intValue]) {
                kaijiangCell.arrowImage.image =[UIImage imageNamed:@"cell_arrow"];
                kaijiangCell.lotteryImage.image = [UIImage imageNamed:[self.allThingArray[i] objectForKey:@"imgName"]];
                kaijiangCell.lotteryLabel.text = [NSString stringWithFormat:@"%@", [[self.allThingArray objectAtIndex:i] objectForKey:@"lotteryName"]];
            }
        }
        
        NSString *drawNumberStr = model.drawNumber;
        if ([drawNumberStr length] > 0) {
            NSArray *array = [drawNumberStr componentsSeparatedByString:@"#"];
            if ([array lastObject]) {
                NSString *str1 = [[array objectAtIndex:0] stringByReplacingOccurrencesOfString:@"," withString:@" "];
                
                if ([model.lotteryId intValue] == 10024) {
                    str1 = [str1 substringToIndex:5];
                }
                NSArray *arr1 = [str1 componentsSeparatedByString:@" "];
                if ([model.lotteryId intValue] == 10059 || [model.lotteryId intValue] == 10058 || [model.lotteryId intValue] == 10057) {
                        
                    UILabel *label2 = [[UILabel alloc]initWithFrame:CGRectMake(70, CGRectGetMaxY(kaijiangCell.issueLabel.frame) + 15, ballLabelWidth, ballLabelWidth)];
                    label2.layer.masksToBounds = YES;
                    label2.layer.cornerRadius = ballLabelWidth / 2;
                    label2.backgroundColor = ColorRGB(37, 169, 255, 1);
                    [kaijiangCell addSubview:label2];
                    
                    UILabel *label3 = [[UILabel alloc]init];//label3 frame等文字宽度确定之后再设置
                    label3.layer.masksToBounds = YES;
                    label3.layer.cornerRadius = ballLabelWidth / 2;
                    label3.backgroundColor = ColorRGB(37, 169, 255, 1);
                    [kaijiangCell addSubview:label3];

                    UILabel *label1 = [[UILabel alloc]initWithFrame:CGRectMake(CGRectGetMidX(label2.frame), CGRectGetMaxY(kaijiangCell.issueLabel.frame) + 15, 180, ballLabelWidth)];
                    label1.backgroundColor = ColorRGB(37, 169, 255, 1);
                    label1.textAlignment = NSTextAlignmentCenter;
                    label1.font = [UIFont systemFontOfSize:15];
                    label1.adjustsFontSizeToFitWidth = YES;
                    label1.text = [NSString stringWithFormat:@"%@  %@  %@", [arr1 objectAtIndex:0], [arr1 objectAtIndex:1], [arr1 objectAtIndex:2]];
                    label1.textColor = allWhiteColor;
                    [label1 sizeToFit];
                    CGSize size = [label1 sizeThatFits:CGSizeMake(CGRectGetMidX(label2.frame), MAXFLOAT)];
                    label1.frame = CGRectMake(CGRectGetMidX(label2.frame), CGRectGetMaxY(kaijiangCell.issueLabel.frame) + 15, size.width, ballLabelWidth);
                    [kaijiangCell addSubview:label1];
                    label3.frame = CGRectMake(size.width + 70, CGRectGetMinY(label2.frame), ballLabelWidth, ballLabelWidth);

                    if ([model.lotteryId intValue] == 10059) {
                        label3.backgroundColor = ColorRGB(81, 197, 108, 1);
                        label2.backgroundColor = ColorRGB(81, 197, 108, 1);
                        label1.backgroundColor = ColorRGB(81, 197, 108, 1);
                    } else if ([model.lotteryId intValue] == 10058) {
                        label1.backgroundColor = ColorRGB(37, 169, 255, 1);
                        label2.backgroundColor = ColorRGB(37, 169, 255, 1);
                        label3.backgroundColor = ColorRGB(37, 169, 255, 1);
                    } else {
                        label1.backgroundColor = ColorRGB(255, 44, 85, 1);
                        label2.backgroundColor = ColorRGB(255, 44, 85, 1);
                        label3.backgroundColor = ColorRGB(255, 44, 85, 1);
                    }
                    
                }
                else if ([model.lotteryId isEqualToString:@"10042"]||[model.lotteryId isEqualToString:@"10039"]||[model.lotteryId isEqualToString:@"10040"]||[model.lotteryId isEqualToString:@"10041"]){
       
                    NSInteger _gameCount = 0;
                    UIColor *themeColor;
                    switch ([model.lotteryId integerValue]) {
                        case 10039:
                            themeColor = UICOLOR_HEX(0xFF2D55);
                            _gameCount = 14;
                            break;
                        case 10040:
                            themeColor = UICOLOR_HEX(0xFFBF3E);
                            _gameCount = 14;
                            break;
                        case 10041:
                            themeColor = UICOLOR_HEX(0x51C66C);
                            _gameCount = 12;
                            break;
                        case 10042:
                            themeColor = UICOLOR_HEX(0x25A9FF);
                            _gameCount = 8;
                            
                            break;
                        default:
                            break;
                    }
                    NSMutableArray *resultArr = [NSMutableArray array];
                    NSString *text = [model.drawNumber copy];
                    //    NSArray *arr = [_model.team componentsSeparatedByString:@","];
                    for (int j = 0; j<model.drawNumber.length; j++) {
                        
                        NSString *str = [text substringToIndex:1];
                        text = [text substringFromIndex:1];
                        [resultArr addObject:str];
                    }
                    CGFloat width = 16*ScreenScale;
                    CGFloat height = 26*ScreenScale;
                    CGFloat spacce = 3.3 *ScreenScale;
                    for (int i = 0; i <_gameCount; i ++) {
                        UILabel *label = [[UILabel alloc]init];
                        label.frame = CGRectMake(10 + 50 + 10  +i*(width+spacce), CGRectGetMaxY(kaijiangCell.issueLabel.frame)+12, width, height);
                        label.textAlignment = NSTextAlignmentCenter;
                        label.backgroundColor = themeColor;
                        label.layer.cornerRadius = 2;
                        label.layer.masksToBounds = YES;
                        label.tag = i +1000;
                        label.text = resultArr[i];
                        label.textColor = allWhiteColor;
                        label.font = FONT(12);
                        [kaijiangCell addSubview:label];
                    }
                }
#pragma mark -- 快3系列
/**

                @"江苏快3", @"10101",
                @"河北快3", @"10102",
                @"内蒙快3", @"10065",
                @"福建快3", @"10085",
                @"贵州快3", @"10087",
                @"广西快3", @"10074",
                @"安徽快3", @"10073",
                @"江西快3", @"10113",
                @"湖北快3", @"10106",
                @"吉林快3", @"10107",
                @"上海快3", @"10203",
 */
            else if ([model.lotteryId isEqualToString:@"10106"]//湖北快3
                    || [model.lotteryId isEqualToString:@"10085"]//福建快3
                    || [model.lotteryId isEqualToString:@"10101"]//江苏快3
                    || [model.lotteryId isEqualToString:@"10102"]//河北快3
                    || [model.lotteryId isEqualToString:@"10065"]//内蒙快3
                    || [model.lotteryId isEqualToString:@"10087"]//贵州快3
                    || [model.lotteryId isEqualToString:@"10074"]//广西快3
                    || [model.lotteryId isEqualToString:@"10073"]//安徽快3
                    || [model.lotteryId isEqualToString:@"10113"]//江西快3
                    || [model.lotteryId isEqualToString:@"10107"]//吉林快3
                    || [model.lotteryId isEqualToString:@"10203"]//上海快3
                         )
                {
                    NSDictionary *imgDic  = @{
                                              @"1":@"dice_v1_small",
                                              @"2":@"dice_v2_small",
                                              @"3":@"dice_v3_small",
                                              @"4":@"dice_v4_small",
                                              @"5":@"dice_v5_small",
                                              @"6":@"dice_v6_small",
                                              };
                    
                    for (int i = 0; i < arr1.count; i ++) {
                        
                        UIButton * button = [UIButton buttonWithType:UIButtonTypeCustom];
                        button.frame = CGRectMake(10 + 50 + 10 + (ballLabelWidth + 5) * i, CGRectGetMaxY(kaijiangCell.issueLabel.frame) + 15, ballLabelWidth, ballLabelWidth);
                        //                        button.backgroundColor = [UIColor redColor];
                        button.titleLabel.font = [UIFont systemFontOfSize:13.f];
                        [button setImage:[UIImage imageNamed:[NSString stringWithFormat:@"%@",[imgDic objectForKey:arr1[i]]]] forState:UIControlStateNormal];
                        //
                        [kaijiangCell addSubview:button];
                        
                    }
                    //                    数组求和
                    NSNumber *sum = [arr1 valueForKeyPath:@"@sum.floatValue"];
                    
                    UILabel *l = [[UILabel alloc] init];
                    l.frame = CGRectMake( 10 + 50 + 10 + (ballLabelWidth + 5) * arr1.count, CGRectGetMaxY(kaijiangCell.issueLabel.frame) + 15, 60, ballLabelWidth);
                    l.font = [UIFont systemFontOfSize:14.f];
                    l.text =  [NSString stringWithFormat:@"和值:%@",sum];
                    l.textColor = [UIColor lightGrayColor];
                    l.textAlignment = NSTextAlignmentLeft;
                    l.numberOfLines = 0;
                    [kaijiangCell addSubview:l];
                }
                else {
                    for (int i = 0; i < arr1.count; i ++) {
                        UILabel *label = [[UILabel alloc]initWithFrame:CGRectMake(10 + 50 + 10 + (ballLabelWidth + 5) * i, CGRectGetMaxY(kaijiangCell.issueLabel.frame) + 15, ballLabelWidth, ballLabelWidth)];
                        label.layer.cornerRadius = ballLabelWidth/2;
                        label.layer.masksToBounds = YES;
                        label.textColor = allWhiteColor;
                        label.textAlignment = NSTextAlignmentCenter;
                        label.backgroundColor = ColorRGB(230, 47, 23, 1);
                        label.font = [UIFont systemFontOfSize:13.f];
                        label.text = [arr1 objectAtIndex:i];
                        [kaijiangCell addSubview:label];
                    }
                }
                
               
                
                NSString *str2 = nil;
                if ([model.lotteryId intValue] == 10032 || [model.lotteryId intValue] == 10026 || [model.lotteryId intValue] == 10033 || [model.lotteryId intValue] == 10030 || [model.lotteryId intValue] == 10027) {
                    str2 = [[array objectAtIndex:1] stringByReplacingOccurrencesOfString:@"," withString:@" "];
                    NSArray *arr2 = [str2 componentsSeparatedByString:@" "];
                    for (int j = 0; j < arr2.count; j ++) {
                        
                        CGRect frame = CGRectZero;
                        if ([model.lotteryId intValue] == 10032 || [model.lotteryId intValue] == 10030 || [model.lotteryId intValue] == 10027) {
                            frame = CGRectMake(15 + 50 + 10 + ballLabelWidth * (arr1.count + 1) + 5 + j * (ballLabelWidth + 5), CGRectGetMaxY(kaijiangCell.issueLabel.frame) + 15, ballLabelWidth, ballLabelWidth);
                        }
                       else if ([model.lotteryId intValue] == 10026) {
                            frame = CGRectMake(15 + 50 + 10 + ballLabelWidth * (arr1.count + 1) + j * (ballLabelWidth + 5), CGRectGetMaxY(kaijiangCell.issueLabel.frame) + 15, ballLabelWidth, ballLabelWidth);
                        }
                        else if ([model.lotteryId intValue] == 10033) {
                            frame = CGRectMake(15 + 50 + 10 + ballLabelWidth * (arr1.count + 1) + 10 + j * (ballLabelWidth + 5), CGRectGetMaxY(kaijiangCell.issueLabel.frame) + 15, ballLabelWidth, ballLabelWidth);
                        }
                        UILabel *blueLabel = [[UILabel alloc]initWithFrame:frame];
                        blueLabel.text = [NSString stringWithFormat:@"%@", [arr2 objectAtIndex:j]];
                        blueLabel.textColor = allWhiteColor;
                        blueLabel.font = [UIFont systemFontOfSize:13.f];
                        blueLabel.textAlignment = NSTextAlignmentCenter;
                        blueLabel.backgroundColor = ColorRGB(0, 160, 255, 1);
                        blueLabel.layer.cornerRadius = ballLabelWidth/2;
                        blueLabel.layer.masksToBounds = YES;
                        blueLabel.clipsToBounds = YES;
                        [kaijiangCell.contentView addSubview:blueLabel];
                    }
                }
                
               
                
            }
        }
        
    }
    
    cell = kaijiangCell;
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 1;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 70;
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
    return 1;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{

    if (self.allDataArray.count > 0) {
        JCKaiJiangFirstModel *model = self.allDataArray[indexPath.row];

        if ([model.lotteryId intValue] == 10057 || [model.lotteryId intValue] == 10058 || [model.lotteryId intValue] == 10059) {
            JCJJKJViewController *kjVC = [[JCJJKJViewController alloc]init];
            kjVC.lotteryId = [NSString stringWithFormat:@"%@", model.lotteryId];
            kjVC.issue = [NSString stringWithFormat:@"%@", model.issue];
            [self.navigationController pushViewController:kjVC animated:YES];
        }else if([model.lotteryId isEqualToString:@"10042"]||[model.lotteryId isEqualToString:@"10039"]||[model.lotteryId isEqualToString:@"10040"]||[model.lotteryId isEqualToString:@"10041"]){
            
            JCKJTraditionalFootBallViewController *vc = [[JCKJTraditionalFootBallViewController alloc]init];
            vc.lotteryId = [NSNumber numberWithInteger:[model.lotteryId integerValue]];
            if ([model.lotteryId isEqualToString:@"10039"]) {
                vc.titleString =@"胜负14场";
            }else if ([model.lotteryId isEqualToString:@"10040"]){
                vc.titleString = @"任选9场";
            }else if ([model.lotteryId isEqualToString:@"10041"]){
                vc.titleString = @"六场半全场";
            }else if ([model.lotteryId isEqualToString:@"10042"]){
                vc.titleString = @"四场进球彩";
            }else{
                vc.titleString = @"传统足球";
            }
            
            [self.navigationController pushViewController:vc animated:YES];
        }
        else {
            NSString *lotteryName = @"";
            for (int i = 0; i < self.allThingArray.count; i ++) {
                NSDictionary *dict = [self.allThingArray objectAtIndex:i];
                if ([model.lotteryId intValue] == [[dict objectForKey:@"lotteryID"] intValue]) {
                    lotteryName = [dict objectForKey:@"lotteryName"];
                }
            }
            JCKJSecondViewController *kaijiangSecVC = [[JCKJSecondViewController alloc]init];
            kaijiangSecVC.lotteryId = model.lotteryId;
            kaijiangSecVC.lotteryName = lotteryName;
            [self.navigationController pushViewController:kaijiangSecVC animated:YES];
        }
    }
}

#pragma mark -- 横线左对齐
- (void)viewDidLayoutSubviews {
    if ([self.dataTableView respondsToSelector:@selector(setSeparatorInset:)]) {
        [self.dataTableView setSeparatorInset:UIEdgeInsetsZero];
    }
    if ([self.dataTableView respondsToSelector:@selector(setLayoutMargins:)])  {
        [self.dataTableView setLayoutMargins:UIEdgeInsetsZero];
    }
    
}

- (void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPat{
    if ([cell respondsToSelector:@selector(setLayoutMargins:)]) {
        [cell setLayoutMargins:UIEdgeInsetsZero];
    }
    if ([cell respondsToSelector:@selector(setSeparatorInset:)]){
        [cell setSeparatorInset:UIEdgeInsetsZero];
    }
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
