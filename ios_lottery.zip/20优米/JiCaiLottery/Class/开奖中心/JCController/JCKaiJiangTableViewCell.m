//
//  JCKaiJiangTableViewCell.m
//  JiCaiLottery
//
//  Created by 风外杏林香 on 2017/4/1.
//  Copyright © 2017年 风外杏林香. All rights reserved.
//

#import "JCKaiJiangTableViewCell.h"
#import "JCHeader.h"

@implementation JCKaiJiangTableViewCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        [self initWithUI];
    }
    return self;
}

- (void)initWithUI
{
    self.lotteryLabel = [[UILabel alloc]init];
    self.lotteryLabel.textColor = ColorRGB(51, 51, 51, 1);
    self.lotteryLabel.font = [UIFont systemFontOfSize:16.f];
    self.lotteryLabel.textAlignment = NSTextAlignmentLeft;
    
    self.lotteryImage = [[UIImageView alloc]init];
//    self.lotteryImage.backgroundColor = [UIColor redColor];
    self.lotteryImage.layer.cornerRadius = 25;
    self.lotteryImage.layer.masksToBounds = YES;
    
    self.issueLabel = [[UILabel alloc]init];
    self.issueLabel.font = [UIFont systemFontOfSize:13.f];
    self.issueLabel.textAlignment = NSTextAlignmentCenter;
    self.issueLabel.textColor = ColorRGB(102, 102, 102, 1);
    self.issueLabel.adjustsFontSizeToFitWidth = YES;
    
    self.drawTimeLabel = [[UILabel alloc]init];
    self.drawTimeLabel.textColor = ColorRGB(102, 102, 102, 1);
    self.drawTimeLabel.font = [UIFont systemFontOfSize:13.f];
    self.drawTimeLabel.textAlignment = NSTextAlignmentCenter;
    
    self.arrowImage = [[UIImageView alloc] init];
    self.arrowImage.image =[UIImage imageNamed:@"cell_arrow"];
    
    self.arrowImage.contentMode = UIViewContentModeCenter;
    
    [self.contentView sd_addSubviews:@[self.arrowImage,self.lotteryImage, self.lotteryLabel, self.issueLabel, self.drawTimeLabel]];

    self.lotteryImage.sd_layout
    .leftSpaceToView(self.contentView, 10)
    .topSpaceToView(self.contentView, 10)
    .heightIs(50)
    .widthIs(50);
    
    CGFloat width = (ScreenWidth - 50 - 50) / 3;
    self.lotteryLabel.sd_layout
    .topEqualToView(self.lotteryImage)
    .leftSpaceToView(self.lotteryImage, 10)
    .widthIs(width)
    .heightIs(25);
    
    self.issueLabel.sd_layout
    .topEqualToView(self.lotteryLabel)
    .leftSpaceToView(self.lotteryLabel, 10)
    .widthIs(width)
    .heightIs(25);
    
    self.drawTimeLabel.sd_layout
    .topEqualToView(self.issueLabel)
    .leftSpaceToView(self.issueLabel, 10)
    .widthIs(width)
    .heightIs(25);
    
    self.arrowImage.sd_layout
    .centerYEqualToView(self.contentView)
    .rightSpaceToView(self.contentView, 5)
    .widthIs(15)
    .heightIs(15);
    
}
- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
