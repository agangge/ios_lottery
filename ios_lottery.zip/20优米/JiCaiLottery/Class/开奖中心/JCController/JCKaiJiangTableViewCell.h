//
//  JCKaiJiangTableViewCell.h
//  JiCaiLottery
//
//  Created by 风外杏林香 on 2017/4/1.
//  Copyright © 2017年 风外杏林香. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface JCKaiJiangTableViewCell : UITableViewCell

@property (nonatomic, strong)UILabel *lotteryLabel;
@property (nonatomic, strong)UIImageView *lotteryImage;
@property (nonatomic, strong)UILabel *issueLabel;
@property (nonatomic, strong)UILabel *drawTimeLabel;
@property (nonatomic, strong)UIImageView *arrowImage;

@end
