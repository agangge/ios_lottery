//
//  JCKaiJiangFirstModel.h
//  JiCaiLottery
//
//  Created by 风外杏林香 on 2017/4/1.
//  Copyright © 2017年 风外杏林香. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface JCKaiJiangFirstModel : NSObject

@property (nonatomic, strong)NSString *drawNumber;
@property (nonatomic, strong)NSString *lotteryId;
@property (nonatomic, strong)NSString *issue;
@property (nonatomic, strong)NSString *drawTime;
@property (nonatomic, strong)NSString *issueId;

+ (void)requestData:(void(^)(NSArray *dataArray, NSError *error))block;

@end
