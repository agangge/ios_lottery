//
//  JCKaiJiangFirstModel.m
//  JiCaiLottery
//
//  Created by 风外杏林香 on 2017/4/1.
//  Copyright © 2017年 风外杏林香. All rights reserved.
//

#import "JCKaiJiangFirstModel.h"

#import "JCHeader.h"

@implementation JCKaiJiangFirstModel

- (id)initWithDictionary:(NSDictionary *)dict
{
    self = [super init];
    if (self) {
        self.drawNumber = [dict objectForKey:@"drawNumber"];
        self.lotteryId = [dict objectForKey:@"lotteryId"];
        self.issue = [dict objectForKey:@"issue"];
        self.issueId = [dict objectForKey:@"issueId"];
        self.drawTime = [dict objectForKey:@"drawTime"];
    }
    return self;
}
+ (void)requestData:(void(^)(NSArray *dataArray, NSError *error))block
{
    NSString *urlString = [NSString stringWithFormat:@"lottery/issue_notify_all.htm"];
     [JCRequestNetWork getWithUrlString:urlString parameters:nil success:^(id data) {
         NSDictionary *dictionary = (NSDictionary *)[NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableLeaves error:nil];
         NSMutableArray *allModelArray = [NSMutableArray arrayWithCapacity:[[dictionary objectForKey:@"drawList"] count]];
         for (NSDictionary *dict1 in [dictionary objectForKey:@"drawList"]) {
             JCKaiJiangFirstModel *model = [[JCKaiJiangFirstModel alloc]initWithDictionary:dict1];
             [allModelArray addObject:model];
         
         }
         if (block) {
             block([NSArray arrayWithArray:allModelArray], nil);
         }
        
    } failure:^(NSError *error) {
        if (error) {
            block([NSArray array], error);
        }
        
    } showView:nil];
}

@end
