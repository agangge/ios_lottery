//
//  JCGendanViewController.m
//  JiCaiLottery
//
//  Created by Peng Jun on 2017/11/22.
//  Copyright © 2017年 JiCaiLottery. All rights reserved.
//

#import "JCGendanViewController.h"
#import "JCGendanTableViewCell.h"
#import "JCGendanCenterListModel.h"
#import "JCHeader.h"
#import "MJRefresh.h"
#import "JCSearchView.h"
#import "JCTitleButton.h"
#import "JCGendanPopView.h"
#import "JCcopyGendanViewController.h"
#import "JCStartGendanViewController.h"
#import "JCGendanOrderDetailViewController.h"
#import "JCGendanListViewController.h"
#import "JCGendanNewDetailViewController.h"
#import "JCLoginViewController.h"
#import "JCGendanNumberDetailViewController.h"
static int const fetchSize = 10;
static NSString *const CELLIDENTIFY = @"gendanCell";
@interface JCGendanViewController ()<UITableViewDelegate,UITableViewDataSource,JCSearchViewDelegate,UITextFieldDelegate>
@property (nonatomic, strong)UITableView *tableView;
@property (nonatomic, strong)NSMutableArray *dataArray;
@property (nonatomic, strong)JCGendanTableViewCell *gendanCell;
@property (nonatomic, strong)JCSearchView *searchView;
@property (nonatomic, strong)UIButton *mengButtonView;
@property (nonatomic, strong)UIView *shadowView;
@property (nonatomic, strong)UIView *selectedView;
@property (nonatomic, strong)JCGendanPopView *popView;
@property (nonatomic, strong)UIButton *titleBtn;
@property (nonatomic, assign)NSInteger popViewButtonIndex;
@end

@implementation JCGendanViewController{

    BOOL isSearch;
    int _page;
}
- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    if (self.dataArray.count == 0) {
        [self requestDataIsNewRefresh:YES];
    }
}

- (void)viewDidDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
//    [self.navigationController setNavigationBarHidden:YES animated:self.closeAnimating]; // 纯色的navigationbar加载会有问题
}
- (UITableView *)tableView{
    if (!_tableView) {
        if (iPhoneX) {
            _tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 24, ScreenWidth, ScreenHeight-24) style:UITableViewStylePlain];
        }else{
            _tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, ScreenWidth, ScreenHeight) style:UITableViewStylePlain];
        }
        
        _tableView.delegate = self;
        _tableView.dataSource = self;
        self.tableView.tableFooterView = [[UIView alloc] initWithFrame:CGRectZero];
        self.tableView.rowHeight = UITableViewAutomaticDimension;
        self.tableView.estimatedRowHeight = 100;
        
    }
    return _tableView;
}
- (NSMutableArray *)dataArray{
    if (!_dataArray) {
        _dataArray = [NSMutableArray array];
    }
    return _dataArray;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.dataArray.count;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    __weak typeof(self)wealself = self;
    _gendanCell = [tableView dequeueReusableCellWithIdentifier:CELLIDENTIFY];
    if (!_gendanCell) {
        _gendanCell = [[JCGendanTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CELLIDENTIFY];
        _gendanCell.selectionStyle = UITableViewCellSelectionStyleNone;
        wealself.gendanCell.gdBlcok = ^(NSInteger schemeId){
//            JCGendanListViewController *vc =[[JCGendanListViewController alloc]init];
            JCcopyGendanViewController *vc = [[JCcopyGendanViewController alloc]init];
            vc.schemeId = schemeId;
            [wealself.navigationController pushViewController:vc animated:YES];
        };
    }
    JCGendanCenterListModel *model = self.dataArray[indexPath.row];
    _gendanCell.model = model;
    
    
    return _gendanCell;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    NSString *isLogin = [UserDefaults objectForKey:@"isLogin"];
    if ([isLogin intValue] == 0) {
        //未登录将tabbar的selectedIndex设置为之前选择的selectedIndex
        JCLoginViewController *jcLoginVC = [[JCLoginViewController alloc]init];
        [self presentViewController:jcLoginVC animated:YES completion:nil];
        return;
    }
    NSString *clientUserSession = [UserDefaults objectForKey:@"clientUserSession"];
    if (self.dataArray.count != 0) {
        
        if ([clientUserSession isEqualToString:@""]) {
            [JCPopObject showMessage:@"请登录账号！"];
        } else {
            JCGendanCenterListModel *model = self.dataArray[indexPath.row];
            if ([model.lotteryName isEqualToString:@"竞彩足球"] || [model.lotteryName isEqualToString:@"竞彩篮球"] || [model.lotteryName isEqualToString:@"北京单场"]) {
                JCGendanNewDetailViewController *vc = [[JCGendanNewDetailViewController alloc]init];
                vc.schemeId = model.schemeId;
                vc.isShowGendanButton = YES;
                [self.navigationController pushViewController:vc animated:YES];
            } else {
                JCGendanNumberDetailViewController *vc = [[JCGendanNumberDetailViewController alloc]init];
                vc.schemeId = model.schemeId;
                vc.isShowGendanButton = YES;
                [self.navigationController pushViewController:vc animated:YES];
            }
        }
    }
}
- (void)viewDidLoad {
    
    [super viewDidLoad];
 
    [self.view addSubview:self.tableView];
    __weak typeof (self) weakSelf = self;
    self.tableView.mj_header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
        [weakSelf requestDataIsNewRefresh:YES];
    }];
    self.tableView.mj_footer = [MJRefreshBackNormalFooter footerWithRefreshingBlock:^{
        [weakSelf requestDataIsNewRefresh:NO];
    }];
     _popViewButtonIndex = 0;
    [self initWithTitleButton];
    [self initWithSearchButton];
    [self requestDataIsNewRefresh:YES];

}

- (void)requestDataIsNewRefresh:(BOOL)isNewfresh{
    
    NSString *isLogin = [UserDefaults objectForKey:@"isLogin"];
    if ([isLogin intValue] == 0) {
        JCLoginViewController *jcLoginVC = [[JCLoginViewController alloc]init];
        [self presentViewController:jcLoginVC animated:YES completion:nil];
        return;
    }
    NSString *urlString = [JCAllUrl gendanCenterUrl];

    if (isNewfresh) {
        _page = 1;
    }else{
        _page +=1;
    }

        NSString *keyWord = [self.searchView.nameText.text stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
        
        NSDictionary *dict = @{
                               @"type" : @(_popViewButtonIndex),
                               @"fetchSize" : @(fetchSize),
                               @"firstRow" : @(_page),
                               @"userName" : keyWord.length>0?keyWord:@"",
                               };

    __weak typeof (self) weakSelf = self;

    [JCRequestNetWork getWithUrlString:urlString parameters:dict success:^(id data) {
        
        NSDictionary *dataDic = (NSDictionary *)[NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableLeaves error:nil];
        if ([dataDic[@"flag"] integerValue] == 1) {
            NSArray *array =dataDic[@"schemeList"];
            JCLog(@"array -- %lu", (unsigned long)array.count);
            if (keyWord.length>0&&isNewfresh) {
                if (array.count >0) {
                    [weakSelf.dataArray removeAllObjects];
                }
            }
            if (array.count>0 &&isNewfresh) {
                [weakSelf.dataArray removeAllObjects];
            }
            if (array.count>0 && array.count<fetchSize) {
                [weakSelf.tableView.mj_header endRefreshing];
                [weakSelf.tableView.mj_footer endRefreshing];
                
            }else{
                [weakSelf.tableView.mj_header endRefreshing];
                [weakSelf.tableView.mj_footer endRefreshing];
            }
            for (NSDictionary *dictionary in array) {

                JCGendanCenterListModel *model = [JCGendanCenterListModel yy_modelWithDictionary:dictionary];
                [weakSelf.dataArray addObject:model];
            }
            dispatch_async(dispatch_get_main_queue(), ^{
                [weakSelf.tableView reloadData];
            });
            
        }else{
            
            [weakSelf.tableView.mj_header endRefreshing];
            [weakSelf.tableView.mj_footer endRefreshing];
            
            dispatch_async(dispatch_get_main_queue(), ^{
                weakSelf.searchView.nameText.text = @"";
                jxt_showToastTitleDismiss(dataDic[@"errorMessage"], 0.3, ^(NSInteger buttonIndex) {
                    
                });
            });
        }
    } failure:^(NSError *error) {
        [weakSelf.tableView.mj_header endRefreshing];
         [weakSelf.tableView.mj_footer endRefreshing];
    } showView:nil];
}
#pragma mark -- 初始化选择按钮
- (void)initWithTitleButton{
    self.titleBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    self.titleBtn.frame = CGRectMake(0 , 0, ScreenWidth, 30);
    self.titleBtn.titleLabel.textAlignment = NSTextAlignmentRight;
    [self.titleBtn setTitle:@"          全部 ▼" forState:0];
    [self.titleBtn setTitle:@"          全部 ▲" forState:UIControlStateSelected];
    [self.titleBtn addTarget:self action:@selector(buttonClick:) forControlEvents:UIControlEventTouchUpInside];
    self.navigationItem.titleView = self.titleBtn;
    
}

- (void)buttonClick:(UIButton *)btn {
    
    __block typeof(self)weakself = self;
    if (!btn.selected) {
        UIView *rootView = [[UIApplication sharedApplication] keyWindow];

        self.popView = [[JCGendanPopView alloc]initWithFrame:CGRectMake(0, StatusBarAndNavigationBarHeight, ScreenWidth, ScreenHeight - StatusBarAndNavigationBarHeight) withIndex:self.popViewButtonIndex+1];
        self.popView.selectBlock = ^(NSString *buttontext, NSInteger butttonIndex) {
            weakself.popViewButtonIndex = butttonIndex - 1;
            [weakself.titleBtn setTitle:[NSString stringWithFormat:@"          %@  ▼",buttontext] forState:UIControlStateNormal];
             [weakself.titleBtn setTitle:[NSString stringWithFormat:@"          %@  ▲",buttontext] forState:UIControlStateSelected];
            weakself.titleBtn.selected = !btn.selected;
            [weakself.popView removeFromSuperview];
            [weakself requestDataIsNewRefresh:YES];
        };
        [rootView addSubview:self.popView];
    }
    else{
         [self.popView removeFromSuperview];
    }
    btn.selected = !btn.selected;
}

- (void)initWithSearchButton{
    UIBarButtonItem *searchBtn = [[UIBarButtonItem alloc]initWithImage:[UIImage imageNamed:@"search.png"] style:(UIBarButtonItemStylePlain) target:self action:@selector(searchAction:)];
    NSArray *array = @[searchBtn];
    
    self.navigationItem.rightBarButtonItems = array;
}
#pragma mark -- 模糊搜索
- (void)searchAction:(UIBarButtonItem *)sender
{
    [self.popView removeFromSuperview];
    self.titleBtn.selected = NO;
    
    JCLog(@"search");
    [self.view addSubview:self.mengButtonView];
    if (!self.searchView) {
        self.searchView = [[JCSearchView alloc]initWithFrame:CGRectMake(0, StatusBarAndNavigationBarHeight, ScreenWidth, 60)];
    }
    
    self.searchView.backgroundColor = ColorRGB(247, 247, 247, 1);
    self.searchView.delegate = self;
    [self.searchView.nameText becomeFirstResponder];
    self.searchView.nameText.delegate = self;
    [UIView animateWithDuration:0.3 animations:^{
        [self.view addSubview:self.searchView];
    } completion:^(BOOL finished) {
        
    }];
}
#pragma mark -- UITextFieldDelegate
- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    if ([string isEqualToString:@"\n"]) {  //如果 serch触发了 输入\n 判断 取消键盘
        [textField resignFirstResponder];
        //添加搜索方法；
        [self clieckSearchButton];
        [self.searchView removeFromSuperview];
        [self.mengButtonView removeFromSuperview];
        
        return NO;
    }
    return YES;
}

- (void)clieckSearchButton
{
    isSearch = YES;
    [self requestDataIsNewRefresh:YES];
}

#pragma mark -- JCSearchViewDelegate
- (void)clickDisMissBtn:(UIButton *)sender
{
    [self.mengButtonView removeFromSuperview];
    [self.searchView.nameText resignFirstResponder];
    [self.searchView removeFromSuperview];
}

- (void)mengButtonViewAction:(UIButton *)sender
{
    [self.mengButtonView removeFromSuperview];
    [self.searchView.nameText resignFirstResponder];
    [self.searchView removeFromSuperview];
}
- (UIButton *)mengButtonView
{
    if (!_mengButtonView) {
        _mengButtonView = [UIButton buttonWithType:(UIButtonTypeCustom)];
        _mengButtonView.frame = CGRectMake(0, 0, ScreenWidth, ScreenHeight);
        _mengButtonView.backgroundColor = [UIColor blackColor];
        _mengButtonView.alpha = 0.5;
        [_mengButtonView addTarget:self action:@selector(mengButtonViewAction:) forControlEvents:(UIControlEventTouchUpInside)];
    }
    return _mengButtonView;
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}


@end
