//
//  JCGendanListViewController.h
//  JiCaiLottery
//
//  Created by Peng Jun on 2017/11/23.
//  Copyright © 2017年 JiCaiLottery. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface JCGendanListViewController : UIViewController
//schemeId
@property (nonatomic, assign)NSInteger schemeId;

@end
