//
//  JCGendanListViewController.m
//  JiCaiLottery
//
//  Created by Peng Jun on 2017/11/23.
//  Copyright © 2017年 JiCaiLottery. All rights reserved.
//

#import "JCGendanListViewController.h"
#import "JCHeader.h"
#import "JCGendanListTableViewCell.h"
#import "JCgendanListModel.h"
static CGFloat const ROWHEIGHT = 44.F;
static NSInteger const fetchSize = 20.F;
static NSString *const identifyString = @"gendanlistCell";
@interface JCGendanListViewController ()<UITableViewDelegate,UITableViewDataSource,JCTitleViewDelegate>
@property (nonatomic, strong)JCGendanListTableViewCell *listCell;
@property (nonatomic, strong)NSMutableArray *dataArray;
@property (nonatomic, strong)UITableView *tableView;
@property (nonatomic, strong)JCTitleView *titleView;
@property (nonatomic, strong)UIView *headerView;
@end

@implementation JCGendanListViewController{
    int _page;
}
- (UITableView *)tableView{
    if (!_tableView) {
        _tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, StatusBarAndNavigationBarHeight, ScreenWidth, ScreenHeight) style:UITableViewStylePlain];
        _tableView.delegate = self;
        _tableView.dataSource = self;
        _tableView.rowHeight = ROWHEIGHT;
        _tableView.tableHeaderView = self.headerView;
        _tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
        
    }
    return _tableView;
}
- (UIView *)headerView{
    if (!_headerView) {
        _headerView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, 40)];
        _headerView.backgroundColor = allWhiteColor;
        NSArray *arr = @[@"姓名",@"跟单金额",@"跟单时间",@"奖金"];
        for (int i = 0; i<4; i++) {
            CGFloat x = i*ScreenWidth/4;
            
            UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(x, 0, ScreenWidth/4, 40)];
            label.text =arr[i];
            label.textAlignment = NSTextAlignmentCenter;
            label.textColor =UICOLOR_HEX(0x333333);
            label.font = FONT(15);
            [_headerView addSubview:label];
        }
        UILabel *line = [[UILabel alloc]initWithFrame:CGRectMake(0, 39.5, ScreenWidth, 0.5)];
        line.backgroundColor = UICOLOR_HEX(0xf0f0f0);
        [_headerView addSubview:line];
    }

    return _headerView;
}
- (NSMutableArray *)dataArray{
    if (!_dataArray) {
        _dataArray = [NSMutableArray array];
    }
    return _dataArray;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.dataArray.count;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    _listCell = [tableView dequeueReusableCellWithIdentifier:identifyString];
    if (!_listCell) {
        _listCell = [[JCGendanListTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifyString];
        _listCell.selectionStyle = 0;
    }
    JCgendanListModel *model = self.dataArray[indexPath.row];
    _listCell.model = model;
    return _listCell;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
}
-(void)loadView
{
    self.titleView = [[JCTitleView alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, StatusBarAndNavigationBarHeight) titleLabel:@"跟单列表"];
    self.titleView.delegate = self;
    self.view = self.titleView;
}
- (void)clickPopBtnAction:(UIButton *)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}
- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"跟单列表";
    [self.view addSubview:self.tableView];
    self.tableView.mj_header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
         [self requestDataIsNewRefresh:YES];
    }];
    self.tableView.mj_footer = [MJRefreshBackFooter footerWithRefreshingBlock:^{
         [self requestDataIsNewRefresh:NO];
    }];
     [self requestDataIsNewRefresh:YES];
    
}
- (void)requestDataIsNewRefresh:(BOOL)isNewfresh
{
    //    NSDictionary *dict = [NSDictionary dictionary];
    NSString *urlString = [JCAllUrl gendanListUrl];
//    int page = self.dataArray.count%fetchSize > 0?(int)self.dataArray.count/fetchSize+1:(int)self.dataArray.count/fetchSize;
    if (isNewfresh) {
        _page = 1;
    }else{
        _page += 1;
    }
    
    NSDictionary *dict = @{@"schemeId" : @(_schemeId),
                           @"fetchSize" : @(fetchSize),
                           @"firstRow" : @(_page)
                           };

    __weak typeof (self) weakSelf = self;
    [JCRequestNetWork getWithUrlString:urlString parameters:dict success:^(id data) {
        
        NSDictionary *dataDic = (NSDictionary *)[NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableLeaves error:nil];
        if ([dataDic[@"flag"] integerValue] == 1) {
            NSArray *array =dataDic[@"list"];
            JCLog(@"array -- %lu", (unsigned long)array.count);
            if (array.count>0 &&isNewfresh) {
                [weakSelf.dataArray removeAllObjects];
            }
            if (array.count>0 && array.count<fetchSize) {
                [weakSelf.tableView.mj_header endRefreshing];
                [weakSelf.tableView.mj_footer endRefreshingWithNoMoreData];
               
            }else{
                [weakSelf.tableView.mj_header endRefreshing];
                [weakSelf.tableView.mj_footer endRefreshing];
            }
            for (NSDictionary *dictionary in array) {
                //                JCGendanCenterListModel *model = [[JCGendanCenterListModel alloc]init];
                JCgendanListModel *model = [JCgendanListModel yy_modelWithDictionary:dictionary];
                //                [model setValuesForKeysWithDictionary:dictionary];
                [weakSelf.dataArray addObject:model];
            }
            dispatch_async(dispatch_get_main_queue(), ^{
                [weakSelf.tableView reloadData];
            });
            
        }else{
            [weakSelf.tableView.mj_header endRefreshing];
            [weakSelf.tableView.mj_footer endRefreshing];
        }
        
    } failure:^(NSError *error) {
        [weakSelf.tableView.mj_header endRefreshing];
        [weakSelf.tableView.mj_footer endRefreshing];
    } showView:nil];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
