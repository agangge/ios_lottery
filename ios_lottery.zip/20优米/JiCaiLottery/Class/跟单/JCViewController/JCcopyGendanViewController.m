//
//  JCcopyGendanViewController.m
//  JiCaiLottery
//
//  Created by Peng Jun on 2017/11/24.
//  Copyright © 2017年 JiCaiLottery. All rights reserved.
//

#import "JCcopyGendanViewController.h"
#import "JCHeader.h"
#import "JCcopygendanView.h"
#import "JCGendanCopyModel.h"
@interface JCcopyGendanViewController ()<JCTitleViewDelegate>
@property (nonatomic, strong)JCTitleView *titleView;
@property (nonatomic, strong)JCcopygendanView *mainview;
@property (nonatomic, assign)__block NSInteger Beishu;
@property (nonatomic, strong)JCGendanCopyModel *model;
@end

@implementation JCcopyGendanViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = UICOLOR_HEX(0xf0f0f0);
    self.title = @"复制跟单";
    __weak typeof (self) weakSelf = self;
    self.mainview = [[JCcopygendanView alloc]initWithFrame:CGRectMake(0, StatusBarAndNavigationBarHeight, ScreenWidth, 300)];
    _Beishu = 1;
    


    self.mainview.numberButton.resultBlock = ^(PPNumberButton *ppBtn, CGFloat number, BOOL increaseStatus) {
        JCLog(@"number = %ld ",(long)number);
        JCLog(@"%@",increaseStatus ? @"加运算":@"减运算");
        
        weakSelf.Beishu = number;
        NSInteger dangeiJine = [weakSelf.model.singleMultipleMoney integerValue];
        JCLog(@"dangeiJine = %ld ",(long)dangeiJine);
        weakSelf.mainview.jineLabel.text =[NSString stringWithFormat:@"%.f",(dangeiJine * number)];
    };
    
    
    [self.view addSubview:self.mainview];
    
    UIButton *sureButton = [[UIButton alloc] initWithFrame:CGRectMake(0, ScreenHeight -TabbarSafeBottomMargin -49 , ScreenWidth, 49)];
    sureButton.backgroundColor = allRedColor;
    [sureButton setTitle:@"立即跟单" forState:UIControlStateNormal];
    [sureButton setTitleColor:allWhiteColor forState:UIControlStateNormal];
    sureButton.titleLabel.font = FONT(18);
    [sureButton addTarget:self action:@selector(sureGendanAction:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:sureButton];
    [self requestData];
    // Do any additional setup after loading the view.
}

#pragma mark - UI创建
-(void)loadView
{
    
    self.titleView = [[JCTitleView alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, StatusBarAndNavigationBarHeight) titleLabel:@"复制跟单"];
    self.view = self.titleView;
    self.titleView.delegate = self;
}
#pragma mark - 立即跟单
- (void)sureGendanAction:(UIButton *)button{
    [self gendanTodoRequest];
}
- (void)requestData{
    NSString *urlString = [JCAllUrl gendanCopyUrl];
    NSDictionary *dict = @{@"schemeId" : @(_schemeId)};
    __weak typeof (self) weakSelf = self;
    [JCRequestNetWork getWithUrlString:urlString parameters:dict success:^(id data) {
        
        NSDictionary *dataDic = (NSDictionary *)[NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableLeaves error:nil];
        if ([dataDic[@"flag"] integerValue] == 1) {
            
             weakSelf.model = [JCGendanCopyModel yy_modelWithDictionary:dataDic];
            weakSelf.mainview.model = weakSelf.model;
        }else{

        }
        
    } failure:^(NSError *error) {

    } showView:nil];
}
- (void)gendanTodoRequest{
    __weak typeof(self)weakSelf = self;
    NSString *urlString = [JCAllUrl gendanTodoCopyUrl];
    NSDictionary *dict = @{@"schemeId" : @(_schemeId),
                           @"multiple":@(_Beishu)
                           };
    [JCRequestNetWork getWithUrlString:urlString parameters:dict success:^(id data) {
        
        NSDictionary *dataDic = (NSDictionary *)[NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableLeaves error:nil];
        if ([dataDic[@"flag"] integerValue] == 1) {
            jxt_showAlertOneButton(@"提示", @"跟单成功", @"确定", ^(NSInteger buttonIndex) {
                [weakSelf.navigationController popViewControllerAnimated:YES];
            });
        }else{
            
            jxt_showAlertOneButton(@"提示", dataDic[@"errorMessage"], @"确定", ^(NSInteger buttonIndex) {
                
            });
        }
        
    } failure:^(NSError *error) {
        
    } showView:nil];
    
}
- (void)clickPopBtnAction:(UIButton *)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    [self.view endEditing:YES];
}
- (void)textFieldChanged:(UITextField *)textField
{

    if ([textField.text intValue] > 99999) {
        textField.text = @"99999";
//        jxt_showAlertTitle(@"倍数最大为99999");
    } else {
        JCLog(@"大于999999");
        
        
    }
    JCLog(@"%@",textField.text);
    _Beishu = [textField.text integerValue];
    NSInteger dangeiJine = [self.model.singleMultipleMoney integerValue];
    self.mainview.jineLabel.text =[NSString stringWithFormat:@"%ld",(dangeiJine * _Beishu)];
    
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
