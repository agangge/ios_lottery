//
//  JCGendanViewController.h
//  JiCaiLottery
//
//  Created by Peng Jun on 2017/11/22.
//  Copyright © 2017年 JiCaiLottery. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface JCGendanViewController : UIViewController
@property (nonatomic, assign) BOOL closeAnimating; //隐藏navigationbar
@end
