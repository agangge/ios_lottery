//
//  JCGendanChartsViewController.h
//  JiCaiLottery
//
//  Created by Peng Jun on 2018/5/22.
//  Copyright © 2018年 JiCaiLottery. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface JCGendanChartsViewController : UIViewController
@property (nonatomic, assign)NSInteger chartType; //1.盈利。2.命中。 3 奖金
@end
