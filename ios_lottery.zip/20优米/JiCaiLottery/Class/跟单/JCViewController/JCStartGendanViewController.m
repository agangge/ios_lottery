//
//  JCStartGendanViewController.m
//  JiCaiLottery
//
//  Created by Peng Jun on 2017/11/23.
//  Copyright © 2017年 JiCaiLottery. All rights reserved.
//

#import "JCStartGendanViewController.h"
#import "JCHeader.h"
#import "JCStartGendanGKTableViewCell.h"
#import "JCStartGendanMSTableViewCell.h"
#import "JCStartGendanTCTableViewCell.h"
@interface JCStartGendanViewController ()<UITableViewDelegate,UITableViewDataSource,JCTitleViewDelegate,UIScrollViewDelegate>
@property (nonatomic, strong)NSMutableArray *dataArray;
@property (nonatomic, strong)UITableView *tableView;
@property (nonatomic, strong)JCTitleView *titleView;
@property (nonatomic, assign)__block NSInteger fananIndex;
@property (nonatomic, assign)__block NSInteger tichengIndex;
@property (nonatomic, strong)__block NSString *miaoshuText;
@property (nonatomic, copy)NSString *danbeiJIne;
@end

@implementation JCStartGendanViewController

- (UITableView *)tableView{
    if (!_tableView) {
        _tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, StatusBarAndNavigationBarHeight, ScreenWidth, ScreenHeight-49-StatusBarAndNavigationBarHeight) style:UITableViewStylePlain];
        _tableView.delegate = self;
        _tableView.dataSource = self;
        _tableView.allowsSelection = NO;
        _tableView.separatorStyle =UITableViewCellSeparatorStyleNone;
        
        
    }
    return _tableView;
}

- (NSMutableArray *)dataArray{
    if (!_dataArray) {
        _dataArray = [NSMutableArray array];
    }
    return _dataArray;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return 3;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    if (indexPath.row == 0) {
        
        JCStartGendanGKTableViewCell *gkcell = [[JCStartGendanGKTableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"gkcell"];
        gkcell.danbeiJine = _danbeiJIne;
        //        @"方案金额  2注  1倍 1期  共%@元",_danbeiJine];
        gkcell.topLabel.text = [NSString stringWithFormat:@"方案金额  %@注  %@倍  共%@元", _zhushuString, _jibeiString, _danbeiJIne];
        gkcell.topLabel.attributedText = [UILabel changeHemaiTextString:gkcell.topLabel.text labelString1:nil labelString2:_zhushuString labelString3:_jibeiString labelString4:_danbeiJIne];
        //        NSMutableAttributedString *att = [att ]
        gkcell.gkBlcok = ^(NSString *buttonString, NSInteger buttonIndex) {
            _fananIndex = buttonIndex;
            JCLog(@"是否公开");
            JCLog(@"buttonString = %@ buttonIndex =  %lD",buttonString,(long)_fananIndex);
        };
        return gkcell;
        
    }else if (indexPath.row == 1){
        JCLog(@"方案提成");
        JCStartGendanTCTableViewCell *tccell = [[JCStartGendanTCTableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"tccell"];
        tccell.tcBlcok = ^(NSString *buttonString, NSInteger buttonIndex) {
            _tichengIndex = buttonIndex;
            JCLog(@"%@%lD",buttonString,(long)_tichengIndex);
        };
        return tccell;
    }else{
        JCStartGendanMSTableViewCell *mscell = [[JCStartGendanMSTableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"mscell"];
        mscell.msBlcok = ^(NSString *buttonString) {
            
            JCLog(@"%@",buttonString);
            if (buttonString.length>0) {
                _miaoshuText = [JCTool removeSpaceAndNewline:buttonString];
            }else{
                _miaoshuText = buttonString;
            }
            JCLog(@"%@",_miaoshuText);
        };
        return mscell;
    }
    
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    CGFloat rowheight = 0.0;
    switch (indexPath.row) {
            case 0:
            rowheight = 165;
            break;
            case 1:
            rowheight = 240;
            break;
            case 2:
            rowheight = 220;
            break;
            
        default:
            break;
    }
    return rowheight;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
}


-(void)loadView
{
    //    self.navigationController.navigationBar.hidden = YES;
    self.titleView = [[JCTitleView alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, StatusBarAndNavigationBarHeight) titleLabel:@"发起跟单"];
    self.titleView.delegate = self;
    self.view = self.titleView;
}
- (void)clickPopBtnAction:(UIButton *)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}
- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self.view addSubview:self.tableView];
    UIButton *sureButton = [[UIButton alloc] initWithFrame:CGRectMake(0, ScreenHeight -TabbarSafeBottomMargin -49 , ScreenWidth, 49)];
    sureButton.backgroundColor = allRedColor;
    _fananIndex = 103;
    _tichengIndex = 100;
    [sureButton setTitle:@"立即跟单" forState:UIControlStateNormal];
    [sureButton setTitleColor:allWhiteColor forState:UIControlStateNormal];
    sureButton.titleLabel.font = FONT(18);
    [sureButton addTarget:self action:@selector(sureGendanAction:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:sureButton];
    [self requestData];
    
    
}

#pragma mark - 确定发起跟单
- (void)sureGendanAction:(UIButton *)button{
    if (_tichengIndex==0||_fananIndex==0) {
        jxt_showAlertOneButton(@"提示", @"请填完数据", @"确定", ^(NSInteger buttonIndex) { });
    }else{
        //        jxt_showAlertTitle([NSString stringWithFormat:@"%@",_miaoshuText]);
        [self requestSureAction];
    }
    
    NSLog(@"立即跟单");
}
- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    [self.view endEditing:YES];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (void)requestSureAction{
    
    NSString *urlString = [JCAllUrl gendanToPubilishUrl];
    NSDictionary *dict = @{@"schemeId" : @([_schemeId integerValue]),
                           @"sopen":@(_fananIndex -99),
                           @"remuneration":@(_tichengIndex -99),
                           @"sdescribe":_miaoshuText?_miaoshuText:@"",
                           };
    
    //    __weak typeof (self) weakSelf = self;
    [JCRequestNetWork getWithUrlString:urlString parameters:dict success:^(id data) {
        __weak typeof(self)weakSelf = self;
        NSDictionary *dataDic = (NSDictionary *)[NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableLeaves error:nil];
        if ([dataDic[@"flag"] integerValue] == 1) {
            //            jxt_showAlertTitle(@"发布成功");
            //            jxt_showAlertMessage(@"发布成功");
            jxt_showToastTitleDismiss(@"发布成功", 0.5, ^(NSInteger buttonIndex) {
                [weakSelf.navigationController popViewControllerAnimated:YES];
            });
            
        }
        else{
            jxt_showAlertTitle(dataDic[@"errorMessage"]);
        }
        
    } failure:^(NSError *error) {
        
        
    } showView:nil];
}
- (void)requestData{
    
    NSString *urlString = [JCAllUrl gendanEditPageUrl];
    NSDictionary *dict = @{@"schemeId" : @([_schemeId integerValue]),
                           };
    
    __weak typeof (self) weakSelf = self;
    [JCRequestNetWork getWithUrlString:urlString parameters:dict success:^(id data) {
        
        NSDictionary *dataDic = (NSDictionary *)[NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableLeaves error:nil];
        if ([dataDic[@"flag"] integerValue] == 1) {
            weakSelf.danbeiJIne =[dataDic[@"singleMultipleMoney"] stringValue] ;
            
            
            [_tableView reloadData];
        }
        else{
            jxt_showAlertOneButton(@"提示", dataDic[@"errorMessage"], @"确定", ^(NSInteger buttonIndex) {
                [weakSelf.navigationController popViewControllerAnimated:YES];
            });
        }
        
    } failure:^(NSError *error) {
        
        
    } showView:nil];
}

@end
