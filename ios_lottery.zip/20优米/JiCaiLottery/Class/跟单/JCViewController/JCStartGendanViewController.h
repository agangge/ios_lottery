//
//  JCStartGendanViewController.h
//  JiCaiLottery
//
//  Created by Peng Jun on 2017/11/23.
//  Copyright © 2017年 JiCaiLottery. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface JCStartGendanViewController : UIViewController
@property (nonatomic, copy)NSString *schemeId;
@property (nonatomic, copy)NSString *jibeiString;
@property (nonatomic, copy)NSString *zhushuString;
@end
