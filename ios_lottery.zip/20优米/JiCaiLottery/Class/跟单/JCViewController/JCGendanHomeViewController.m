//
//  JCGendanViewController.m
//  JiCaiLottery
//
//  Created by Peng Jun on 2017/11/22.
//  Copyright © 2017年 JiCaiLottery. All rights reserved.
//

#import "JCGendanHomeViewController.h"
#import "JCGendanTableViewCell.h"
#import "JCGendanCenterListModel.h"
#import "JCHeader.h"
#import "MJRefresh.h"
#import "JCSearchView.h"
#import "JCTitleButton.h"
#import "JCGendanPopView.h"
#import "JCcopyGendanViewController.h"
#import "JCStartGendanViewController.h"
#import "JCGendanOrderDetailViewController.h"
#import "JCGendanListViewController.h"
#import "JCGendanNewDetailViewController.h"
#import "JCLoginViewController.h"
#import "JCGendanNumberDetailViewController.h"
#import "JCGendanDSHomeTableViewCell.h"
#import "JCGendanHomeHeadView.h"
#import "JCGendanDatingTableViewCell.h"
#import "JCGendanSectionHeadView.h"
#import "JCGendanChartsViewController.h"
#import "JCGendanDShomeViewController.h"
#import "MOTMutablePopView.h"
#import "JCMyFocusViewController.h"
static int const fetchSize = 10;
static NSString *const CELLIDENTIFY = @"gendanCell";
@interface JCGendanHomeViewController ()<UITableViewDelegate,UITableViewDataSource,JCSearchViewDelegate,UITextFieldDelegate,JCGendanSectionHeadViewDelegate>
@property (nonatomic, strong)UITableView *tableView;
@property (nonatomic, strong)NSMutableArray *dataArray;
@property (nonatomic, strong)JCGendanDatingTableViewCell *gendanCell;
@property (nonatomic, strong)JCSearchView *searchView;
@property (nonatomic, strong)UIButton *mengButtonView;
@property (nonatomic, strong)UIView *shadowView;
@property (nonatomic, strong)UIView *selectedView;
@property (nonatomic, strong)JCGendanPopView *popView;
@property (nonatomic, strong)UIButton *titleBtn;
@property (nonatomic, assign)NSInteger rankTypeButtonIndex;
@property (nonatomic, strong)JCGendanHomeHeadView *bangdanView;
@property (nonatomic, strong)JCGendanSectionHeadView *listHeadView;
@end

@implementation JCGendanHomeViewController{
    
    BOOL isSearch;
    int _page;
}
- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    NSString *isLogin = [UserDefaults objectForKey:@"isLogin"];
    if ([isLogin intValue] == 0) {
        JCLoginViewController *jcLoginVC = [[JCLoginViewController alloc]init];
        [self presentViewController:jcLoginVC animated:YES completion:nil];
        return;
    }

}

- (void)viewDidDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    //    [self.navigationController setNavigationBarHidden:YES animated:self.closeAnimating]; // 纯色的navigationbar加载会有问题
}
- (JCGendanHomeHeadView*)bangdanView{
    if (!_bangdanView) {
        _bangdanView = [[JCGendanHomeHeadView alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, 118+40+146.5+10)];
//        _bangdanView.dSArray = @[@"1",@"1",@"1",@"1",@"1",@"1",@"1"];
        __weak typeof(self)weakself = self;
        _bangdanView.bangdanBlcok = ^(NSInteger tag) {
            NSLog(@"%ld",tag);
            if (tag < 10) {
                
                if (tag ==4) {
                    
                    // [JCPopObject showMessage:@"我的关注在哪啦"];
                    JCMyFocusViewController *vc = [[JCMyFocusViewController alloc]init];
                    
                    [weakself.navigationController pushViewController:vc animated:YES];
                    return ;
                }
                JCGendanChartsViewController *chart = [[JCGendanChartsViewController alloc]init];
                chart.chartType = tag;
                [weakself.navigationController pushViewController:chart animated:YES];
            }else{
                JCGendanDShomeViewController *dsVC = [[JCGendanDShomeViewController alloc]init];
                NSDictionary *dic = weakself.bangdanView.dSArray[tag -100];
                dsVC.dashengUserId =[[dic objectForKey:@"userId"] intValue];
                [weakself.navigationController pushViewController:dsVC animated:YES];
            }
           
            
        };
    }
    return _bangdanView;
}
- (UITableView *)tableView{
    if (!_tableView) {
        if (iPhoneX) {
            _tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 24, ScreenWidth, ScreenHeight-TabbarSafeBottomMargin-TabbarHeight) style:UITableViewStylePlain];
        }else{
            _tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, ScreenWidth, ScreenHeight-TabbarHeight-10) style:UITableViewStylePlain];
        }
        _tableView.separatorInset=UIEdgeInsetsMake(0,0, 0, 0);
    _tableView.separatorStyle=UITableViewCellSeparatorStyleSingleLine;
        _tableView.separatorColor = UICOLOR_HEX(0xeeeeee);
        _tableView.delegate = self;
        _tableView.dataSource = self;
        _tableView.tableHeaderView = self.bangdanView;
        _tableView.tableFooterView = [[UIView alloc] initWithFrame:CGRectZero];
       
        _tableView.rowHeight = UITableViewAutomaticDimension;
         _tableView.estimatedRowHeight = 175+50+50;
        
    }
    return _tableView;
}


- (NSMutableArray *)dataArray{
    if (!_dataArray) {
        _dataArray = [NSMutableArray array];
    }
    return _dataArray;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.dataArray.count;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    __weak typeof(self)wealself = self;
    _gendanCell = [tableView dequeueReusableCellWithIdentifier:CELLIDENTIFY];
    if (!_gendanCell) {
        _gendanCell = [[JCGendanDatingTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CELLIDENTIFY];
        _gendanCell.selectionStyle = UITableViewCellSelectionStyleNone;
        wealself.gendanCell.gdBlcok = ^(NSInteger schemeId){
            //            JCGendanListViewController *vc =[[JCGendanListViewController alloc]init];
            JCcopyGendanViewController *vc = [[JCcopyGendanViewController alloc]init];
            vc.schemeId = schemeId;
            [wealself.navigationController pushViewController:vc animated:YES];
        };
        wealself.gendanCell.gdIconBlcok = ^(NSInteger schemeId){
            //            JCGendanListViewController *vc =[[JCGendanListViewController alloc]init];
            JCGendanDShomeViewController *vc = [[JCGendanDShomeViewController alloc]init];
            vc.dashengUserId = (int)schemeId;
            [wealself.navigationController pushViewController:vc animated:YES];
        };
    }
    JCGendanCenterListModel *model = self.dataArray[indexPath.row];
    _gendanCell.model = model;
    
    
    return _gendanCell;
}
- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{
    _listHeadView =[[JCGendanSectionHeadView alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, 40)];
  
    _listHeadView.redlineView.hidden = NO;
    _listHeadView.lineView.hidden = YES;
    //    _listHeadView.titleLabel.text = @"跟单列表";
    _listHeadView.rankTypeButtonIndex = _rankTypeButtonIndex;
   
    _listHeadView.delegate = self;
    return _listHeadView;
}
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    return 40;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 200;;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    NSString *isLogin = [UserDefaults objectForKey:@"isLogin"];
    if ([isLogin intValue] == 0) {
        //未登录将tabbar的selectedIndex设置为之前选择的selectedIndex
        JCLoginViewController *jcLoginVC = [[JCLoginViewController alloc]init];
        [self presentViewController:jcLoginVC animated:YES completion:nil];
        return;
    }
    NSString *clientUserSession = [UserDefaults objectForKey:@"clientUserSession"];
    if (self.dataArray.count != 0) {
        
        if ([clientUserSession isEqualToString:@""]) {
            [JCPopObject showMessage:@"请登录账号！"];
        } else {
            JCGendanCenterListModel *model = self.dataArray[indexPath.row];
            if ([model.lotteryName isEqualToString:@"竞彩足球"] || [model.lotteryName isEqualToString:@"竞彩篮球"] || [model.lotteryName isEqualToString:@"北京单场"]) {
                JCGendanNewDetailViewController *vc = [[JCGendanNewDetailViewController alloc]init];
                vc.schemeId = model.schemeId;
                vc.isShowGendanButton = YES;
                [self.navigationController pushViewController:vc animated:YES];
                  JCLog(@"进入 JCGendanNewDetailViewController");
            } else {
                JCGendanNumberDetailViewController *vc = [[JCGendanNumberDetailViewController alloc]init];
                vc.schemeId = model.schemeId;
                vc.isShowGendanButton = YES;
                [self.navigationController pushViewController:vc animated:YES];
                 JCLog(@"进入 JCGendanNumberDetailViewController");
            }
        }
    }
}
- (void)viewDidLoad {
    
    [super viewDidLoad];
    
    [self.view addSubview:self.tableView];
    __weak typeof (self) weakSelf = self;
    
    self.tableView.mj_header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
        [weakSelf requestDataIsNewRefresh:YES];
    }];
     [self.tableView.mj_header beginRefreshing];
    self.tableView.mj_footer = [MJRefreshBackNormalFooter footerWithRefreshingBlock:^{
        [weakSelf requestDataIsNewRefresh:NO];
    }];
    [self.tableView.mj_footer beginRefreshing];
//    _rankTypeButtonIndex = 0;
        _rankTypeButtonIndex = 7;
//    [self initWithTitleButton];
    [self initWithSearchButton];
    [self requestDataIsNewRefresh:YES];
    
}
#pragma mark -- 请求数据
- (void)requestDataIsNewRefresh:(BOOL)isNewfresh{
    
    NSString *isLogin = [UserDefaults objectForKey:@"isLogin"];
    if ([isLogin intValue] == 0) {
        JCLoginViewController *jcLoginVC = [[JCLoginViewController alloc]init];
        [self presentViewController:jcLoginVC animated:YES completion:nil];
        return;
    }
    NSString *urlString = [JCAllUrl gendanGaibanCenterUrl];
    
    if (isNewfresh) {
        _page = 1;
        [self hotDasehgnRequest];
    }else{
        _page +=1;
    }
    
//    NSString *keyWord = [self.searchView.nameText.text stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    
    NSDictionary *dict = @{
                           @"type" : @(_rankTypeButtonIndex),
                           @"fetchSize" : @(fetchSize),
                           @"firstRow" : @(_page),
                           @"userName" : @"",
                           
                           };
    
    __weak typeof (self) weakSelf = self;
    
    [JCRequestNetWork getWithUrlString:urlString parameters:dict success:^(id data) {
        
        NSDictionary *dataDic = (NSDictionary *)[NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableLeaves error:nil];
        if ([dataDic[@"flag"] integerValue] == 1) {
            NSArray *array =dataDic[@"schemeList"];
            JCLog(@"array -- %lu", (unsigned long)array.count);
//            if (keyWord.length>0&&isNewfresh) {
//                if (array.count >0) {
//                     JCGendanDShomeViewController *dsVC = [[JCGendanDShomeViewController alloc]init];
////                    [weakSelf.dataArray removeAllObjects];
//                    NSDictionary *nnndic = array[0];
//                    NSNumber *uid = [nnndic objectForKey:@"userId"];
//
//                    dsVC.dashengUserId =[uid intValue];
//                    [self.navigationController pushViewController:dsVC animated:YES];
//                }else{
//                    [JCPopObject showMessage:@"暂无搜索结果"];
//                }
//                return;
////
//            }
//            if ((_rankTypeButtonIndex ==1)&&isNewfresh) {
//                 [weakSelf.dataArray removeAllObjects];
//            }
            if (array.count>0 &&isNewfresh) {
                [weakSelf.dataArray removeAllObjects];
            }
            if (array.count>0 && array.count<fetchSize) {
                [weakSelf.tableView.mj_header endRefreshing];
                [weakSelf.tableView.mj_footer endRefreshing];
                
            }else{
                [weakSelf.tableView.mj_header endRefreshing];
                [weakSelf.tableView.mj_footer endRefreshing];
            }
            for (NSDictionary *dictionary in array) {
                
                JCGendanCenterListModel *model = [JCGendanCenterListModel yy_modelWithDictionary:dictionary];
                [weakSelf.dataArray addObject:model];
            }
            dispatch_async(dispatch_get_main_queue(), ^{
                [weakSelf.tableView reloadData];
            });
            
        }else{
            
            [weakSelf.tableView.mj_header endRefreshing];
            [weakSelf.tableView.mj_footer endRefreshing];
            
            dispatch_async(dispatch_get_main_queue(), ^{
                weakSelf.searchView.nameText.text = @"";
                jxt_showToastTitleDismiss(dataDic[@"errorMessage"], 0.3, ^(NSInteger buttonIndex) {
                    
                });
            });
        }
    } failure:^(NSError *error) {
        [weakSelf.tableView.mj_header endRefreshing];
        [weakSelf.tableView.mj_footer endRefreshing];
    } showView:nil];
}
- (void)searchUserNamerequest:(NSString *)userName{
    
    
    NSString *urlString = [JCAllUrl gendansearchrUrl];
    
    
    //
        NSDictionary *dict = @{
                               @"username" : userName,
                              
    
                               };
    
    __weak typeof (self) weakSelf = self;
    
    [JCRequestNetWork getWithUrlString:urlString parameters:dict success:^(id data) {
        
        NSDictionary *dataDic = (NSDictionary *)[NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableLeaves error:nil];
        if ([dataDic[@"flag"] integerValue] == 1) {
            NSString *uid = [dataDic objectForKey:@"user_id"];
            JCGendanDShomeViewController *dsVC = [[JCGendanDShomeViewController alloc]init];
            ////                    [weakSelf.dataArray removeAllObjects];
            dsVC.dashengUserId =[uid intValue];
            [weakSelf.navigationController pushViewController:dsVC animated:YES];
        }else{
            
            
            
            
        }
    } failure:^(NSError *error) {
        
        
    } showView:nil];
}
- (void)hotDasehgnRequest{
    

    NSString *urlString = [JCAllUrl gendanHotDasheng];
    

//    
//    NSDictionary *dict = @{
//                           @"type" : @(_rankTypeButtonIndex),
//                           @"fetchSize" : @(fetchSize),
//                           @"firstRow" : @(_page),
//                        
//                           };
    
    __weak typeof (self) weakSelf = self;
    
    [JCRequestNetWork getWithUrlString:urlString parameters:nil success:^(id data) {
        
        NSDictionary *dataDic = (NSDictionary *)[NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableLeaves error:nil];
        if ([dataDic[@"flag"] integerValue] == 1) {
            NSArray *arr = [dataDic objectForKey:@"hotRecommendor"];
            if (arr.count > 0) {
                dispatch_async(dispatch_get_main_queue(), ^{
                    
                    _bangdanView.dSArray = [arr copy];
                });
            }
        }else{
            
            [weakSelf.tableView.mj_header endRefreshing];
            
         
        }
    } failure:^(NSError *error) {
        [weakSelf.tableView.mj_header endRefreshing];
        
    } showView:nil];
}


- (void)initWithSearchButton{
    UIBarButtonItem *searchBtn = [[UIBarButtonItem alloc]initWithImage:[UIImage imageNamed:@"search.png"] style:(UIBarButtonItemStylePlain) target:self action:@selector(searchAction:)];
    NSArray *array = @[searchBtn];

    self.navigationItem.rightBarButtonItems = array;
}
#pragma mark -- 模糊搜索
- (void)searchAction:(UIBarButtonItem *)sender
{
    [self.popView removeFromSuperview];
    self.titleBtn.selected = NO;

    JCLog(@"search");
    [self.view addSubview:self.mengButtonView];
    if (!self.searchView) {
        self.searchView = [[JCSearchView alloc]initWithFrame:CGRectMake(0, StatusBarAndNavigationBarHeight, ScreenWidth, 60)];
    }

    self.searchView.backgroundColor = ColorRGB(247, 247, 247, 1);
    self.searchView.delegate = self;
    [self.searchView.nameText becomeFirstResponder];
    self.searchView.nameText.delegate = self;
    [UIView animateWithDuration:0.3 animations:^{
        [self.view addSubview:self.searchView];
    } completion:^(BOOL finished) {

    }];
}
#pragma mark -- UITextFieldDelegate
- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    if ([string isEqualToString:@"\n"]) {  //如果 serch触发了 输入\n 判断 取消键盘
        [textField resignFirstResponder];
        //添加搜索方法；
        [self clieckSearchButton];
        [self.searchView removeFromSuperview];
        [self.mengButtonView removeFromSuperview];

        return NO;
    }
    return YES;
}

- (void)clieckSearchButton
{
    isSearch = YES;
//    [self :YES];
    NSString *keyWord =self.searchView.nameText.text;
//    [self.searchView.nameText.text stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    [self searchUserNamerequest:(keyWord.length>0?keyWord:@"")];
}

#pragma mark -- JCSearchViewDelegate
- (void)clickDisMissBtn:(UIButton *)sender
{
    [self.mengButtonView removeFromSuperview];
    [self.searchView.nameText resignFirstResponder];
    [self.searchView removeFromSuperview];
}
- (void)clickPopViewButton:(UIButton *)sender{
    //    sender.selected = !sender.selected;
    NSInteger btntag = sender.tag;
    [self.dataArray removeAllObjects];
    if (btntag ==100) {
        _rankTypeButtonIndex = 9;
    }else if(btntag ==101){
        _rankTypeButtonIndex = 8;
    }else if (btntag ==102){
        _rankTypeButtonIndex = 7;
    }
    //    [self.tableView.mj_header beginRefreshing];
    //    - (void)requestDataIsNewRefresh:(BOOL)isNewfresh
    [self requestDataIsNewRefresh:YES];
    
}
- (void)mengButtonViewAction:(UIButton *)sender
{
    [self.mengButtonView removeFromSuperview];
    [self.searchView.nameText resignFirstResponder];
    [self.searchView removeFromSuperview];
}
- (UIButton *)mengButtonView
{
    if (!_mengButtonView) {
        _mengButtonView = [UIButton buttonWithType:(UIButtonTypeCustom)];
        _mengButtonView.frame = CGRectMake(0, 0, ScreenWidth, ScreenHeight);
        _mengButtonView.backgroundColor = [UIColor blackColor];
        _mengButtonView.alpha = 0.5;
        [_mengButtonView addTarget:self action:@selector(mengButtonViewAction:) forControlEvents:(UIControlEventTouchUpInside)];
    }
    return _mengButtonView;
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}


@end
