//
//  JCGendanOrderDetailViewController.m
//  JiCaiLottery
//
//  Created by Peng Jun on 2017/11/24.
//  Copyright © 2017年 JiCaiLottery. All rights reserved.
//

#import "JCGendanOrderDetailViewController.h"
#import "JCHeader.h"
#import "JCGendanDetailHeadView.h"
#import "JCGendanDetailMessageCell.h"
#import "JCGendanDetailSportLoteryCell.h"
#import "JCGendanDetailNumberLoteryCell.h"
#import "JCGendanDetailHeaderView.h"
#import "JCNumberDeatilTableViewCell.h"
#import "JCAthleticsTableViewCell.h"
#import "JCNumberModel.h"
#import "JCNumberSchemeContentModel.h"
#import "JCAthleticsMatchesModel.h"
static NSString *const sportCellIdentify = @"sportCell";
static NSString *const numberCellIdentify = @"numberCell";
static NSString *const messageCellIdentify = @"messageCell";
@interface JCGendanOrderDetailViewController ()<UITableViewDelegate,UITableViewDataSource,JCTitleViewDelegate,UIScrollViewDelegate>
@property (nonatomic, strong)NSMutableArray *dataArray;
@property (nonatomic, strong)UITableView *tableView;
@property (nonatomic, strong)JCTitleView *titleView;
@property (nonatomic, strong)JCGendanDetailHeadView *headView;
@property (nonatomic, strong)JCGendanDetailSportLoteryCell *sportCell;
@property (nonatomic, strong)JCGendanDetailNumberLoteryCell *numberCell;
@property (nonatomic, strong)JCGendanDetailMessageCell *messageCell;
@property (nonatomic, strong)NSMutableArray *schemeContentArray;
@property (nonatomic, strong)NSMutableArray *matchesArray;
@end

@implementation JCGendanOrderDetailViewController
- (UITableView *)tableView{
    if (!_tableView) {
        _tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, StatusBarAndNavigationBarHeight, ScreenWidth, ScreenHeight-49-StatusBarAndNavigationBarHeight) style:UITableViewStylePlain];
        _tableView.delegate = self;
        _tableView.dataSource = self;
        _tableView.allowsSelection = NO;
        _tableView.separatorStyle =UITableViewCellSeparatorStyleNone;
        
    }
    _tableView.tableHeaderView = self.headView;
    return _tableView;
}
- (JCGendanDetailHeadView *)headView{
    if (!_headView) {
        _headView = [[JCGendanDetailHeadView alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, 100) dataArray:self.dataArray prize:@"头string"];
    }
    return _headView;
}

- (NSMutableArray *)dataArray{
    if (!_dataArray) {
        _dataArray = [NSMutableArray array];
    }
    return _dataArray;
}
- (NSMutableArray *)schemeContentArray{
    if (!_schemeContentArray) {
        _schemeContentArray = [NSMutableArray array];
    }
    return _schemeContentArray;
}
- (NSMutableArray *)matchesArray{
    if (!_matchesArray) {
        _matchesArray = [NSMutableArray array];
    }
    return _matchesArray;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
//    if (section == 0) {
//        return 1;
//    }else{
        return 1;
//    }
}
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 2;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    NSInteger lottery;
    if (indexPath.section == 0) {
        _messageCell = [tableView dequeueReusableCellWithIdentifier:messageCellIdentify];
        if (!_messageCell) {
            _messageCell = [[JCGendanDetailMessageCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:messageCellIdentify];
        }
        return _messageCell;
    }else if(indexPath.section == 1){
        if (lottery) {
//            JCNumberSchemeContentModel *model = [self.schemeContentArray objectAtIndex:indexPath.row];
            JCNumberDeatilTableViewCell *detailCell = [[JCNumberDeatilTableViewCell alloc]initWithStyle:(UITableViewCellStyleDefault) reuseIdentifier:@""];
//            detailCell.numberLabel.text = [NSString stringWithFormat:@"%@", model.number];
            if (indexPath.row != 0) {
//                detailCell.touLabel.hidden = YES;
            }
            
//            cell = detailCell;
            return detailCell;
        }else
        {
        _sportCell = [tableView dequeueReusableCellWithIdentifier:sportCellIdentify];
        if (!_sportCell) {
            _sportCell = [[JCGendanDetailSportLoteryCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:sportCellIdentify];
        }
       
    }
         return _messageCell;
    }
    return _messageCell;
}
- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{
    JCGendanDetailHeaderView *headerView = [[JCGendanDetailHeaderView alloc]initWithReuseIdentifier:@"header"];
    if (section == 0) {
        headerView.leftLabel.text = @"方案信息";
        headerView.loteryLabel.text = @"";
        headerView.zhushuLable.text =@"";
    }else{
        headerView.leftLabel.text = @"方案信息";
        headerView.loteryLabel.text = @"让球胜平负复式";
        headerView.zhushuLable.text =@"2注  1倍";
    }
    return headerView;
}
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    return 30;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    CGFloat rowheight = 170.0;
//    switch (indexPath.section) {
////        case 0:
////            rowheight = 64;
////            break;
//        case 0:
//            rowheight = 170;
//            break;
//        case 1:
//            rowheight = 52;
//            break;
//
//        default:
//            break;
//    }
    return rowheight;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
}
-(void)loadView
{
    //    self.navigationController.navigationBar.hidden = YES;
    self.titleView = [[JCTitleView alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, StatusBarAndNavigationBarHeight) titleLabel:@"详情"];
    self.titleView.delegate = self;
    self.view = self.titleView;
}
- (void)clickPopBtnAction:(UIButton *)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}
- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self.view addSubview:self.tableView];
    [self requestURL];
    
}
- (void)requestURL
{
    NSString *urlString = [JCAllUrl schemeDetailUrl];
    NSString *clientUserSession = [UserDefaults objectForKey:@"clientUserSession"];
    NSDictionary *dict = @{@"clientUserSession" : clientUserSession,
                           @"schemeId" : self.schemeId};
    [JCRequestNetWork postWithUrlString:urlString parameters:dict success:^(id data) {
        NSDictionary *dictionary = (NSDictionary *)[NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableLeaves error:nil];
//        [self.athleticTableView.mj_header endRefreshing];
        if ([[dictionary objectForKey:@"flag"] intValue] == 1) {
            JCNumberModel *model = [JCNumberModel mj_objectWithKeyValues:dictionary];
            [self.dataArray addObject:model];
            for (JCNumberSchemeContentModel *schemeContentModel in model.schemeContent) {
                [self.schemeContentArray addObject:schemeContentModel];
                for (JCAthleticsMatchesModel *matchModel in schemeContentModel.matches) {
                    [self.matchesArray addObject:matchModel];
                }
            }
        }
        dispatch_async(dispatch_get_main_queue(), ^{
//            [self.view addSubview:self.athleticTableView];
//            [self.athleticTableView reloadData];
        });
     
    } failure:^(NSError *error) {
//        [self.athleticTableView.mj_header endRefreshing];
        JCLog(@"error -- %@", error);
    } showView:nil];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
