//
//  JCGendanChartsViewController.m
//  JiCaiLottery
//
//  Created by Peng Jun on 2018/5/22.
//  Copyright © 2018年 JiCaiLottery. All rights reserved.
//

#import "JCGendanChartsViewController.h"
#import "JCTitleButton.h"
#import "JCHeader.h"
#import "MJRefresh.h"
//#import "JCGendanDSHomeTableViewCell.h"
#import "JCGendanChartTableViewCell.h"
#import "JCGendanRankModel.h"
#import "JCGendanDShomeViewController.h"
@interface JCGendanChartsViewController ()<UITableViewDelegate,UITableViewDataSource>
@property (nonatomic, strong)UITableView *tableView;
@property (nonatomic, strong)NSMutableArray *dataArray;
@property (nonatomic, strong)MBProgressHUD *hud;
@end

@implementation JCGendanChartsViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
    [self.view addSubview:self.tableView];
    if (_chartType == 1) {
        self.title = @"盈利榜";
    }else if (_chartType == 2){
        self.title = @"命中榜";
    }else if(_chartType == 3){
        self.title = @"奖金榜";
    }
    [self requestUrl];
    // Do any additional setup after loading the view.
}
- (UITableView *)tableView{
    if (!_tableView) {
        if (iPhoneX) {
            _tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 24, ScreenWidth, ScreenHeight-24) style:UITableViewStylePlain];
        }else{
            _tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, ScreenWidth, ScreenHeight) style:UITableViewStylePlain];
        }
        _tableView.backgroundColor = allBackGroundColor;
        _tableView.delegate = self;
        _tableView.dataSource = self;
        _tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
        _tableView.tableFooterView = [[UIView alloc] initWithFrame:CGRectZero];
        _tableView.rowHeight = UITableViewAutomaticDimension;
        _tableView.estimatedRowHeight = 100;
        
    }
    return _tableView;
}
//- (void)scrollViewDidScroll:(UIScrollView *)scrollView {
//
//    CGFloat sectionHeaderHeight = 10;
//    CGFloat sectionFooterHeight = 0.0001;
//    CGFloat offsetY = scrollView.contentOffset.y;
//    if (offsetY >= 0 && offsetY <= sectionHeaderHeight) {
//        scrollView.contentInset = UIEdgeInsetsMake(-offsetY, 0, -sectionFooterHeight, 0);
//    } else if (offsetY >= sectionHeaderHeight && offsetY <= scrollView.contentSize.height - scrollView.frame.size.height - sectionFooterHeight) {
//        scrollView.contentInset = UIEdgeInsetsMake(-sectionHeaderHeight, 0, -sectionFooterHeight, 0);
//    } else if (offsetY >= scrollView.contentSize.height - scrollView.frame.size.height - sectionFooterHeight && offsetY <= scrollView.contentSize.height - scrollView.frame.size.height) {
//        scrollView.contentInset = UIEdgeInsetsMake(-offsetY, 0, -(scrollView.contentSize.height - scrollView.frame.size.height - sectionFooterHeight), 0);
//    }
//}
- (NSMutableArray *)dataArray{
    if (!_dataArray) {
        _dataArray = [NSMutableArray array];
    }
    return _dataArray;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
//    return self.dataArray.count;
    return 1;
}
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return self.dataArray.count;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
//    __weak typeof(self)wealself = self;

    JCGendanChartTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"chartCell"];
    if (!cell) {
      
        cell = [[JCGendanChartTableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"chartCell"];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
    }
    JCGendanRankModel *model = self.dataArray[indexPath.section];
    [cell listModel:model listType:_chartType Rank:indexPath.section];
    return cell;
}
- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{
    UIView *view = [[UIView alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, 10)];
    view.backgroundColor = allBackGroundColor;
    return view;
}
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    return 10;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 55 *(ScreenScale>1?ScreenScale:1);
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    if (self.dataArray.count == 0) {
        return;
    }
    JCGendanRankModel *model = self.dataArray[indexPath.section];
    JCGendanDShomeViewController *vc = [[JCGendanDShomeViewController alloc]init];
    vc.dashengUserId = [model.userId intValue];
    [self.navigationController pushViewController:vc animated:YES];
}
- (void)requestUrl{
    
    
    NSString *urlString = [JCAllUrl gendanRank];
    
    
    
        NSDictionary *dict = @{
                               @"rankType" : @(_chartType - 1),

                               };
    
    __weak typeof (self) weakSelf = self;
    self.hud = [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    self.hud.label.text = @"正在加载";
    [JCRequestNetWork getWithUrlString:urlString parameters:dict success:^(id data) {
        
        NSDictionary *dataDic = (NSDictionary *)[NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableLeaves error:nil];
        if ([dataDic[@"flag"] integerValue] == 1) {
            NSArray *arr = [dataDic objectForKey:@"ranks"];
            if (arr.count > 0) {
                for (int i =0 ; i<arr.count; i++) {
                    JCGendanRankModel *model = [JCGendanRankModel yy_modelWithDictionary:arr[i]];
                    [weakSelf.dataArray addObject:model];
                }
            }
            dispatch_async(dispatch_get_main_queue(), ^{
                [weakSelf.tableView reloadData];
            });
            
        }else{
            [JCPopObject showMessage:dataDic[@"errorMessage"]];
//            dispatch_async(dispatch_get_main_queue(), ^{
//                [self.tableView reloadData];
//            });
//            [weakSelf.tableView.mj_header endRefreshing];
            
            
        }
        [self.hud hideAnimated:YES];
    } failure:^(NSError *error) {
        [self.hud hideAnimated:YES];
//        [weakSelf.tableView.mj_header endRefreshing];
        
    } showView:nil];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
