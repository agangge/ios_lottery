//
//  JCGendanTableViewCell.m
//  JiCaiLottery
//
//  Created by Peng Jun on 2017/11/22.
//  Copyright © 2017年 JiCaiLottery. All rights reserved.
//

#import "JCGendanTableViewCell.h"
#import "JCHeader.h"
#import "SDAutoLayout.h"
#import "JCGendanCenterListModel.h"
@interface JCGendanTableViewCell()
@property (nonatomic, strong)UIImageView *avatarImageView;
@property (nonatomic, strong)UILabel *nameLabel;
@property (nonatomic, strong)UIButton *focusButton;
@property (nonatomic, strong)UILabel *evaluateLabel;
@property (nonatomic, strong)UILabel *recentlyStatusLabel;
@property (nonatomic, strong)UILabel *limitTimeLabel;
@property (nonatomic, strong)UIButton *gendanButton;

@property (nonatomic, strong)UIView *bottomView;
@end
@implementation JCGendanTableViewCell


- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        [self createCell];
    }
    return self;
}

- (void)createCell{
    
    _avatarImageView = [[UIImageView alloc] init];
    _avatarImageView.layer.cornerRadius = 15;
    _avatarImageView.clipsToBounds = YES;
    _avatarImageView.image = [UIImage imageNamed:@"person_name"];
    
    _nameLabel = [[UILabel alloc] init];
    _nameLabel.font = FONT(18);
    _nameLabel.text = @"姓名";
    _nameLabel.textColor = UICOLOR_HEX(0x333333);
    
    _focusButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [_focusButton setTitle:@"+ 关注" forState: UIControlStateNormal];
    [_focusButton setTitle:@"已关注" forState: UIControlStateSelected];
    [_focusButton setBackgroundImage:[UIImage imageNamed:@"gendan_title_selected"] forState:UIControlStateNormal];
     [_focusButton setBackgroundImage:[UIImage imageNamed:@"lilun_normal"] forState:UIControlStateSelected];
    _focusButton.titleLabel.font = FONT(12);
    _focusButton.clipsToBounds = YES;
    _focusButton.layer.cornerRadius = 3;
    _focusButton.backgroundColor = allRedColor;
    [_focusButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [_focusButton addTarget:self action:@selector(focusAction:) forControlEvents:UIControlEventTouchUpInside];
    
    _evaluateLabel = [[UILabel alloc] init];
    _evaluateLabel.font = FONT(12);
    _evaluateLabel.text = @"评价";
    _evaluateLabel.numberOfLines = 0;
    _evaluateLabel.textColor = UICOLOR_HEX(0x333333);
    
    _recentlyStatusLabel = [[UILabel alloc] init];
    _recentlyStatusLabel.font = FONT(18);
    _recentlyStatusLabel.text = @"近期1中1";
    _recentlyStatusLabel.textAlignment = NSTextAlignmentRight;
    _recentlyStatusLabel.textColor = UICOLOR_HEX(0xE62F1A);
    
    _limitTimeLabel = [[UILabel alloc] init];
    _limitTimeLabel.font = FONT(10);
    _limitTimeLabel.textAlignment = NSTextAlignmentRight;
    _limitTimeLabel.text = @"11-18 20:00截止";
    _limitTimeLabel.textColor = UICOLOR_HEX(0x666666);
    
    _gendanButton= [UIButton buttonWithType:UIButtonTypeCustom];
    [_gendanButton setTitle:@"跟 单" forState: UIControlStateNormal];
    _gendanButton.titleLabel.font = FONT(13);
    _gendanButton.layer.cornerRadius = 2.f;
    _gendanButton.layer.borderColor = UICOLOR_HEX(0xE62F1A).CGColor;
    _gendanButton.layer.borderWidth = 0.5f;
    [_gendanButton setTitleColor:UICOLOR_HEX(0xE62F1A) forState:UIControlStateNormal];
    [_gendanButton addTarget:self action:@selector(gendanAction:) forControlEvents:UIControlEventTouchUpInside];
    [self createBottomView];

    [self.contentView addSubview:_avatarImageView];
    [self.contentView addSubview:_nameLabel];
    [self.contentView addSubview:_focusButton];
    [self.contentView addSubview:_evaluateLabel];
    [self.contentView addSubview:_recentlyStatusLabel];
    [self.contentView addSubview:_limitTimeLabel];
    [self.contentView addSubview:_gendanButton];
    [self.contentView addSubview:_bottomView];
    
    [_avatarImageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.left.equalTo(self.contentView).offset(15);
        make.size.mas_equalTo(CGSizeMake(30, 30));
    }];
    
    [_focusButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(_avatarImageView.mas_centerY);
        make.left.equalTo(_avatarImageView.mas_right).offset(10);
        make.size.mas_equalTo(CGSizeMake(50, 20));
    }];
    
    [_nameLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(_avatarImageView.mas_centerY);
        make.left.equalTo(_focusButton.mas_right).offset(10);
    }];
    
    [_evaluateLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(_avatarImageView.mas_bottom).offset(8);
        make.left.equalTo(_avatarImageView.mas_left);
        make.width.mas_equalTo(ScreenWidth*2/3);
        make.height.mas_greaterThanOrEqualTo(50);
    }];
    

    [_recentlyStatusLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.equalTo(self.contentView.mas_right).offset(-15);
        make.top.equalTo(self.contentView.mas_top).offset(15);
    }];
    

    [_limitTimeLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.equalTo(self.contentView.mas_right).offset(-15);
        make.top.equalTo(_recentlyStatusLabel.mas_bottom).offset(8);
    }];

    [_gendanButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.equalTo(self.contentView.mas_right).offset(-15);
        make.top.equalTo(_limitTimeLabel.mas_bottom).offset(8);
        make.size.mas_equalTo(CGSizeMake(90, 30));
    }];
    

    [self.bottomView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.equalTo(self.contentView.mas_bottom).offset(-10);
        make.centerX.equalTo(self.contentView.mas_centerX);
        make.width.mas_equalTo(ScreenWidth -30);
        make.height.mas_equalTo(75);
        make.top.equalTo(_evaluateLabel.mas_bottom).mas_offset(10);
//        make.top.mas_lessThanOrEqualTo(_evaluateLabel.mas_bottom)
    }];
    
    
}
- (UIView *)createBottomView{
    NSArray *arr = @[@"玩法",@"订单金额",@"跟单金额",@"参与人数",@"什么玩法呢",@"2元",@"20元",@"66人"];
    
        _bottomView = [[UIView alloc] init];
        _bottomView.backgroundColor = UICOLOR_HEX(0xf7f6f6);
        
        UILabel *leftLine = [[UILabel alloc] initWithFrame:CGRectMake((ScreenWidth-30), 0, 0.5, 75)];
        leftLine.backgroundColor = UICOLOR_HEX(0xcccccc);
        [_bottomView addSubview:leftLine];
        UILabel *topLine = [[UILabel alloc] initWithFrame:CGRectMake(0, 75, ScreenWidth - 30, 0.5)];
        topLine.backgroundColor = UICOLOR_HEX(0xcccccc);
        [_bottomView addSubview:topLine];
        for (int i = 0; i < 8; i++) {
            
            CGFloat x = (ScreenWidth -30)/4* (i%4);
            CGFloat y = i <4?0:30;
            CGFloat width =(ScreenWidth -30)/4;
            CGFloat height = i <4?30:45;
            UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(x, y, width, height)];
            label.text = arr[i];
            label.tag = i +96;
            label.font = FONT(12);
            label.textColor = UICOLOR_HEX(0x333333);
            label.textAlignment = NSTextAlignmentCenter;
            label.numberOfLines = 2;
            [_bottomView addSubview:label];
            
            UILabel *rightLine = [[UILabel alloc] initWithFrame:CGRectMake(x, y, 0.5, height)];
            rightLine.backgroundColor = UICOLOR_HEX(0xcccccc);
            UILabel *bottomLine = [[UILabel alloc] initWithFrame:CGRectMake(x, y, (ScreenWidth - 30)/4, 0.5)];
            bottomLine.backgroundColor = UICOLOR_HEX(0xcccccc);
            [_bottomView addSubview:rightLine];
            [_bottomView addSubview:bottomLine];
        }
    
    return _bottomView;
}
- (void)focusAction:(UIButton *)button{
    if (button.selected == NO) {
        [self foucuOnRequest:[JCAllUrl gendanCare_personUrl]];
    }else{
         [self foucuOnRequest:[JCAllUrl gendanCancel_care_personUrl]];
    }
//    if (self.fcBlcok) {
//        self.fcBlcok();
//    }
}
- (void)gendanAction:(UIButton *)button{
    if (self.gdBlcok) {
        self.gdBlcok([_model.schemeId integerValue]);
    }
}
- (void)setModel:(JCGendanCenterListModel *)model{
    _model = model;
    _nameLabel.text = _model.userName;
    _evaluateLabel.text = _model.sdescribe;
    _recentlyStatusLabel.text = _model.recentRecord;
    NSString *clipendtime = [_model.endTime substringFromIndex:5];
    NSString *endtime = [clipendtime substringToIndex:clipendtime.length - 3];
    _limitTimeLabel.text = [NSString stringWithFormat:@"%@截止",endtime];
    [_avatarImageView sd_setImageWithURL:[NSURL URLWithString:_model.avatar] placeholderImage:[UIImage imageNamed:@"person_name"]];
    _focusButton.selected = _model.isFollow;
    for (UILabel *label in _bottomView.subviews) {
        switch (label.tag) {
            case 100:
                label.text = _model.betDescription;
                break;
            case 101:
                label.text =[NSString stringWithFormat:@"%@元",_model.singleMultipleMoney];
                break;
            case 102:
                label.text =[NSString stringWithFormat:@"%@元",_model.followMoney];
                break;
            case 103:
                label.text =[NSString stringWithFormat:@"%@人",_model.participant];
                break;
                
            default:
                break;
        }
    }
    
}
- (void)foucuOnRequest:(NSString *)urlString{
    
    
    NSDictionary *dict = @{@"followUserId" : _model.userId,
                           };
    
//    __weak typeof (self) weakSelf = self;
    [JCRequestNetWork getWithUrlString:urlString parameters:dict success:^(id data) {
        
        NSDictionary *dataDic = (NSDictionary *)[NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableLeaves error:nil];
        if ([dataDic[@"flag"] integerValue] == 1) {
            _focusButton.selected = !_focusButton.selected;
            _model.isFollow = _focusButton.selected;
        }
        else{
            jxt_showAlertTitle(dataDic[@"errorMessage"]);
        }
        
    } failure:^(NSError *error) {
        
        
    } showView:nil];
}
- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
