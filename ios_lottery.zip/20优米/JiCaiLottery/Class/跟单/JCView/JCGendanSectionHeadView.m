//
//  JCListLotteryView.m
//  JiCaiLottery
//
//  Created by 风外杏林香 on 2017/5/18.
//  Copyright © 2017年 JiCaiLottery. All rights reserved.
//

#import "JCGendanSectionHeadView.h"
#import "JCHeader.h"
#import "ImageCenterButton.h"
#import "UIButton+Layout.h"
//#import "MOTMutablePopView.h"
@implementation JCGendanSectionHeadView

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        self.backgroundColor = [UIColor whiteColor];
        [self initWithUI];
    }
    return self;
}

- (void)initWithUI
{
    self.lineView = [[UIView alloc]init];
    self.lineView .backgroundColor = allRedColor;
    
    self.redlineView = [[UIView alloc]init];
    self.redlineView .backgroundColor = allRedColor;
    [self addSubview:self.redlineView];
    self.redlineView.hidden = YES;
    UIView *bottomLine = [[UIView alloc]init];
    bottomLine.backgroundColor = UICOLOR_HEX(0xeeeeee);
    
    self.titleLabel = [[UILabel alloc]init];
    self.titleLabel.textAlignment = NSTextAlignmentLeft;
    self.titleLabel.font = [UIFont systemFontOfSize:14.f];
    self.titleLabel.textColor =JCTTTColor;
    
    self.rightMiaoshuLabel = [[UILabel alloc]init];
    self.rightMiaoshuLabel.textAlignment = NSTextAlignmentRight;
    self.rightMiaoshuLabel.font = [UIFont systemFontOfSize:14.f];
    self.rightMiaoshuLabel.textColor =JCTTTColor;
    
    _reDSListbutton = [UIButton buttonWithType:UIButtonTypeCustom];
    _reDSListbutton.frame = CGRectMake(ScreenWidth - 80, 0, 120, 80);
    [_reDSListbutton setTitle:@"关注大神" forState:UIControlStateNormal];
    [_reDSListbutton setTitleColor:JCNNNColor forState:UIControlStateNormal];
    [_reDSListbutton setTitleColor:allRedColor forState:UIControlStateSelected];
    _reDSListbutton.titleLabel.font = FONT(16);
    _reDSListbutton.tag = 100;
    [_reDSListbutton addTarget:self action:@selector(buttonAction:) forControlEvents:UIControlEventTouchUpInside];
    [self addSubview:_reDSListbutton];
    
    _reJineListbutton = [UIButton buttonWithType:UIButtonTypeCustom];
    _reJineListbutton.frame = CGRectMake(ScreenWidth - 80, 0, 120, 80);
    [_reJineListbutton setTitle:@"发单金额" forState:UIControlStateNormal];
    [_reJineListbutton setTitleColor:JCNNNColor forState:UIControlStateNormal];
    _reJineListbutton.titleLabel.font = FONT(16);
    _reJineListbutton.tag = 102;
    [_reJineListbutton setTitleColor:allRedColor forState:UIControlStateSelected];
    [_reJineListbutton addTarget:self action:@selector(buttonAction:) forControlEvents:UIControlEventTouchUpInside];
    [self addSubview:_reJineListbutton];
    
    _reRSListbutton = [UIButton buttonWithType:UIButtonTypeCustom];
    _reRSListbutton.frame = CGRectMake(ScreenWidth - 80, 0, 120, 80);
    [_reRSListbutton setTitle:@"跟单人数" forState:UIControlStateNormal];
    [_reRSListbutton setTitleColor:JCNNNColor forState:UIControlStateNormal];
    [_reRSListbutton setTitleColor:allRedColor forState:UIControlStateSelected];
    _reRSListbutton.titleLabel.font = FONT(16);
    _reRSListbutton.tag = 101;
    [_reRSListbutton addTarget:self action:@selector(buttonAction:) forControlEvents:UIControlEventTouchUpInside];
    [self addSubview:_reRSListbutton];
    
    
    [self sd_addSubviews:@[self.lineView, self.titleLabel,bottomLine,_reDSListbutton,_reRSListbutton,_reJineListbutton,self.rightMiaoshuLabel]];
    
    self.lineView.sd_layout
    .leftSpaceToView(self, 20)
    .topSpaceToView(self, 10)
    .heightIs(20)
    .widthIs(2);
    
    self.titleLabel.sd_layout
    .leftSpaceToView(self.lineView, 10)
    .topSpaceToView(self, 5)
    .widthIs(ScreenWidth-200)
    .heightIs(30);
    
    self.rightMiaoshuLabel.sd_layout
    .rightSpaceToView(self, 20)
    .topSpaceToView(self, 5)
    .widthIs(ScreenWidth-200)
    .heightIs(30);
    
    bottomLine.sd_layout
    .leftSpaceToView(self, 0)
    .bottomSpaceToView(self, 0)
    .heightIs(0.5)
    .widthIs(ScreenWidth);
    
    [self.redlineView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.width.mas_equalTo(ScreenWidth /3);
        make.bottom.mas_equalTo(self.mas_bottom);
        make.left.mas_equalTo(self.mas_left);
        make.height.mas_equalTo(@2);
    }];
    
    //    self.arrowImage.sd_layout
    //    .rightSpaceToView(self, 20)
    //    .bottomSpaceToView(self, 16.5)
    //    .heightIs(9)
    //    .widthIs(15);
    
    _reDSListbutton.sd_layout
    .rightSpaceToView(self, 0)
    .bottomSpaceToView(self, 5)
    .heightIs(25)
    .widthIs(ScreenWidth /3);
    
    _reRSListbutton.sd_layout
    .rightSpaceToView(_reDSListbutton, 0)
    .bottomSpaceToView(self, 5)
    .heightIs(25)
    .widthIs(ScreenWidth /3);
    
    _reJineListbutton.sd_layout
    .rightSpaceToView(_reRSListbutton, 0)
    .bottomSpaceToView(self, 5)
    .heightIs(25)
    .widthIs(ScreenWidth /3);
}
- (void)buttonAction:(UIButton *)button{
    
    for (UIButton *dbutton in self.subviews) {
        if ([dbutton isKindOfClass:[UIButton class]]) {
            dbutton.selected = NO;
        }
    }
    button.selected = YES;
    NSInteger btag = button.tag;
    [self.redlineView mas_remakeConstraints:^(MASConstraintMaker *make) {
        make.width.mas_equalTo(ScreenWidth /3);
        make.bottom.mas_equalTo(self.mas_bottom);
        make.right.mas_equalTo(self.mas_right).offset(-ScreenWidth /3*(btag - 100));
        make.height.mas_equalTo(@2);
    }];
    
    if ([self.delegate respondsToSelector:@selector(clickPopViewButton:)]) {
        [self.delegate clickPopViewButton:button];
    }
    
    
}
- (void)setRankTypeButtonIndex:(NSInteger)rankTypeButtonIndex{
    _rankTypeButtonIndex = rankTypeButtonIndex;
    if (_rankTypeButtonIndex == 7) {
        _reJineListbutton.selected = YES;
        [self.redlineView mas_remakeConstraints:^(MASConstraintMaker *make) {
            make.width.mas_equalTo(ScreenWidth /3);
            make.bottom.mas_equalTo(self.mas_bottom);
            make.left.mas_equalTo(self.mas_left);
            make.height.mas_equalTo(@2);
        }];
        //        _reJineListbutton.layer.cornerRadius  = 4;
        //        _reJineListbutton.layer.borderColor = allRedColor.CGColor;
        //        _reJineListbutton.layer.borderWidth = 1;
    }else if (_rankTypeButtonIndex == 8){
        _reRSListbutton.selected = YES;
        [self.redlineView mas_remakeConstraints:^(MASConstraintMaker *make) {
            make.width.mas_equalTo(ScreenWidth /3);
            make.bottom.mas_equalTo(self.mas_bottom);
            make.left.mas_equalTo(self.mas_left).offset(ScreenWidth / 3);
            make.height.mas_equalTo(@2);
        }];
        //        _reRSListbutton.layer.cornerRadius  = 4;
        //        _reRSListbutton.layer.borderColor = allRedColor.CGColor;
        //        _reRSListbutton.layer.borderWidth = 1;
    }else if (_rankTypeButtonIndex == 9){
        
        _reDSListbutton.selected = YES;
        [self.redlineView mas_remakeConstraints:^(MASConstraintMaker *make) {
            make.width.mas_equalTo(ScreenWidth /3);
            make.bottom.mas_equalTo(self.mas_bottom);
            make.left.mas_equalTo(self.mas_left).offset(ScreenWidth / 3*2);
            make.height.mas_equalTo(@2);
        }];
        //        _reDSListbutton.layer.cornerRadius  = 4;
        //        _reDSListbutton.layer.borderColor = allRedColor.CGColor;
        //        _reDSListbutton.layer.borderWidth = 1;
    }
}
/*
 // Only override drawRect: if you perform custom drawing.
 // An empty implementation adversely affects performance during animation.
 - (void)drawRect:(CGRect)rect {
 // Drawing code
 }
 */

@end
