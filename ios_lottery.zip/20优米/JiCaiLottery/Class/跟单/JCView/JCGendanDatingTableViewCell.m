//
//  JCGendanDatingTableViewCell.m
//  JiCaiLottery
//
//  Created by Peng Jun on 2018/5/22.
//  Copyright © 2018年 JiCaiLottery. All rights reserved.
//

#import "JCGendanDatingTableViewCell.h"
#import "JCHeader.h"
#import "JCGendanInfoView.h"
#import "JCGendanCenterListModel.h"


@interface JCGendanDatingTableViewCell()
@property(nonatomic,strong) JCGendanInfoView *infoView;
@property(nonatomic,strong)UIImageView *icon;
@property(nonatomic,strong)UILabel *name;
@property(nonatomic,strong)UILabel *recommendLabel;
@property(nonatomic,strong)UILabel *recentStatu;
@property(nonatomic,strong)UILabel *recentStatu2;
@property(nonatomic,strong)UILabel *recentStatu3;

@property(nonatomic,strong)UILabel *limitTime;
@property(nonatomic,strong)UIButton *gendanButton;
@property(nonatomic,strong)UILabel *describeLab;
//@property(nonatomic, strong)CBAutoScrollLabel *describeLab;

@property(nonatomic,strong)UIImageView *stausImgV;
@property(nonatomic,strong)UILabel *ballType;
@end

@implementation JCGendanDatingTableViewCell


- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}
- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        [self createUI];
    }
    return self;
}
- (void)createUI{
    UIView *line = [[UIView alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, 0.5)];
    line.backgroundColor = allLineColor;
    [self.contentView addSubview:line];
    
//    头像
    self.icon = [[UIImageView alloc]init];
    self.icon.layer.cornerRadius = 16 *(ScreenScale>1?ScreenScale:1);
    self.icon.clipsToBounds = YES;
    self.icon.userInteractionEnabled = YES;
    self.icon.contentMode = UIViewContentModeScaleAspectFill;
    UITapGestureRecognizer *iconTap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(iconAction:)];
    [self.icon addGestureRecognizer:iconTap];
    [self.contentView addSubview:self.icon];
    
    
    [self.icon mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(self.contentView.mas_left).offset(20);
        make.top.mas_equalTo(self.contentView.mas_top).offset(20);
        make.size.mas_equalTo(CGSizeMake(32, 32));
    }];
   
    
//    名称
    
    self.name = [[UILabel alloc]init];
    self.name.text = @"大神";
    self.name.textColor = JCTTTColor;
    self.name.userInteractionEnabled = YES;
    UITapGestureRecognizer *nameTap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(iconAction:)];
    [self.name addGestureRecognizer:nameTap];
    self.name.font = FONT(14);
    [self.contentView addSubview:self.name];
    
    [self.name mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(self.icon.mas_right).offset(5);
        make.top.mas_equalTo(self.contentView.mas_top).offset(17);
    }];
    
  
    
//    推荐
//    self.recommendLabel = [[UILabel alloc]init];
//    self.recommendLabel.text = @"荐";
//    self.recommendLabel.textAlignment = NSTextAlignmentCenter;
//    self.recommendLabel.layer.cornerRadius = 3;
//    self.recommendLabel.clipsToBounds = YES;
//    self.recommendLabel.textColor = [UIColor whiteColor];
//    self.recommendLabel.backgroundColor = allRedColor;
//    self.recommendLabel.font = FONT(12);
//    [self.contentView addSubview:self.recommendLabel];
//
//    [self.recommendLabel mas_makeConstraints:^(MASConstraintMaker *make) {
//        make.left.mas_equalTo(self.name.mas_right).offset(10);
//        make.centerY.mas_equalTo(self.name.mas_centerY);
//        make.size.mas_equalTo(CGSizeMake(20, 20));
//    }];
    
//近1中1
    self.recentStatu = [[UILabel alloc]init];
    self.recentStatu.text = @"近3中1";
    self.recentStatu.font = FONT(12);
    self.recentStatu.textColor = allWhiteColor;
    self.recentStatu.backgroundColor = allRedColor;
    self.recentStatu.layer.cornerRadius = 6.f;
    self.recentStatu.layer.masksToBounds = YES;
    self.recentStatu.textAlignment = NSTextAlignmentCenter;
    [self.contentView addSubview:self.recentStatu];
    [self.recentStatu mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self.name.mas_top).offset(0);
        make.left.mas_equalTo(self.name.mas_right).offset(5);
//        make.size.mas_equalTo(CGSizeMake(60, 20));
         make.height.mas_equalTo(20);
//        make.width.mas_equalTo(50);
    }];
    
  
    
  //盈利0%
    self.recentStatu2 = [[UILabel alloc]init];
    self.recentStatu2.text = @" 盈利0% ";
    self.recentStatu2.font = FONT(12);
    self.recentStatu2.textColor = allRedColor;
    self.recentStatu2.backgroundColor = UICOLOR_HEX(0xFFF7F7);
    self.recentStatu2.textAlignment = NSTextAlignmentCenter;
    self.recentStatu2.layer.cornerRadius = 6.f;
    self.recentStatu2.layer.masksToBounds = YES;
    [self.contentView addSubview:self.recentStatu2];
    [self.recentStatu2 mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self.name.mas_top).offset(0);
        make.left.mas_equalTo(self.recentStatu.mas_right).offset(5);
//        make.size.mas_equalTo(CGSizeMake(50, 20));
//        make.width.mas_equalTo(50);
        make.height.mas_equalTo(20);
    }];
    
    
   //3连红
    self.recentStatu3 = [[UILabel alloc]init];
    self.recentStatu3.text = @" 3连红 ";
    self.recentStatu3.font = FONT(12);
    self.recentStatu3.textColor = allRedColor;
    self.recentStatu3.backgroundColor = [UIColor whiteColor];
    [self.contentView addSubview:self.recentStatu3];
    [self.recentStatu3 mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self.name.mas_top).offset(0);
        make.left.mas_equalTo(self.recentStatu2.mas_right).offset(5);
//        make.size.mas_equalTo(CGSizeMake(50, 20));
         make.height.mas_equalTo(20);
    }];
    
    // 宣言lab
    self.describeLab = [[UILabel alloc]init];
    self.describeLab.text = @"今明两天无足球比赛,玩玩篮球.今明两天无足球比赛,玩玩篮球.今明两天无足球比赛,玩玩篮球.";
    self.describeLab.textAlignment = NSTextAlignmentLeft;
    self.describeLab.textColor = [UIColor lightGrayColor];
    self.describeLab.font = FONT(12);
    [self.contentView addSubview:self.describeLab];
//    self.describeLab.numberOfLines = 0;//设置换行
//    self.describeLab.preferredMaxLayoutWidth = ScreenWidth-20;//给一个maxWidth
    [self.describeLab setContentHuggingPriority:UILayoutPriorityRequired forAxis:UILayoutConstraintAxisVertical];//设置huggingPriority
    [self.describeLab mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self.name.mas_bottom).offset(5);
        make.left.mas_equalTo(self.icon.mas_right).offset(5);
       make.size.mas_equalTo(CGSizeMake(ScreenWidth/2+50, 20));
    }];
    
//    self.describeLab.labelSpacing = 30;
//    self.describeLab.pauseInterval = 1.7;  
//    self.describeLab.scrollSpeed = 30; // pixels per second
//    self.describeLab.fadeLength = 12.f;
//    self.describeLab.scrollDirection = CBAutoScrollDirectionLeft;
//    [self.describeLab observeApplicationNotifications];
//    
    
    
    
    
    //    中间信息View（ 单倍金额、跟单人数等）
    self.infoView = [[JCGendanInfoView alloc]initWithFrame:CGRectMake(20, 85*(ScreenScale>1?ScreenScale:1), ScreenWidth -40, 84*(ScreenScale>1?ScreenScale:1))];//
    
    //    self.infoView.layer.borderColor = UICOLOR_HEX(0xeeeeee).CGColor;
    //    self.infoView.layer.borderWidth = 0.5;
    [self.contentView addSubview:self.infoView];
    
    //    图片标志
    self.stausImgV = [[UIImageView alloc] init];
    [self.contentView addSubview:self.stausImgV];
    [self.stausImgV mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self.infoView.mas_bottom).offset(10);
        make.left.mas_equalTo(self.infoView.mas_left).offset(0);
        make.height.mas_equalTo(20);
        make.width.mas_equalTo(20);
    }];
    
//   球类型
    self.ballType = [[UILabel alloc]init];
    self.ballType.text = @"竞彩足球";
    self.ballType.font = FONT(12);
    self.ballType.textColor = [UIColor colorWithRed:64/255.0 green:204/255.0 blue:154/255.0 alpha:1];//1 191 155[UIColor greenColor];
    self.ballType.backgroundColor = [UIColor whiteColor];
    [self.contentView addSubview:self.ballType];
    [self.ballType mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self.infoView.mas_bottom).offset(10);
        make.left.mas_equalTo(self.stausImgV.mas_right).offset(5);
        make.size.mas_equalTo(CGSizeMake(60, 20));
    }];
    
    
    self.limitTime = [[UILabel alloc]init];
    self.limitTime.text = @"05-07 00：50截止";
    self.limitTime.font = FONT(12);
    self.limitTime.textColor = JCNNNColor;
    self.limitTime.textAlignment = NSTextAlignmentRight;
    [self.contentView addSubview:self.limitTime];

    [self.limitTime mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self.infoView.mas_bottom).offset(5);
        make.right.mas_equalTo(self.contentView.mas_right).offset(-20);
        make.size.mas_equalTo(CGSizeMake(180, 28));
    }];
    
    self.gendanButton= [UIButton buttonWithType:UIButtonTypeCustom];
    [self.gendanButton setTitle:@"立即跟单" forState: UIControlStateNormal];
    self.gendanButton.titleLabel.font = FONT(14);
    self.gendanButton.backgroundColor = allRedColor;
    self.gendanButton.layer.cornerRadius = 4.f;
    [self.gendanButton setTitleColor:allWhiteColor forState:UIControlStateNormal];
    [self.gendanButton addTarget:self action:@selector(gendanAction:) forControlEvents:UIControlEventTouchUpInside];
    [self.contentView addSubview:self.gendanButton];
    
    
    [self.gendanButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.mas_equalTo(self.contentView.mas_right).offset(-10);
        make.top.mas_equalTo(self.contentView.mas_top).offset(15);
        make.width.mas_equalTo(80);
        make.height.mas_equalTo(30);
       
    }];
    
    
    
    [self.infoView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self.describeLab.mas_bottom).offset(10);
        make.left.mas_equalTo(self.contentView.mas_left).offset(20);
        
        make.size.mas_equalTo(CGSizeMake(ScreenWidth -40, 84));
    }];
    
   
    
    [self layoutIfNeeded];
}
- (void)gendanAction:(UIButton *)button{
    NSLog(@"跟单");
    if (self.gdBlcok) {
        self.gdBlcok([self.model.schemeId integerValue]);
    }
}
- (void)iconAction:(UITapGestureRecognizer *)tap{
    if (self.gdIconBlcok) {
        self.gdIconBlcok([self.model.userId integerValue]);
    }
}
- (void)setModel:(JCGendanCenterListModel *)model{
    _model = model;
    
    [self.icon sd_setImageWithURL:[NSURL URLWithString:_model.avatar] placeholderImage:[UIImage imageNamed:@"mine_defaul_icon"]];
    self.name.text = _model.userName;
    
    self.recentStatu.text =
    [NSString stringWithFormat:@" 近%@中%@  ",_model.weekBetCount,_model.weekHitCount];
    self.recentStatu2.text =
    [NSString stringWithFormat:@" 盈利%@%%  ",_model.weekHitRatio];;
    if (_model.recentRecord.length>0) {
        //        if ([_model.weekHitCount integerValue]>=2) {
        //            self.recentStatu3.text =
        //            [NSString stringWithFormat:@" %@连红  ",_model.weekHitCount];
        //        }
        self.recentStatu3.text =[NSString stringWithFormat:@"%@",_model.recentRecord] ;
    }
    else{
        self.recentStatu3.text = @"";
    }
    
   
    
    self.describeLab.text =  _model.sdescribe;
    
    self.infoView.lotteryName = _model.betDescription;
    self.infoView.money = _model.money;
    
    
    NSString *na = _model.betDescription;
    NSArray *arr = [_model.betDescription componentsSeparatedByString:@"_"];
    if (arr.count > 0) {
        na = arr[0];
    }
    NSString *str = [NSString stringWithFormat:@"%@",na];
    
   
      _stausImgV.image = [UIImage imageNamed:[[JCLotteryInfo GetLotteryImageWithLotteryName] objectForKey:str]];
    self.ballType.text = str;
    
    self.infoView.gendanMoney = [NSString stringWithFormat:@"%@", _model.followMoney];
    self.infoView.singleMoney = [NSString stringWithFormat:@"%@", _model.singleMultipleMoney];
    
    self.infoView.joinners =[NSString stringWithFormat:@"%@", self.model.participant];
    
    NSString *timeen  = @"";
    if (_model.endTime.length > 0) {
        timeen = [_model.endTime substringWithRange:NSMakeRange(5, _model.endTime.length - 8)];
        
    }
    self.limitTime.text = [NSString stringWithFormat:@"%@截止",timeen];
    if ([_model.recommend boolValue]) {
        self.recommendLabel.hidden = NO;
    }else{
        self.recommendLabel.hidden = YES;
    }
}
- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
    
    // Configure the view for the selected state
}

@end
