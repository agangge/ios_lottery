
//
//  JCJionGendanView.m
//  JiCaiLottery
//
//  Created by Peng Jun on 2017/11/27.
//  Copyright © 2017年 JiCaiLottery. All rights reserved.
//

#import "JCJionGendanView.h"
#import "JCHeader.h"
@interface JCJionGendanView()<PPNumberButtonDelegate>
@end
@implementation JCJionGendanView
- (instancetype)initWithFrame:(CGRect)frame{
    if (self = [super initWithFrame:frame]) {
        [self createView];
    }
    return self;
}
- (void)createView{
    UILabel *touLable  = [[UILabel alloc] init];
    touLable.text = @"投";
    touLable.font = FONT(14);
    touLable.textColor = UICOLOR_HEX(0x666666);
    [self addSubview:touLable];
    
    _numberButton = [PPNumberButton numberButtonWithFrame:CGRectZero];
    _numberButton.borderColor = [UIColor grayColor];
    _numberButton.increaseTitle = @"＋";
    _numberButton.decreaseTitle = @"－";
    
    _numberButton.shakeAnimation = YES;
    _numberButton.minValue = 1;
    _numberButton.maxValue = 99999;
    _numberButton.currentNumber = 1;
    _numberButton.delegate = self;
    _numberButton.longPressSpaceTime = CGFLOAT_MAX;
    
    [self addSubview:_numberButton];
    
    UILabel *beiLable  = [[UILabel alloc] init];
    beiLable.text = @"倍";
    beiLable.font = FONT(14);
    beiLable.textColor = UICOLOR_HEX(0x666666);
    [self addSubview:beiLable];
    
    _totalMoneyLabel  = [[UILabel alloc] init];
    _totalMoneyLabel.text = @"共2元";
    _totalMoneyLabel.font = FONT(14);
    _totalMoneyLabel.textColor = UICOLOR_HEX(0x666666);
    [self addSubview:_totalMoneyLabel];
    
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    
    button = [UIButton buttonWithType:UIButtonTypeCustom];
    [button setTitle:@"跟单" forState:UIControlStateNormal];
    [button setTitleColor:UICOLOR_HEX(0xffffff) forState:UIControlStateNormal];
    button.titleLabel.font = FONT(14);
    [button addTarget:self action:@selector(gendanAction) forControlEvents:UIControlEventTouchUpInside];
    button.titleLabel.textAlignment = NSTextAlignmentCenter;
    button.backgroundColor = allRedColor;
    [self addSubview:button];
    
    [touLable mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.mas_equalTo(self.mas_centerY);
        make.left.mas_equalTo(self.mas_left).offset(15);
        
    }];
    
    [_numberButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.mas_equalTo(self.mas_centerY);
        make.left.mas_equalTo(touLable.mas_right).offset(9);
        make.size.mas_equalTo(CGSizeMake(80, 24));
        
    }];
    [beiLable mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.mas_equalTo(self.mas_centerY);
        make.left.mas_equalTo(_numberButton.mas_right).offset(9);
        
    }];
    
    [_totalMoneyLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.mas_equalTo(self.mas_centerY);
        make.centerX.mas_equalTo(self.mas_centerX).offset(20);
        
    }];
    
    [button mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.mas_equalTo(self.mas_centerY);
        make.right.mas_equalTo(self.mas_right);
        make.size.mas_equalTo(CGSizeMake(90, 40));
        
    }];
    UILabel *line = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, 0.5)];
    line.backgroundColor = UICOLOR_HEX(0xdddddd);
    [self addSubview:line];
    
}
- (void)gendanAction{
    if (self.toGdBlock) {
        self.toGdBlock();
    }
}
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
