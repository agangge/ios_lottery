//
//  JCGendanChartTableViewCell.h
//  JiCaiLottery
//
//  Created by Peng Jun on 2018/5/22.
//  Copyright © 2018年 JiCaiLottery. All rights reserved.
//

#import <UIKit/UIKit.h>
@class JCGendanRankModel;
@interface JCGendanChartTableViewCell : UITableViewCell
@property (nonatomic, strong)UIImageView *iconImage;
@property (nonatomic, strong)UIImageView *cupImage;
@property (nonatomic, strong)UILabel *rateLabel;
@property (nonatomic, strong)UILabel *nameLabel;
@property (nonatomic, strong)UILabel *pelpeoLabel;
@property (nonatomic, strong)UILabel *leftGrayLabel;
@property (nonatomic, strong)UILabel *leftRedLabel;
@property (nonatomic, strong)UILabel *zhongjiangLabel;
@property (nonatomic, strong)JCGendanRankModel *model;
- (void)listModel:(JCGendanRankModel*)model listType:(NSInteger)listType Rank:(NSInteger)rank;
@end
