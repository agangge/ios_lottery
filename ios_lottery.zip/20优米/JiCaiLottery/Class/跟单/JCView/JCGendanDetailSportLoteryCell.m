//
//  JCGendanDetailSportLoteryCell.m
//  JiCaiLottery
//
//  Created by Peng Jun on 2017/11/25.
//  Copyright © 2017年 JiCaiLottery. All rights reserved.
//

#import "JCGendanDetailSportLoteryCell.h"
#import "JCHeader.h"
@implementation JCGendanDetailSportLoteryCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        [self initWithTable];
    }
    return self;
}

- (void)initWithTable
{
    self.timeLabel = [[UILabel alloc]init];
    //    self.timeLabel.backgroundColor = allLineColor;
    self.timeLabel.textColor = ColorRGB(51, 51, 51, 1);
    self.timeLabel.textAlignment = NSTextAlignmentCenter;
    self.timeLabel.font = [UIFont systemFontOfSize:15.f];
    
    self.hostOrGuestLabel = [[UILabel alloc]init];
    //    self.hostOrGuestLabel.backgroundColor = allLineColor;
    self.hostOrGuestLabel.numberOfLines = 0;
    self.hostOrGuestLabel.textAlignment = NSTextAlignmentCenter;
    self.hostOrGuestLabel.textColor = ColorRGB(51, 51, 51, 1);
    self.hostOrGuestLabel.font = [UIFont systemFontOfSize:15.f];
    
    self.bingoLabel = [[UILabel alloc]init];
    //    self.bingoLabel.backgroundColor = allLineColor;
    self.bingoLabel.textAlignment = NSTextAlignmentCenter;
    self.bingoLabel.textColor = ColorRGB(51, 51, 51, 1);
    self.bingoLabel.font = [UIFont systemFontOfSize:15.f];
    self.bingoLabel.numberOfLines = 0;
    self.bingoLabel.adjustsFontSizeToFitWidth = YES;
    
    
    self.tijiaoLabel = [[UILabel alloc]init];
    //    self.tijiaoLabel.backgroundColor = allLineColor;
    self.tijiaoLabel.textAlignment = NSTextAlignmentCenter;
    self.tijiaoLabel.textColor = ColorRGB(51, 51, 51, 1);
    self.tijiaoLabel.font = [UIFont systemFontOfSize:10.f];
    self.tijiaoLabel.numberOfLines = 0;
    
    [self sd_addSubviews:@[self.timeLabel, self.hostOrGuestLabel, self.bingoLabel, self.tijiaoLabel]];
    self.timeLabel.sd_layout
    .leftSpaceToView(self, 0)
    .topSpaceToView(self, 0)
    .widthRatioToView(self, 0.25)
    .heightRatioToView(self, 1);
    
    self.hostOrGuestLabel.sd_layout
    .leftSpaceToView(self.timeLabel, 0)
    .topSpaceToView(self, 0)
    .widthRatioToView(self, 0.25)
    .heightRatioToView(self, 1);
    
    self.bingoLabel.sd_layout
    .leftSpaceToView(self.hostOrGuestLabel, 0)
    .topSpaceToView(self, 0)
    .widthRatioToView(self, 0.25)
    .heightRatioToView(self, 1);
    
    self.tijiaoLabel.sd_layout
    .leftSpaceToView(self.bingoLabel, 0)
    .topSpaceToView(self, 0)
    .widthRatioToView(self, 0.25)
    .heightRatioToView(self, 1);
    
}

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
    
    // Configure the view for the selected state
}


@end
