//
//  JCStartGendanTCTableViewCell.m
//  JiCaiLottery
//
//  Created by Peng Jun on 2017/11/23.
//  Copyright © 2017年 JiCaiLottery. All rights reserved.
//

#import "JCStartGendanTCTableViewCell.h"
#import "JCHeader.h"
@implementation JCStartGendanTCTableViewCell{
    UILabel *_topLabel;
    UIView *bottomView;
}

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        self.contentView.backgroundColor = UICOLOR_HEX(0xF7F6F6);
        [self createCell];
    }
    return self;
}
- (void)createCell{
    
    UIView *view = [[UIView alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, 30)];
    view.backgroundColor = allWhiteColor;
    [self.contentView addSubview:view];
    UILabel *line = [[UILabel alloc]initWithFrame:CGRectMake(0, 29.5, ScreenWidth, 0.5)];
    line.backgroundColor = UICOLOR_HEX(0xfffefe);
    [view addSubview:line];
    _topLabel = [[UILabel alloc] init];
    _topLabel.font = FONT(16);
    _topLabel.textColor = UICOLOR_HEX(0x333333);
    _topLabel.text = @"方案提成";
    [view addSubview:_topLabel];
    [_topLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.mas_equalTo(view);
        make.left.mas_equalTo(view.mas_left).offset(15);
    }];
    
    bottomView = [[UIView alloc]initWithFrame:CGRectMake(0, 30, ScreenWidth, 190)];
    bottomView.backgroundColor = allWhiteColor;
    [self.contentView addSubview:bottomView];
    
    UIImage *normalImage = [UIImage imageNamed:@"lilun_normal"];
    UIImage *selectedImage = [UIImage imageNamed:@"lilun_selected"];
    
    UIButton *jingliButton = [UIButton buttonWithType:UIButtonTypeCustom];
    jingliButton.frame = CGRectMake(15, 15, 80, 26);
    [jingliButton setTitleColor:UICOLOR_HEX(0xE62F1A) forState:UIControlStateSelected];
    [jingliButton setTitleColor:UICOLOR_HEX(0xE62F1A) forState:UIControlStateNormal];
    [jingliButton setBackgroundImage:normalImage forState:UIControlStateNormal];
    [jingliButton setBackgroundImage:selectedImage forState:UIControlStateNormal];
    [jingliButton setTitle:@"净利润" forState:UIControlStateNormal];
    jingliButton.tag = 99;
//    jingliButton.selected = YES;
    jingliButton.titleLabel.font = FONT(14);
    [jingliButton addTarget:self action:@selector(llbuttonAction:) forControlEvents:UIControlEventTouchUpInside];
    [bottomView addSubview:jingliButton];
    
    
    NSArray *arr = @[@"1%",@"2%",@"3%",@"4%",@"5%",@"6%",@"7%",@"8%",@"9%",@"10%",];
    for (int i = 0; i<arr.count; i++) {
        
        CGFloat width = (ScreenWidth- 11*4-30) /5;
        CGFloat x = (i%5)*(width+11)+15;
        CGFloat height = 26.f;
        CGFloat y = i<5?55.f:102.f;
        UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
        button.frame = CGRectMake(x, y, width, height);
        if (i == 0) {
            button.selected = YES;
        }
//        [button setBackgroundColor:UICOLOR_HEX(0x999999)];
        [button setTitleColor:UICOLOR_HEX(0xE62F1A) forState:UIControlStateSelected];
        [button setTitleColor:UICOLOR_HEX(0x333333) forState:UIControlStateNormal];
//        [button setBackgroundImage:normalImage forState:UIControlStateNormal];
        button.backgroundColor = UICOLOR_HEX(0xf5f5f5);
        button.layer.cornerRadius = 3;
        button.layer.masksToBounds = YES;
        [button setBackgroundImage:selectedImage forState:UIControlStateSelected];
        button.layer.cornerRadius = 3;
        button.clipsToBounds = YES;
        [button setTitle:arr[i] forState:UIControlStateNormal];
        button.tag = i+100;
        button.titleLabel.font = FONT(14);
        [button addTarget:self action:@selector(buttonAction:) forControlEvents:UIControlEventTouchUpInside];
        [bottomView addSubview:button];
    }
    
    UILabel *shuoming = [[UILabel alloc] init];
    shuoming.font = FONT(14);
    shuoming.textColor = UICOLOR_HEX(0x666666);
    shuoming.text = @"净利润=（税后奖金-订单总本金）*方案提成比例";
     [bottomView addSubview:shuoming];
    [shuoming mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.mas_equalTo(bottomView.mas_bottom).offset(-23);
        make.left.mas_equalTo(bottomView.mas_left).offset(15);
        make.width.mas_equalTo(ScreenWidth -30);
    }];
    //    [self dataFull];
}
- (void)llbuttonAction:(UIButton *)button{};
- (void)buttonAction:(UIButton *)button{
    for (UIButton *btn in bottomView.subviews) {
        if ([btn isKindOfClass:[UIButton class]]) {
            if (btn.tag == button.tag) {
                btn.selected = YES;
            }else{
                btn.selected = NO;
            }
            
        }
    }

    if (self.tcBlcok) {
        self.tcBlcok(button.titleLabel.text, button.tag);
    }
}
- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
