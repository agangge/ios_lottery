//
//  JCGendanPopView.h
//  JiCaiLottery
//
//  Created by Peng Jun on 2017/11/23.
//  Copyright © 2017年 JiCaiLottery. All rights reserved.
//

#import <UIKit/UIKit.h>
typedef void (^selectButtonBlock)(NSString *buttontext,NSInteger butttonIndex);
@interface JCGendanPopView : UIView
@property (nonatomic, strong)UIView *selectedView;
@property (nonatomic, copy)selectButtonBlock selectBlock;
@property (nonatomic, assign)NSInteger selectedIndex;
- (instancetype)initWithFrame:(CGRect)frame withIndex:(NSInteger)index;

@end
