//
//  JCGendanDetailSportLoteryCell.h
//  JiCaiLottery
//
//  Created by Peng Jun on 2017/11/25.
//  Copyright © 2017年 JiCaiLottery. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface JCGendanDetailSportLoteryCell : UITableViewCell
@property (nonatomic, strong)UILabel *timeLabel;
@property (nonatomic, strong)UILabel *hostOrGuestLabel;
@property (nonatomic, strong)UILabel *bingoLabel;
@property (nonatomic, strong)UILabel *tijiaoLabel;
@end
