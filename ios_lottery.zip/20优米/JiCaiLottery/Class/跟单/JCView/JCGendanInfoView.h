//
//  JCGendanInfoView.h
//  JiCaiLottery
//
//  Created by Peng Jun on 2018/5/22.
//  Copyright © 2018年 JiCaiLottery. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface JCGendanInfoView : UIView
@property (nonatomic, copy)NSString *lotteryName;

@property (nonatomic, copy)NSString *singleMoney;
@property (nonatomic, copy)NSString *gendanMoney;
@property (nonatomic, copy)NSString *joinners;
@property (nonatomic, assign)BOOL isGray;

@property (nonatomic, copy)NSString *money;
@end
