//
//  JCGendanPopView.m
//  JiCaiLottery
//
//  Created by Peng Jun on 2017/11/23.
//  Copyright © 2017年 JiCaiLottery. All rights reserved.
//

#import "JCGendanPopView.h"
#import "JCHeader.h"
@implementation JCGendanPopView

- (instancetype)initWithFrame:(CGRect)frame withIndex:(NSInteger)index{
    if (self = [super initWithFrame:frame]) {
//        self.alpha = 0.5;
        self.backgroundColor = [UIColor colorWithRed:0 green:0 blue:0  alpha:0.7];
        self.selectedIndex = index;
        [self  created];
    }
    return self;
}
- (void)created{
    
    CGRect frame = CGRectMake(0,0 , ScreenWidth, 50);
    //    UIView *rootView = [UIApplication sharedApplication].keyWindow;
    self.selectedView = [[UIView alloc] initWithFrame:frame];
    self.selectedView.backgroundColor = [UIColor whiteColor];
    UIButton *allbutton = [UIButton buttonWithType:UIButtonTypeCustom];
    [allbutton setTitle:@"全部" forState:UIControlStateNormal];
    [allbutton setTitle:@"全部" forState:UIControlStateSelected];
    [allbutton setTitleColor:allWhiteColor forState:UIControlStateSelected];
    [allbutton setTitleColor:UICOLOR_HEX(0x333333) forState:UIControlStateNormal];
    allbutton.frame = CGRectMake(70, 10, (ScreenWidth - 140-75)/2, 60/2);
    allbutton.tag = 1;
//    allbutton.layer.cornerRadius = 3;
//    allbutton.layer.borderWidth = 0.5;
//    allbutton.layer.borderColor = UICOLOR_HEX(0x979797).CGColor;
        allbutton.titleLabel.font =FONT(15);
    [allbutton setBackgroundImage:[UIImage imageNamed:@"gendan_title_normal"] forState:UIControlStateNormal];
    [allbutton setBackgroundImage:[UIImage imageNamed:@"gendan_title_selected"] forState:UIControlStateSelected];
    
    [allbutton addTarget:self action:@selector(selectAction:) forControlEvents:UIControlEventTouchUpInside];
    [self.selectedView addSubview:allbutton];
    
    UIButton *focusbutton = [UIButton buttonWithType:UIButtonTypeCustom];
    [focusbutton setTitle:@"关注" forState:UIControlStateNormal];
    [focusbutton setTitle:@"关注" forState:UIControlStateSelected];
    focusbutton.tag = 2;
    [focusbutton setBackgroundImage:[UIImage imageNamed:@"gendan_title_normal"] forState:UIControlStateNormal];
    [focusbutton setBackgroundImage:[UIImage imageNamed:@"gendan_title_selected"] forState:UIControlStateSelected];

    focusbutton.titleLabel.font =FONT(15);
//    focusbutton.layer.borderColor = UICOLOR_HEX(0x979797).CGColor;
//    focusbutton.layer.borderWidth = 0.5;
//        focusbutton.layer.cornerRadius = 3;
    [focusbutton setTitleColor:allWhiteColor forState:UIControlStateSelected];
    [focusbutton setTitleColor:UICOLOR_HEX(0x333333) forState:UIControlStateNormal];
    focusbutton.frame = CGRectMake(70+75+(ScreenWidth - 140-75)/2, 10, (ScreenWidth - 140-75)/2, 60/2);;
    [focusbutton addTarget:self action:@selector(selectAction:) forControlEvents:UIControlEventTouchUpInside];
    [self.selectedView addSubview:focusbutton];
    [self addSubview:self.selectedView];
    if (self.selectedIndex == 1) {
        allbutton.selected = YES;
    }else if (self.selectedIndex == 2){
         focusbutton.selected = YES;
    }

}
- (void)selectAction:(UIButton *)button{
//    button.selected = YES;
        if (self.selectBlock) {
            self.selectBlock(button.titleLabel.text, button.tag);
        }

}
@end
