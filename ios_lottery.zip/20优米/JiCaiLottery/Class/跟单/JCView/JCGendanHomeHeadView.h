//
//  JCGendanHomeHeadView.h
//  JiCaiLottery
//
//  Created by Peng Jun on 2018/5/23.
//  Copyright © 2018年 JiCaiLottery. All rights reserved.
//

#import <UIKit/UIKit.h>
typedef void (^gendanHeadViewBlock)(NSInteger tag);
@interface JCGendanHomeHeadView : UIView
@property (nonatomic, copy)gendanHeadViewBlock bangdanBlcok;

@property (nonatomic, strong)NSArray *dSArray;
@end
