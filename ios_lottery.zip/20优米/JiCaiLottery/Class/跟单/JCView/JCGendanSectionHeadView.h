//
//  JCGendanSectionHeadView.h
//  JiCaiLottery
//
//  Created by Peng Jun on 2018/5/24.
//  Copyright © 2018年 JiCaiLottery. All rights reserved.
//

#import <UIKit/UIKit.h>
@class ImageCenterButton;


@protocol JCGendanSectionHeadViewDelegate <NSObject>

- (void)clickPopViewButton:(UIButton *)sender;

@end
@interface JCGendanSectionHeadView : UIView
@property (nonatomic, strong)UIView *lineView;
@property (nonatomic, strong)UIView *redlineView;
@property (nonatomic, strong)UILabel *titleLabel;
@property (nonatomic, strong)UILabel *rightMiaoshuLabel;
@property (nonatomic, strong)UIImageView *arrowImage;
@property (nonatomic, strong)UIButton *reDSListbutton;
@property (nonatomic, strong)UIButton *reJineListbutton;
@property (nonatomic, strong)UIButton *reRSListbutton;
@property (nonatomic, strong)UILabel *tuijainLabel;
@property (nonatomic, assign)NSInteger rankTypeButtonIndex;
@property (nonatomic, weak)id<JCGendanSectionHeadViewDelegate>delegate;
@end
