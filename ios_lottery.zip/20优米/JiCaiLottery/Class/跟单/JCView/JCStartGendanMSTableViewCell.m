//
//  JCStartGendanMSTableViewCell.m
//  JiCaiLottery
//
//  Created by Peng Jun on 2017/11/23.
//  Copyright © 2017年 JiCaiLottery. All rights reserved.
//

#import "JCStartGendanMSTableViewCell.h"
#import "JCHeader.h"
@implementation JCStartGendanMSTableViewCell{
    UILabel *_topLabel;
    UITextView *_textview;
}

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        [self createCell];
    }
    return self;
}
- (void)createCell{
    UIView *view = [[UIView alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, 40)];
    view.backgroundColor = allWhiteColor;
    [self.contentView addSubview:view];
    UILabel *line = [[UILabel alloc]initWithFrame:CGRectMake(0, 39.5, ScreenWidth, 0.5)];
    line.backgroundColor = UICOLOR_HEX(0xfffefe);
    [view addSubview:line];
    _topLabel = [[UILabel alloc] init];
    _topLabel.font = FONT(16);
    _topLabel.textColor = UICOLOR_HEX(0x333333);
    _topLabel.text = @"方案宣言";
    [view addSubview:_topLabel];
    [_topLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.mas_equalTo(view);
        make.left.mas_equalTo(view.mas_left).offset(15);
    }];
    
    _textview  = [[UITextView alloc] initWithFrame:CGRectMake(15, 45, ScreenWidth -30, 140)];
    _textview.backgroundColor = UICOLOR_HEX(0xF5F5F5);
    _textview.font = FONT(12);
    _textview.delegate = self;
    _textview.textColor = UICOLOR_HEX(0x333333);
    [self.contentView addSubview:_textview];
}
- (BOOL)textViewShouldBeginEditing:(UITextView *)textView{
    return YES;
}
- (BOOL)textViewShouldEndEditing:(UITextView *)textView{
    return YES;
}

- (void)textViewDidBeginEditing:(UITextView *)textView{
    if (self.msBlcok) {
        self.msBlcok(textView.text);
    }
}
- (void)textViewDidEndEditing:(UITextView *)textView{
    if (self.msBlcok) {
        self.msBlcok(textView.text);
    }
}
- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    [self endEditing:YES];
}
- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
