//
//  JCGendanDSHeadView.m
//  JiCaiLottery
//
//  Created by Peng Jun on 2018/5/24.
//  Copyright © 2018年 JiCaiLottery. All rights reserved.
//

#import "JCGendanDSHeadView.h"
#import "JCHeader.h"
#import "JCGendanSectionHeadView.h"
@implementation JCGendanDSHeadView{
    
    UILabel *_rencentLLWenzLabel;
    UILabel *_rencentBangWenzLabel; //几中几
    UILabel *_rencentEarnWenzLabel;
    UIImageView *_topBgImageView;
    //    UIView *_bottomBgView;
    JCGendanSectionHeadView *_liebiaoview;
    NSArray *_arry;
}

- (instancetype)initWithFrame:(CGRect)frame{
    if (self = [super initWithFrame:frame]) {
        self.backgroundColor = allBackGroundColor;
        
        [self createUI];
        
    }
    return self;
}
- (void)createUI{
    
    _topBgImageView = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, (self.bounds.size.height) *130/240)];
    _topBgImageView.image = [UIImage imageNamed:@"大神主页背景"];
    _topBgImageView.userInteractionEnabled = YES;
    [self addSubview:_topBgImageView];
    
    _bottomBgView = [[UIView alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(_topBgImageView.frame), ScreenWidth,  (self.bounds.size.height) *50/240+10)];
    _bottomBgView.backgroundColor = [UIColor whiteColor];
    [self addSubview:_bottomBgView];
    
    
    _backButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [_backButton setImage:[UIImage imageNamed:@"返回"] forState:UIControlStateNormal];
    [_backButton addTarget:self action:@selector(backButton:) forControlEvents:UIControlEventTouchUpInside];
    
    [_topBgImageView addSubview:_backButton];
    
    _titleLabel = [[UILabel alloc]init];
    _titleLabel.text = @"大神主页";
    _titleLabel.font = FONT(18);
    _titleLabel.textColor = [UIColor whiteColor];
    [_topBgImageView addSubview:_titleLabel];
    
    _icon = [[UIImageView alloc]init];
    _icon.image = [UIImage imageNamed:@"mine_defaul_icon"];
    _icon.layer.cornerRadius = 18;
    _icon.clipsToBounds = YES;
    _icon.contentMode = UIViewContentModeScaleAspectFill;
    [_topBgImageView addSubview:_icon];
    
    _name = [[UILabel alloc]init];
    _name.text = @"一站成名";
    _name.font = FONT(14);
    _name.textColor = [UIColor whiteColor];
    [_topBgImageView addSubview:_name];
    
    _fansLabel = [[UILabel alloc]init];
    _fansLabel.text = @"粉丝：144 关注：0      ";
    _fansLabel.font = FONT(12);
    _fansLabel.textColor = [UIColor whiteColor];
    [_topBgImageView addSubview:_fansLabel];
    
    _foucsButton = [UIButton buttonWithType:UIButtonTypeCustom];
    _foucsButton.layer.cornerRadius = 4.0f;
    _foucsButton.clipsToBounds = YES;
    UIImage *selectedImage = [self createImageWithColor:[UIColor whiteColor]];
    UIImage *normalImage = [self createImageWithColor:allRedColor];
    [_foucsButton setTitle:@" + 关注" forState:UIControlStateNormal];
    _foucsButton.titleLabel.font = FONT(14);
    [_foucsButton setTitle:@"已关注" forState:UIControlStateSelected];
    [_foucsButton setTitleColor:allRedColor forState:UIControlStateSelected];
    [_foucsButton setTitleColor:allWhiteColor forState:UIControlStateNormal];
    [_foucsButton setBackgroundImage:normalImage forState:UIControlStateNormal];
    [_foucsButton setBackgroundImage:selectedImage forState:UIControlStateSelected];
    [_foucsButton addTarget:self action:@selector(foucsButtonAction:) forControlEvents:UIControlEventTouchUpInside];
    [_topBgImageView addSubview:_foucsButton];
    
    _rencentLLLabel =[[UILabel alloc]init];
    _rencentLLLabel.text = @"0.00%";
    _rencentLLLabel.font = FONT(14);
    _rencentLLLabel.numberOfLines = 2;
    _rencentLLLabel.textAlignment = NSTextAlignmentCenter;
    _rencentLLLabel.textColor = allRedColor;
    [_bottomBgView addSubview:_rencentLLLabel];
    
    _rencentBangLabel =[[UILabel alloc]init];
    _rencentBangLabel.text = @"0中0";
    _rencentBangLabel.font = FONT(14);
    _rencentBangLabel.numberOfLines = 2;
    _rencentBangLabel.textAlignment = NSTextAlignmentCenter;
    _rencentBangLabel.textColor = allRedColor;
    [_bottomBgView addSubview:_rencentBangLabel];
    
    _rencentEarnLabel =[[UILabel alloc]init];
    _rencentEarnLabel.text = @"0.0元";
    _rencentEarnLabel.font = FONT(14);
    _rencentEarnLabel.textAlignment = NSTextAlignmentCenter;
    _rencentEarnLabel.numberOfLines = 2;
    _rencentEarnLabel.textColor = allRedColor;
    [_bottomBgView addSubview:_rencentEarnLabel];
    
    _rencentLLWenzLabel =[[UILabel alloc]init];
    _rencentLLWenzLabel.text = @"近7天盈利率";
    _rencentLLWenzLabel.font = FONT(14);
    _rencentLLWenzLabel.numberOfLines = 2;
    _rencentLLWenzLabel.textAlignment = NSTextAlignmentCenter;
    _rencentLLWenzLabel.textColor = UICOLOR_HEX(0x999999);
    [_bottomBgView addSubview:_rencentLLWenzLabel];
    
    _rencentBangWenzLabel =[[UILabel alloc]init];
    _rencentBangWenzLabel.text = @"近7天命中率";
    _rencentBangWenzLabel.font = FONT(14);
    _rencentBangWenzLabel.numberOfLines = 2;
    _rencentBangWenzLabel.textAlignment = NSTextAlignmentCenter;
    _rencentBangWenzLabel.textColor = UICOLOR_HEX(0x999999);
    [_bottomBgView addSubview:_rencentBangWenzLabel];
    
    _rencentEarnWenzLabel =[[UILabel alloc]init];
    _rencentEarnWenzLabel.text = @"推荐中奖(元)";
    _rencentEarnWenzLabel.font = FONT(14);
    _rencentEarnWenzLabel.textAlignment = NSTextAlignmentCenter;
    _rencentEarnWenzLabel.numberOfLines = 2;
    _rencentEarnWenzLabel.textColor = UICOLOR_HEX(0x999999);
    [_bottomBgView addSubview:_rencentEarnWenzLabel];
    
    //状态：（新增 ）
    
    
    UIView *lineView =  [[UIView alloc] init];
    [_bottomBgView addSubview:lineView];
    lineView.backgroundColor = LineColor;
    [lineView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.right.mas_equalTo(self);
        make.top.mas_equalTo(_rencentEarnWenzLabel.mas_bottom).offset(5);
        make.height.mas_equalTo(1.5);
    }];
    
    UIImageView *statusImgV  = [[UIImageView alloc] init];
//    [_bottomBgView addSubview:statusImgV];
//    statusImgV.contentMode = UIViewContentModeScaleAspectFit;
//    statusImgV.image = [UIImage imageNamed:@"lottery_status"];
//    [statusImgV mas_makeConstraints:^(MASConstraintMaker *make) {
//        make.left.mas_equalTo(self.mas_left).offset(15);
//        make.top.mas_equalTo(_bottomBgView.mas_top).offset(80);
//        make.size.mas_equalTo(CGSizeMake(30, 25));
//    }];
    

#pragma mark -- 待优化 传值
//    JCLog(@"self.schemeListArry = %@",self.schemeListArry);//是 0
//    if (self.schemeListArry.count > 0) {//
//
//        for (int i = 0; i<self.schemeListArry.count; i++) {
//            UIImageView *statusImgV2= [[UIImageView alloc] init];
//            [_bottomBgView addSubview:statusImgV2];
//            statusImgV2.frame = CGRectMake(50+(ScreenWidth-120)/4*i, 80, 25, 25);
//            statusImgV2.image = [UIImage imageNamed:@"lottery_yes"];
//            if ([self.schemeListArry[i] intValue] == 601) {
//                statusImgV2.image = [UIImage imageNamed:@"lottery_no"];
//            }
//
//        }
//
//    }
    
    
//    UIView *lineView22 =  [[UIView alloc] init];
//    [_bottomBgView addSubview:lineView22];
//    lineView22.backgroundColor = LineColor;
//    [lineView22 mas_makeConstraints:^(MASConstraintMaker *make) {
//        make.left.right.mas_equalTo(self);
//        make.top.mas_equalTo(lineView.mas_bottom).offset(50);
//        make.height.mas_equalTo(5);
//    }];
    
    
    _liebiaoview = [[JCGendanSectionHeadView alloc]init];
    _liebiaoview.titleLabel.text = @"推荐列表";
    _liebiaoview.reJineListbutton .hidden = YES;
     _liebiaoview.reRSListbutton.hidden = YES;
     _liebiaoview.reDSListbutton.hidden = YES;
    _liebiaoview.rightMiaoshuLabel.hidden = YES;
    _liebiaoview.arrowImage.hidden = YES;
    _liebiaoview.tuijainLabel.hidden = YES;
    [self addSubview:_liebiaoview];
    
    [_liebiaoview mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(self.mas_left).offset(0);
        
        make.top.mas_equalTo(lineView.mas_bottom).offset(5);
        make.size.mas_equalTo(CGSizeMake(ScreenWidth, 40));
    }];
    
    [_backButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(_topBgImageView.mas_top).offset(STATUSH);
        make.left.mas_equalTo(_topBgImageView.mas_left).offset(0);
        make.size.mas_equalTo(CGSizeMake(50, 44));
    }];
    
    [_titleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.mas_equalTo(_topBgImageView.mas_centerX);
        make.top.mas_equalTo(_topBgImageView.mas_top).offset(iPhoneX?40:30);
    }];
    [_icon mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(_topBgImageView.mas_left).offset(20);
        make.bottom.mas_equalTo(_topBgImageView.mas_bottom).offset(-25);
        make.size.mas_equalTo(CGSizeMake(36, 36));
    }];
    
    [_name mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(_icon.mas_right).offset(10);
        make.top.mas_equalTo(_icon.mas_top);
    }];
    
    [_fansLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(_icon.mas_right).offset(10);
        make.top.mas_equalTo(_name.mas_bottom).offset(4);
    }];
    
    [_foucsButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.mas_equalTo(_topBgImageView.mas_right).offset(-20);
        make.centerY.mas_equalTo(_icon.mas_centerY);
        make.size.mas_equalTo(CGSizeMake(62, 22));
    }];
    
    [_rencentLLLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        //        make.bottom.mas_equalTo(_bottomBgView.mas_centerY);
        make.top.mas_equalTo(_topBgImageView.mas_bottom).offset(10);
        make.centerX.mas_equalTo(_bottomBgView.mas_centerX).offset(- ScreenWidth / 3);
    }];
    
    [_rencentBangLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        //        make.bottom.mas_equalTo(_bottomBgView.mas_centerY);
        make.top.mas_equalTo(_topBgImageView.mas_bottom).offset(10);
        make.centerX.mas_equalTo(_bottomBgView.mas_centerX);
    }];
    
    [_rencentEarnLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        //        make.bottom.mas_equalTo(_bottomBgView.mas_centerY);
        make.top.mas_equalTo(_topBgImageView.mas_bottom).offset(10);
        make.centerX.mas_equalTo(_bottomBgView.mas_centerX).offset( ScreenWidth / 3);
    }];
    
    
    [_rencentLLWenzLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        //        make.top.mas_equalTo(_bottomBgView.mas_centerY);
        make.top.mas_equalTo(_rencentBangLabel.mas_bottom).offset(10);
        make.centerX.mas_equalTo(_bottomBgView.mas_centerX).offset(- ScreenWidth / 3);
    }];
    
    [_rencentBangWenzLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        //        make.top.mas_equalTo(_bottomBgView.mas_centerY);
        make.top.mas_equalTo(_rencentBangLabel.mas_bottom).offset(10);
        make.centerX.mas_equalTo(_bottomBgView.mas_centerX);
    }];
    
    [_rencentEarnWenzLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        //        make.top.mas_equalTo(_bottomBgView.mas_centerY);
        make.top.mas_equalTo(_rencentBangLabel.mas_bottom).offset(10);
        make.centerX.mas_equalTo(_bottomBgView.mas_centerX).offset( ScreenWidth / 3);
    }];
}
#pragma mark - 根据颜色获取图片
- (UIImage *)createImageWithColor:(UIColor *)color
{
    //图片尺寸
    CGRect rect = CGRectMake(0, 0, 62, 22);
    //填充画笔
    UIGraphicsBeginImageContext(rect.size);
    //根据所传颜色绘制
    CGContextRef context = UIGraphicsGetCurrentContext();
    CGContextSetFillColorWithColor(context, color.CGColor);
    //显示区域
    CGContextFillRect(context, rect);
    // 得到图片信息
    UIImage * image = UIGraphicsGetImageFromCurrentImageContext();
    //消除画笔
    UIGraphicsEndImageContext();
    return image;
}
- (void)foucsButtonAction:(UIButton *)button{
    //    button.selected = !button.selected;
    //    if (button.selected) {
    //        NSLog(@"已关注");
    //    }else{
    //        NSLog(@"未关注");
    //    }
    if ([self.delegate respondsToSelector:@selector(clickFocusDSButton:)]) {
        [self.delegate clickFocusDSButton:button];
    }
    
}
- (void)backButton:(UIButton *)button{
    if ([self.delegate respondsToSelector:@selector(clickDSBackButton:)]) {
        [self.delegate clickDSBackButton:button];
    }
    
}

//-(void)setSchemeListArry:(NSArray *)schemeListArry{
//    if (self.schemeListArry.count > 0) {
//
//        for (int i = 0; i<self.schemeListArry.count; i++) {
//            UIImageView *statusImgV2= [[UIImageView alloc] init];
//            [_bottomBgView addSubview:statusImgV2];
//            statusImgV2.frame = CGRectMake(50+(ScreenWidth-120)/4*i, 80, 25, 25);
//            statusImgV2.image = [UIImage imageNamed:@"lottery_yes"];
//            if ([self.schemeListArry[i] intValue] == 601) {
//                statusImgV2.image = [UIImage imageNamed:@"lottery_no"];
//            }
//        }
//    }
//}





@end
