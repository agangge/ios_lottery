//
//  JCGendanDetailHeaderView.h
//  JiCaiLottery
//
//  Created by Peng Jun on 2017/11/27.
//  Copyright © 2017年 JiCaiLottery. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface JCGendanDetailHeaderView : UITableViewHeaderFooterView
@property (nonatomic, strong)UILabel *leftLabel;
@property (nonatomic, strong)UILabel *loteryLabel;
@property (nonatomic, strong)UILabel *zhushuLable;
@end
