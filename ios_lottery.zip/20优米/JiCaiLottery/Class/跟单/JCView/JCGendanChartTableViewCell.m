//
//  JCGendanChartTableViewCell.m
//  JiCaiLottery
//
//  Created by Peng Jun on 2018/5/22.
//  Copyright © 2018年 JiCaiLottery. All rights reserved.
//

#import "JCGendanChartTableViewCell.h"
#import "JCHeader.h"
#import "JCGendanRankModel.h"
#import "NSString+DecimalsCalculation.h"
#import "JCDecimalNumberTool.h"
@implementation JCGendanChartTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}
- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        [self createUI];
    }
    return self;
}
- (void)createUI{
    _rateLabel = [[UILabel alloc]init];
    _rateLabel.textColor = JCTTTColor;
    _rateLabel.text = @"1";
    _rateLabel.font = FONT(14);
    [self.contentView addSubview:_rateLabel];
    
    _iconImage = [[UIImageView alloc]init];
    _iconImage.layer.cornerRadius = 18;
    _iconImage.layer.masksToBounds = YES;
    _iconImage.backgroundColor = [UIColor grayColor];
    _iconImage.contentMode = UIViewContentModeScaleAspectFill;
    [self.contentView addSubview:_iconImage];
    _cupImage = [[UIImageView alloc]init];
    [self.contentView addSubview:_cupImage];
    
    _nameLabel = [[UILabel alloc]init];
    _nameLabel.textColor = JCTTTColor;
    _nameLabel.text = @"一站成名";
    _nameLabel.font = FONT(14);
    [self.contentView addSubview:_nameLabel];
    
    _leftGrayLabel = [[UILabel alloc]init];
    _leftGrayLabel.textColor = JCTTTColor;
    _leftGrayLabel.text = @"推荐/命中率";
    _leftGrayLabel.font = FONT(12);
    [self.contentView addSubview:_leftGrayLabel];
    
    _leftRedLabel = [[UILabel alloc]init];
    _leftRedLabel.textColor = allRedColor;
    _leftRedLabel.text = @"推荐/命中率";
    _leftRedLabel.font = FONT(12);
    [self.contentView addSubview:_leftRedLabel];
    
    _pelpeoLabel = [[UILabel alloc]init];
    _pelpeoLabel.textColor = allRedColor;
    _pelpeoLabel.textAlignment = NSTextAlignmentRight;
    _pelpeoLabel.text = @"79271294712";
    _pelpeoLabel.font = FONT(14);
    [self.contentView addSubview:_pelpeoLabel];
    
    _zhongjiangLabel = [[UILabel alloc]init];
    _zhongjiangLabel.textColor = JCTTTColor;
     _zhongjiangLabel.textAlignment = NSTextAlignmentRight;
    _zhongjiangLabel.text = @"推荐中奖(元）";
    _zhongjiangLabel.font = FONT(12);
    [self.contentView addSubview:_zhongjiangLabel];
    
    [_rateLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.mas_equalTo(self.contentView.mas_centerY);
        make.left.mas_equalTo(self.contentView.mas_left).offset(28);
    }];
    [_cupImage mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.mas_equalTo(self.contentView.mas_centerY);
        make.left.mas_equalTo(self.contentView.mas_left).offset(20);
        make.size.mas_equalTo(CGSizeMake(24, 24));
    }];
    [_iconImage mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.mas_equalTo(self.contentView.mas_centerY);
        make.left.mas_equalTo(self.contentView.mas_left).offset(50);
        make.size.mas_equalTo(CGSizeMake(36, 36));
    }];
    
    [_nameLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(_iconImage.mas_right).offset(6);
        make.top.mas_equalTo(_iconImage.mas_top);
    }];
    
    [_leftGrayLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(_iconImage.mas_right).offset(6);
        make.top.mas_equalTo(_nameLabel.mas_bottom).offset(3);
    }];
    
    [_leftRedLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(_leftGrayLabel.mas_right).offset(1);
        make.top.mas_equalTo(_nameLabel.mas_bottom).offset(3);
    }];
    [_pelpeoLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.mas_equalTo(self.contentView.mas_right).offset(-20);
        make.bottom.mas_equalTo(self.contentView.mas_centerY).offset(-2);
    }];
    [_zhongjiangLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.mas_equalTo(self.contentView.mas_right).offset(-20);
        make.top.mas_equalTo(self.contentView.mas_centerY).offset(2);
    }];
}
//- (void)setModel:(JCGendanRankModel *)model{
//    _model = model;
//
//}
- (void)listModel:(JCGendanRankModel*)model listType:(NSInteger)listType Rank:(NSInteger)rank{
    if (rank == 0) {
        _cupImage.image = [UIImage imageNamed:@"gendan_guanjun"];
        _cupImage.hidden = NO;
        _rateLabel.hidden = YES;
    }else if (rank == 1){
        _cupImage.image = [UIImage imageNamed:@"gendan_yajun"];
        _cupImage.hidden = NO;
        _rateLabel.hidden = YES;
    }else if (rank == 2){
        _cupImage.image = [UIImage imageNamed:@"gendan_jijun"];
        _cupImage.hidden = NO;
        _rateLabel.hidden = YES;
    }else{
        _cupImage.hidden = YES;
        _rateLabel.hidden = NO;
        _rateLabel.text = [NSString stringWithFormat:@"%ld",rank+1];
    }
    _nameLabel.text = model.userName?model.userName:@"一站成名";
    [_iconImage sd_setImageWithURL:[NSURL URLWithString:model.avatar] placeholderImage:[UIImage imageNamed:@"mine_defaul_icon"]];
    if (listType == 1) {
        [_nameLabel mas_updateConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(_iconImage.mas_right).offset(6);
            make.top.mas_equalTo(_iconImage.mas_top);
        }];
        _leftGrayLabel.hidden = NO;
        _leftRedLabel.hidden = NO;
        _leftGrayLabel.text = @"命中率";
        _leftRedLabel.text = [NSString stringWithFormat:@"%@%%",[model.weekHitRatio stringValue]];

        _pelpeoLabel.text =[NSString stringWithFormat:@"%@%%", [JCDecimalNumberTool stringWithDecimaNumber:[model.weekGain doubleValue]]];
        _zhongjiangLabel.text = @"周盈利率";
    }else if (listType == 2){
        [_nameLabel mas_updateConstraints:^(MASConstraintMaker *make) {
            make.centerY.mas_equalTo(self.contentView.mas_centerY);
             make.left.mas_equalTo(_iconImage.mas_right).offset(6);
        }];
        _leftGrayLabel.hidden = YES;
        _leftRedLabel.hidden = YES;
        _pelpeoLabel.text = [NSString stringWithFormat:@"%@中%@",[model.weekBetCount stringValue],[model.weekHitCount stringValue]];
        _zhongjiangLabel.text = @"近7天命中率";
        
    }else if (listType == 3){
        [_nameLabel mas_updateConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(_iconImage.mas_right).offset(6);
            make.top.mas_equalTo(_iconImage.mas_top);
        }];
        _leftGrayLabel.hidden = NO;
        _leftRedLabel.hidden = NO;
        _leftGrayLabel.text = @"推单：";
        _leftRedLabel.text = [NSString stringWithFormat:@"%@中%@",[model.weekBetCount stringValue],[model.weekHitCount stringValue]];
        _pelpeoLabel.text = [NSString stringWithFormat:@"%@",[model.allHitPrize stringValue]];
        _zhongjiangLabel.text = @"推荐中奖(元)";
    }
}
- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
