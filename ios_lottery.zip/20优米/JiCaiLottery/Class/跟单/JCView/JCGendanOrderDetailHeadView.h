//
//  JCGendanOrderDetailHeadView.h
//  JiCaiLottery
//
//  Created by Dxc_iOS on 2019/4/26.
//  Copyright © 2019 JiCaiLottery. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface JCGendanOrderDetailHeadView : UIView
@property (nonatomic, strong)UIImageView *touImgV;//头像
@property (nonatomic, strong)UILabel *nameLab;//姓名
@property (nonatomic, strong)UILabel *IdLab;//ID
@property (nonatomic, strong)UILabel *endTimeLab;//截止时间

@property (nonatomic, strong)UIImageView *statusImgV;//中奖状态图片
@property (nonatomic, strong)UILabel *describeLab;//宣言
@property (nonatomic, strong)UILabel *danBeiMoneyLab;//单倍金额
@property (nonatomic, strong)UILabel *tichengLab;//方案提成
@property (nonatomic, strong)UILabel *followNameLab;//跟单于谁

@property (nonatomic, strong)UILabel *titleLabel;
@property (nonatomic, strong)UILabel *moneyLabel;
@property (nonatomic, strong)UILabel *statueLabel;
@property (nonatomic, strong)UILabel *zhongJiangLabel;
@property (nonatomic, strong)UILabel *bianhaoLabel;
@property (nonatomic, copy)NSString *titleStr;
@property (nonatomic, copy)NSString *moneyStr;
@property (nonatomic, copy)NSString *statueStr;
@property (nonatomic, copy)NSString *zhongJiangStr;
@property (nonatomic, copy)NSString *bianhaoStr;
@property (nonatomic, strong)UILabel *jiaJiangLabel;
@property (nonatomic, copy)NSString *jiaJiangStr;

//@property (nonatomic, copy)NSString *describeStr;

- (instancetype)initWithFrame:(CGRect)frame
                    dataArray:(NSMutableArray *)dataArray
                        prize:(NSString *)prize;
@end

NS_ASSUME_NONNULL_END
