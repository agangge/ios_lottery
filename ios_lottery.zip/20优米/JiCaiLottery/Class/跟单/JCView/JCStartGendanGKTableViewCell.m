//
//  JCStartGendanGKTableViewCell.m
//  JiCaiLottery
//
//  Created by Peng Jun on 2017/11/23.
//  Copyright © 2017年 JiCaiLottery. All rights reserved.
//

#import "JCStartGendanGKTableViewCell.h"
#import "JCHeader.h"
@implementation JCStartGendanGKTableViewCell{
    
    UIView *bottomView;
}

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        self.contentView.backgroundColor = UICOLOR_HEX(0xF7F6F6);
        [self createCell];
    }
    return self;
}
- (void)createCell{
    UIView *view = [[UIView alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, 35)];
    view.backgroundColor = allWhiteColor;
    [self.contentView addSubview:view];
    UILabel *line = [[UILabel alloc]initWithFrame:CGRectMake(0, 34.5, ScreenWidth, 0.5)];
    line.backgroundColor = UICOLOR_HEX(0xf0f0f0);
    [view addSubview:line];
    _topLabel = [[UILabel alloc] init];
    _topLabel.font = FONT(14);
    _topLabel.textColor = UICOLOR_HEX(0x333333);
    _topLabel.text = @"方案金额  2注  1倍 1期  共4元";
    [view addSubview:_topLabel];
    [_topLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.mas_equalTo(view);
        make.left.mas_equalTo(view.mas_left).offset(15);
    }];
    
    
    bottomView = [[UIView alloc]initWithFrame:CGRectMake(0, 35, ScreenWidth, 100+20)];
    bottomView.backgroundColor = allWhiteColor;
    [self.contentView addSubview:bottomView];
    
    UILabel *fanan = [[UILabel alloc] init];
    fanan.frame = CGRectMake(15, 13, 120*ScreenScale, 15);
    fanan.font = FONT(14);
    fanan.textColor = UICOLOR_HEX(0x333333);
    fanan.text = @"方案是否公开";
    [bottomView addSubview:fanan];
//    UIImage *normalImage = [UIImage imageNamed:@"lilun_normal"];
    UIImage *selectedImage = [UIImage imageNamed:@"lilun_selected"];
    NSArray *arr = @[@"完全公开",@"截止后公开",@"跟单可见",@"完全保密",@"开奖后公开"];
//  完全公开  1 、   截止后公开4   跟单可见 3  完全保密  2
//    开奖后公开 5
    for (int i = 0; i<arr.count; i++) {
        
        CGFloat width = (ScreenWidth- 6*3-30) /4;
        CGFloat x = (i%4)*(width+6)+15;
        CGFloat height = 26.f;
        CGFloat y = i<4?48.f:80.f;//48.f;
        
        UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
        button.frame = CGRectMake(x, y, width, height);
        [button setTitleColor:UICOLOR_HEX(0xE62F1A) forState:UIControlStateSelected];
        [button setTitleColor:UICOLOR_HEX(0x333333) forState:UIControlStateNormal];
        button.backgroundColor = UICOLOR_HEX(0xf5f5f5);
        button.layer.cornerRadius = 3;
        button.layer.masksToBounds = YES;
//        [button setBackgroundImage:normalImage forState:UIControlStateNormal];
        [button setBackgroundImage:selectedImage forState:UIControlStateSelected];
        [button setTitle:arr[i] forState:UIControlStateNormal];
        if (i == 0) {//完全公开 1 (100-99)
            button.tag = 100;
        }else if (i ==1){//截止后公开 4 (103-99)
            button.tag = 103;
        }else if (i ==2){//跟单可见3 (102-99)
            button.tag = 102;
        }else if (i ==3){//完全保密 2 (101-99)
            button.tag = 101;
        }
        else if (i ==4){//开奖后公开 5 (104-99)
            button.tag = 104;
        }
        if (i == 1) {
            button.selected = YES;
        }
        button.titleLabel.font = FONT(14);
        [button addTarget:self action:@selector(buttonAction:) forControlEvents:UIControlEventTouchUpInside];
        [bottomView addSubview:button];
    }
    
}
- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}
- (void)buttonAction:(UIButton *)button{
    for (UIButton *btn in bottomView.subviews) {
        if ([btn isKindOfClass:[UIButton class]]) {
            if (btn.tag == button.tag) {
                btn.selected = YES;
            }else if(btn.tag == 99){
//                btn.selected = NO;
            }else{
                btn.selected = NO;
            }
            
        }
    }
    if (self.gkBlcok) {

        self.gkBlcok(button.titleLabel.text, button.tag);
//        JCLog(@"button.titleLabel.text = %@",button.titleLabel.text)
    }
}
- (void)setDanbeiJine:(NSString *)danbeiJine{
    _danbeiJine = danbeiJine;
    _topLabel.text = [NSString stringWithFormat:@"方案金额  2注  1倍 1期  共%@元",_danbeiJine];
//     _topLabel.text = @"方案金额  2注  1倍 1期  共4元";
}
@end
