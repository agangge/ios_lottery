//
//  JCGendanDSButtonCell.m
//  JiCaiLottery
//
//  Created by Peng Jun on 2018/5/23.
//  Copyright © 2018年 JiCaiLottery. All rights reserved.
//

#import "JCGendanDSButtonCell.h"

@implementation JCGendanDSButtonCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}
- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        [self createUI];
    }
    return self;
}
- (void)createUI{
    
}
- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
