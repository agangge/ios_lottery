//
//  JCStartGendanMSTableViewCell.h
//  JiCaiLottery
//
//  Created by Peng Jun on 2017/11/23.
//  Copyright © 2017年 JiCaiLottery. All rights reserved.
//

#import <UIKit/UIKit.h>
typedef void (^MsButtonBlock)(NSString *buttonString);
@interface JCStartGendanMSTableViewCell : UITableViewCell<UITextViewDelegate>
@property (nonatomic, copy)MsButtonBlock msBlcok;
@end
