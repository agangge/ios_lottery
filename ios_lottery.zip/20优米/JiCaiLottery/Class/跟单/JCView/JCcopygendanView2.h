//
//  JCcopygendanView2.h
//  JiCaiLottery
//
//  Created by Dxc_iOS on 2019/5/22.
//  Copyright © 2019 JiCaiLottery. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "PPNumberButton2.h"

NS_ASSUME_NONNULL_BEGIN
@class JCGendanCopyModel;
@interface JCcopygendanView2 : UIView
@property (nonatomic, strong) PPNumberButton2 *numberButton;
@property (nonatomic, strong) JCGendanCopyModel *model;
@property (nonatomic, strong)UILabel *jineLabel;
@end

NS_ASSUME_NONNULL_END
