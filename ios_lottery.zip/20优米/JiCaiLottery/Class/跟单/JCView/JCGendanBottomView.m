//
//  JCGendanBottomView.m
//  JiCaiLottery
//
//  Created by Peng Jun on 2017/11/22.
//  Copyright © 2017年 JiCaiLottery. All rights reserved.
//

#import "JCGendanBottomView.h"

@implementation JCGendanBottomView

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
