//
//  JCcopygendanView2.m
//  JiCaiLottery
//
//  Created by Dxc_iOS on 2019/5/22.
//  Copyright © 2019 JiCaiLottery. All rights reserved.
//

#import "JCcopygendanView2.h"
#import "JCHeader.h"
#import "JCGendanCopyModel.h"
#import "PPNumberButton2.h"
@interface JCcopygendanView2()<PPNumberButton2Delegate>
@end
@implementation JCcopygendanView2
{
    //    UILabel *_jineLabel;
    UILabel *_topLabel;
    UILabel *_duixiangLabel;
    UILabel *_danbeiLabel;
    UILabel *_yongjinbiliLabel;
    UILabel *_jiezhishijianLabel;
    
    UIButton *_addButton;
    UIButton *_subButton;
    UITextField *_textFiled;
    
}

- (instancetype)initWithFrame:(CGRect)frame{
    if (self = [super initWithFrame:frame]) {
        [self createView];
    }
    return self;
}
- (void)createView{
    UIView *view = [[UIView alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, 90)];
    view.backgroundColor = allWhiteColor;
    [self addSubview:view];
    UILabel *line = [[UILabel alloc]initWithFrame:CGRectMake(0, 89.5, ScreenWidth, 0.5)];
    line.backgroundColor = UICOLOR_HEX(0xF0F0F0);
    [view addSubview:line];
    _topLabel = [[UILabel alloc] init];
    _topLabel.font = FONT(15);
    _topLabel.textColor = UICOLOR_HEX(0x333333);
    _topLabel.text = @"跟单金额（元）";
    
    _jineLabel = [[UILabel alloc] init];
    _jineLabel.font = FONT(30);
    _jineLabel.textColor = UICOLOR_HEX(0xE62F1A);
    _jineLabel.text = @"400.00";
    [view sd_addSubviews:@[_topLabel,_jineLabel]];
    _topLabel.sd_layout
    .topSpaceToView(view, 15)
    .leftSpaceToView(view, 15)
    .widthIs(ScreenWidth - 15);
    
    _jineLabel.sd_layout
    .bottomSpaceToView(line, 12)
    .leftSpaceToView(view, 15)
    .widthIs(ScreenWidth - 15)
    .heightIs(30);
    
    
    UIView *bottomView = [[UIView alloc]initWithFrame:CGRectZero];
    bottomView.backgroundColor = allWhiteColor;
    [self addSubview:bottomView];
    
    UILabel *GDBS = [[UILabel alloc] init];
    GDBS.font = FONT(15);
    GDBS.textColor = UICOLOR_HEX(0x333333);
    GDBS.text = @"跟单倍数";
    [bottomView addSubview:GDBS];
    
    _numberButton = [PPNumberButton2 numberButtonWithFrame:CGRectZero];
    _numberButton.borderColor = [UIColor grayColor];
    _numberButton.increaseTitle = @"＋";
    _numberButton.decreaseTitle = @"－";
    
    _numberButton.shakeAnimation = YES;
    _numberButton.minValue = 1;
    _numberButton.maxValue = 99999;
    _numberButton.currentNumber = 1;
    
    _numberButton.delegate = self;
    _numberButton.longPressSpaceTime = CGFLOAT_MAX;
    
    [bottomView addSubview:_numberButton];
    
    UILabel *GDDX = [[UILabel alloc] init];
    GDDX.font = FONT(15);
    GDDX.textColor = UICOLOR_HEX(0x333333);
    GDDX.text = @"跟单对象";
    [bottomView addSubview:GDDX];
    
    _duixiangLabel= [[UILabel alloc] init];
    _duixiangLabel.font = FONT(15);
    _duixiangLabel.textColor = UICOLOR_HEX(0xE62F1A);
    _duixiangLabel.text = @"我是阿兰";
    [bottomView addSubview:_duixiangLabel];
    
    UILabel *DBJE = [[UILabel alloc] init];
    DBJE.font = FONT(15);
    DBJE.textColor = UICOLOR_HEX(0x333333);
    DBJE.text = @"单倍金额";
    [bottomView addSubview:DBJE];
    
    _danbeiLabel= [[UILabel alloc] init];
    _danbeiLabel.font = FONT(15);
    _danbeiLabel.textColor = UICOLOR_HEX(0x666666);
    _danbeiLabel.text = @"2.00";
    [bottomView addSubview:_danbeiLabel];
    
    UILabel *YJBL = [[UILabel alloc] init];
    YJBL.font = FONT(15);
    YJBL.textColor = UICOLOR_HEX(0x333333);
    YJBL.text = @"佣金比例";
    [bottomView addSubview:YJBL];
    
    _yongjinbiliLabel= [[UILabel alloc] init];
    _yongjinbiliLabel.font = FONT(15);
    _yongjinbiliLabel.textColor = UICOLOR_HEX(0x666666);
    _yongjinbiliLabel.text = @"2%";
    [bottomView addSubview:_yongjinbiliLabel];
    
    UILabel *JZSJ = [[UILabel alloc] init];
    JZSJ.font = FONT(15);
    JZSJ.textColor = UICOLOR_HEX(0x333333);
    JZSJ.text = @"截止时间";
    [bottomView addSubview:JZSJ];
    
    _jiezhishijianLabel= [[UILabel alloc] init];
    _jiezhishijianLabel.font = FONT(15);
    _jiezhishijianLabel.textColor = UICOLOR_HEX(0x666666);
    _jiezhishijianLabel.text = @"12.12.11";
    [bottomView addSubview:_jiezhishijianLabel];
    
    [GDBS mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(bottomView.mas_left).offset(15);
        make.top.mas_equalTo(bottomView.mas_top).offset(23);
    }];
    
    [_numberButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.mas_equalTo(bottomView.mas_right).offset(-15);
        make.centerY.mas_equalTo(GDBS.mas_centerY);
        make.size.mas_equalTo(CGSizeMake(170, 30));
    }];
    
    [GDDX mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(bottomView.mas_left).offset(15);
        make.top.mas_equalTo(GDBS.mas_bottom).offset(27);
    }];
    
    [_duixiangLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.mas_equalTo(bottomView.mas_right).offset(-15);
        make.centerY.mas_equalTo(GDDX.mas_centerY);
    }];
    
    
    [DBJE mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(bottomView.mas_left).offset(15);
        make.top.mas_equalTo(GDDX.mas_bottom).offset(20);
    }];
    
    [_danbeiLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.mas_equalTo(bottomView.mas_right).offset(-15);
        make.centerY.mas_equalTo(DBJE.mas_centerY);
    }];
    
    
    [YJBL mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(bottomView.mas_left).offset(15);
        make.top.mas_equalTo(DBJE.mas_bottom).offset(20);
    }];
    
    [_yongjinbiliLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.mas_equalTo(bottomView.mas_right).offset(-15);
        make.centerY.mas_equalTo(YJBL.mas_centerY);
    }];
    
    
    [JZSJ mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(bottomView.mas_left).offset(15);
        make.top.mas_equalTo(YJBL.mas_bottom).offset(20);
    }];
    
    [_jiezhishijianLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.mas_equalTo(bottomView.mas_right).offset(-15);
        make.centerY.mas_equalTo(JZSJ.mas_centerY);
    }];
    [bottomView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(view.mas_bottom);
        make.left.right.mas_equalTo(self);
        make.bottom.mas_equalTo(_jiezhishijianLabel.mas_bottom).offset(30);
    }];
    
    
}
- (void)setModel:(JCGendanCopyModel *)model{
    _model  =model;
    //    UILabel *_jineLabel;
    //    UILabel *_topLabel;
    //    UILabel *_duixiangLabel;
    //    UILabel *_danbeiLabel;
    //    UILabel *_yongjinbiliLabel;
    //    UILabel *_jiezhishijianLabel;
    //    _jineLabel.text = _model.singleMultipleMoney;
    _duixiangLabel.text = _model.gendan_user;
    _danbeiLabel.text = _model.singleMultipleMoney;
    _yongjinbiliLabel.text =[NSString stringWithFormat:@"%@%%", _model.remuneration];
    NSString *clipendtime = [_model.endTime substringFromIndex:5];
    NSString *endtime = [clipendtime substringToIndex:clipendtime.length - 3];
    _jiezhishijianLabel.text = endtime;
    _jineLabel.text =_model.singleMultipleMoney;
    
}
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
