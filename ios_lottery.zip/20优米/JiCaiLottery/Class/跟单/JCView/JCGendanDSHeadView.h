//
//  JCGendanDSHeadView.h
//  JiCaiLottery
//
//  Created by Peng Jun on 2018/5/24.
//  Copyright © 2018年 JiCaiLottery. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol JCGendanDSHeadViewDelegate <NSObject>

- (void)clickFocusDSButton:(UIButton *)sender;
- (void)clickDSBackButton:(UIButton *)sender;
@end

@interface JCGendanDSHeadView : UIView

@property (nonatomic, strong)UILabel * titleLabel;
@property (nonatomic, strong)UILabel *name;
@property (nonatomic, strong)UIImageView *icon;
@property (nonatomic, strong)UILabel *fansLabel;
@property (nonatomic, strong)UIButton *foucsButton;
@property (nonatomic, copy)NSString *recentYLL;
@property (nonatomic, copy)NSString *recentYLStatus;
@property (nonatomic, copy)NSString *recentEarnMoney;
@property (nonatomic, strong)UILabel * rencentLLLabel;
@property (nonatomic, strong)UILabel * rencentEarnLabel;
@property (nonatomic, strong)UIButton* backButton;
@property (nonatomic, strong)UILabel * rencentBangLabel;
@property (nonatomic, weak)id<JCGendanDSHeadViewDelegate>delegate;

@property (nonatomic, strong) UIView *bottomBgView;
//为近5场开奖订单的中奖结果：601为未中奖，501为中奖。（若用户已开奖订单不足，则可能为空或不足5）
@property (nonatomic, strong) NSArray *schemeListArry;

@end
