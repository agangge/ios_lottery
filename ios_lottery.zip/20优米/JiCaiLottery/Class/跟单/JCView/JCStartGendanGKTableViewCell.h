//
//  JCStartGendanGKTableViewCell.h
//  JiCaiLottery
//
//  Created by Peng Jun on 2017/11/23.
//  Copyright © 2017年 JiCaiLottery. All rights reserved.
//

#import <UIKit/UIKit.h>
typedef void (^GKButtonBlock)(NSString *buttonString,NSInteger buttonIndex);
@interface JCStartGendanGKTableViewCell : UITableViewCell
@property (nonatomic, copy)GKButtonBlock gkBlcok;
@property (nonatomic, copy)NSString *danbeiJine;
@property (nonatomic, strong)UILabel *topLabel;
@end
