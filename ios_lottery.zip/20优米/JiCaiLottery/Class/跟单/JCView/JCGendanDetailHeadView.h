//
//  JCGendanDetailHeadView.h
//  JiCaiLottery
//
//  Created by Peng Jun on 2017/11/24.
//  Copyright © 2017年 JiCaiLottery. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface JCGendanDetailHeadView : UIView
@property (nonatomic, strong)UIImageView *touImgV;//头像
@property (nonatomic, strong)UILabel *nameLab;//姓名
@property (nonatomic, strong)UILabel *IdLab;//ID
@property (nonatomic, strong)UILabel *endTimeLab;//截止时间
@property (nonatomic, strong)UILabel *describeLab;//宣言
@property (nonatomic, strong)UILabel *danBeiMoneyLab;//单倍金额
@property (nonatomic, strong)UILabel *tichengLab;//方案提成
@property (nonatomic, strong)UILabel *followNameLab;//跟单于谁

@property (nonatomic, strong)UILabel *titleLabel;
@property (nonatomic, strong)UILabel *moneyLabel;
@property (nonatomic, strong)UILabel *statueLabel;
@property (nonatomic, strong)UILabel *zhongJiangLabel;
@property (nonatomic, strong)UILabel *bianhaoLabel;
@property (nonatomic, copy)NSString *titleStr;
@property (nonatomic, copy)NSString *moneyStr;
@property (nonatomic, copy)NSString *statueStr;
@property (nonatomic, copy)NSString *zhongJiangStr;
@property (nonatomic, copy)NSString *bianhaoStr;
@property (nonatomic, strong)UILabel *jiaJiangLabel;
@property (nonatomic, copy)NSString *jiaJiangStr;

//@property (nonatomic, copy)NSString *describeStr;


- (instancetype)initWithFrame:(CGRect)frame
                    dataArray:(NSMutableArray *)dataArray
                        prize:(NSString *)prize;
@end
