//
//  JCGendanDetailMessageCell.m
//  JiCaiLottery
//
//  Created by Peng Jun on 2017/11/24.
//  Copyright © 2017年 JiCaiLottery. All rights reserved.
//

#import "JCGendanDetailMessageCell.h"
#import "JCHeader.h"
#import "UIView+excelForm.h"
@implementation JCGendanDetailMessageCell{
    
}
- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        //        [self createView];
        [self setupContentView];
    }
    return self;
}


-(void)setupContentView{
    
    self.gendanNameLab = [[UILabel alloc]init];
    //    self.gendanNameLab.backgroundColor = allLineColor;
    self.gendanNameLab.textColor = JCTTTColor;//ColorRGB(51, 51, 51, 1);
    self.gendanNameLab.textAlignment = NSTextAlignmentCenter;
    self.gendanNameLab.numberOfLines = 0;
    self.gendanNameLab.font = [UIFont systemFontOfSize:13.f];
    
    self.gendanMoneyLab = [[UILabel alloc]init];
    //    self.gendanMoneyLab.backgroundColor = allLineColor;
    self.gendanMoneyLab.numberOfLines = 0;
    self.gendanMoneyLab.textAlignment = NSTextAlignmentCenter;
    self.gendanMoneyLab.textColor = JCTTTColor;//ColorRGB(51, 51, 51, 1);
    self.gendanMoneyLab.font = [UIFont systemFontOfSize:13.f];
    
    self.gendanTimeLab = [[UILabel alloc]init];
    //    self.gendanTimeLab.backgroundColor = allLineColor;
    self.gendanTimeLab.textAlignment = NSTextAlignmentCenter;
    self.gendanTimeLab.textColor = ColorRGB(51, 51, 51, 1);
    self.gendanTimeLab.font = [UIFont systemFontOfSize:13.f];
    self.gendanTimeLab.numberOfLines = 0;
    self.gendanTimeLab.adjustsFontSizeToFitWidth = YES;
    
    
    self.jiangjinLab = [[UILabel alloc]init];
    //    self.jiangjinLab.backgroundColor = allLineColor;
    self.jiangjinLab.textAlignment = NSTextAlignmentCenter;
    self.jiangjinLab.textColor = ColorRGB(51, 51, 51, 1);
    self.jiangjinLab.font = [UIFont systemFontOfSize:10.f];
    self.jiangjinLab.numberOfLines = 0;
    
    CGFloat w = (ScreenWidth-10)/4;
    
    [self sd_addSubviews:@[self.gendanNameLab, self.gendanMoneyLab, self.gendanTimeLab, self.jiangjinLab]];
    self.gendanNameLab.sd_layout
    .leftSpaceToView(self, 10)
    .topSpaceToView(self, 0)
    //    .widthRatioToView(self, 0.25)
    .widthIs(w)
    .heightRatioToView(self, 1);
    
    self.gendanMoneyLab.sd_layout
    .leftSpaceToView(self.gendanNameLab, 0)
    .topSpaceToView(self, 0)
    //    .widthRatioToView(self, 0.25)
    .widthIs(w)
    .heightRatioToView(self, 1);
    
    self.gendanTimeLab.sd_layout
    .leftSpaceToView(self.gendanMoneyLab, 0)
    .topSpaceToView(self, 0)
    //    .widthRatioToView(self, 0.25)
    .widthIs(w)
    .heightRatioToView(self, 1);
    
    self.jiangjinLab.sd_layout
    .leftSpaceToView(self.gendanTimeLab, 0)
    .topSpaceToView(self, 0)
    //    .widthRatioToView(self, 0.25)
    .widthIs(w)
    .heightRatioToView(self, 1);
    
    
    
    //       中 分割线
    
    for (int y = 0; y <  4+1; y++) {
        CGFloat ww = (ScreenWidth-20)/4;
        UIView *line = [[UIView alloc] initWithFrame:CGRectZero];
        [self.contentView addSubview:line];
        line.backgroundColor = [UIColor lightGrayColor];
        
        [line mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(self.contentView.mas_top).offset(0);
            make.bottom.mas_equalTo(self.contentView.mas_bottom).offset(-0.5);
            make.left.mas_equalTo(self.contentView.mas_left).offset(10+ww*y);
            make.width.mas_equalTo(0.5);
        }];
        
    }
    
    
    //       下 分割线
    UIView *verline2 = [[UIView alloc] initWithFrame:CGRectZero];
    [self.contentView addSubview:verline2];
    verline2.backgroundColor = [UIColor lightGrayColor];
    [verline2 mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.mas_equalTo(self.contentView.mas_bottom).offset(-0.5);
        make.left.mas_equalTo(self.contentView.mas_left).offset(10);
        make.right.mas_equalTo(self.contentView.mas_right).offset(-10);
        make.height.mas_equalTo(0.5);
    }];
    
    
    
    
    
    
    
    
    
}



-(void)configModel:(JCgendanListModel *)gendanListModel with:(NSArray *)arr{
    
    gendanListModel = arr[0];
    
    self.gendanNameLab.text = gendanListModel.username;
    self.gendanMoneyLab.text = gendanListModel.money;
    self.gendanTimeLab.text = gendanListModel.time;
    self.jiangjinLab.text = gendanListModel.price;
    
    
    
    
    
    
    
}






- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
    
    // Configure the view for the selected state
}

@end
