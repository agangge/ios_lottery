//
//  JCGendanDetailHeadView.m
//  JiCaiLottery
//
//  Created by Peng Jun on 2017/11/24.
//  Copyright © 2017年 JiCaiLottery. All rights reserved.
//

#import "JCGendanDetailHeadView.h"

#import "JCHeader.h"
#import "JCNumberModel.h"
#import "JCNumberSchemeDetailModel.h"

@implementation JCGendanDetailHeadView

- (instancetype)initWithFrame:(CGRect)frame dataArray:(NSMutableArray *)dataArray prize:(NSString *)prize

{
    self = [super initWithFrame:frame];
    if (self) {
        [self initWithUI:dataArray prize:prize];
    }
    return self;
}

- (void)initWithUI:(NSMutableArray *)dataArray prize:(NSString *)prize;
{
    //    头像
    self.touImgV = [[UIImageView alloc] init];
    self.touImgV.image = [UIImage imageNamed:@"mine_defaul_icon"];
    [self addSubview:self.touImgV];
    [self.touImgV mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self.mas_top).offset(5);
        
        make.left.mas_equalTo(self.mas_left).offset(15);
        make.size.mas_equalTo(CGSizeMake(40, 40));
    }];
    
    //    名称
    self.nameLab = [[UILabel alloc]init];
    self.nameLab.textColor = JCTTTColor;
    self.nameLab.font = FONT(14);
    self.nameLab.text = @"大神";
    [self addSubview:self.nameLab];
    
    [self.nameLab mas_makeConstraints:^(MASConstraintMaker *make) {
        //        make.top.mas_equalTo(self.mas_top).offset(5);
        make.centerY.mas_equalTo(self.touImgV.mas_centerY);
        make.left.mas_equalTo(self.touImgV.mas_right).offset(10);
        make.size.mas_equalTo(CGSizeMake(100, 20));
    }];
    //    Id
    //    self.IdLab = [[UILabel alloc]init];
    //    self.IdLab.textColor = JCTTTColor;
    //    self.IdLab.font = FONT(14);
    //    self.IdLab.text = @"ID:";
    //    [self addSubview:self.IdLab];
    //    [self.IdLab mas_makeConstraints:^(MASConstraintMaker *make) {
    //        make.left.mas_equalTo(self.touImgV.mas_right).offset(10);
    //        make.top.mas_equalTo(self.nameLab.mas_bottom).offset(0);
    //        make.size.mas_equalTo(CGSizeMake(100, 20));
    //    }];
    //    截止时间
    self.endTimeLab = [[UILabel alloc]init];
    self.endTimeLab.textColor = [UIColor grayColor];//JCTTTColor;
    self.endTimeLab.font = FONT(12);
    self.endTimeLab.text = @"2019-03-19 23:50:00截止";
    self.endTimeLab.textAlignment = NSTextAlignmentRight;
    [self addSubview:self.endTimeLab];
    [self.endTimeLab mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.mas_equalTo(self.mas_right).offset(-15);
        //        make.top.mas_equalTo(self.mas_top).offset(10);
        make.centerY.mas_equalTo(self.nameLab.mas_centerY);
        make.size.mas_equalTo(CGSizeMake(250, 20));
    }];
    
    
    
    //    分割线
    UIView *IdlineView = [[UIView alloc]init];
    IdlineView.backgroundColor = UICOLOR_HEX(0xeeeeee);
    [self addSubview:IdlineView];
    [IdlineView mas_makeConstraints:^(MASConstraintMaker *make) {
        
        make.top.mas_equalTo(self.touImgV.mas_bottom).offset(10);
        make.left.mas_equalTo(self.mas_left).offset(0);
        make.right.mas_equalTo(self.mas_right).offset(0);
        make.height.mas_equalTo(0.5);
    }];
    
    
    
    
    
    //    宣言lab 高度自适应
    self.describeLab = [[UILabel alloc]init];
    self.describeLab.textColor = JCTTTColor;
    self.describeLab.font = FONT(14);
    self.describeLab.text = @"今明两天无足球比赛,玩玩篮球.今明两天无足球比赛,玩玩篮球.今明两天无足球比赛,玩玩篮球.";;
    [self addSubview:self.describeLab];
    self.describeLab.numberOfLines = 0;//设置换行
    MASAttachKeys(self.describeLab);
    
    [self.describeLab mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(IdlineView.mas_bottom).offset(10);
        make.left.mas_equalTo(self.mas_left).offset(15);
        make.right.mas_equalTo(self.mas_right).offset(-15);
        //        make.bottom.mas_equalTo(self.mas_bottom);
    }];
    
    
    
    UIView *bgVieww = [[UIView alloc]init];
    bgVieww.backgroundColor = RGB(245, 245, 245);
    [self addSubview:bgVieww];
    [bgVieww mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(self.mas_left).offset(5);
        make.right.mas_equalTo(self.mas_right).offset(-5);
        make.top.mas_equalTo(self.describeLab.mas_bottom).offset(5*kFontScale);
        make.height.mas_equalTo(65*kScale);
    }];
    
    //    订单金额
    
    UILabel *money = [[UILabel alloc]init];
    money.numberOfLines = 0;
    money.textAlignment = NSTextAlignmentCenter;
    money.text = @" 订单金额";
    money.textColor = JCTTTColor;
    money.font = FONT(14);
    [bgVieww addSubview:money];
    [money mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(bgVieww.mas_top).offset(10);
        make.left.mas_equalTo(self.mas_left).offset(0);
        make.size.mas_equalTo(CGSizeMake(ScreenWidth/3, 20));
        
    }];
    
    self.moneyLabel = [[UILabel alloc]init];
    self.moneyLabel.numberOfLines = 0;
    self.moneyLabel.textAlignment = NSTextAlignmentCenter;
    self.moneyLabel.textColor = [UIColor redColor];
    self.moneyLabel.font = FONT(14);
    [bgVieww addSubview:self.moneyLabel];
    
    [self.moneyLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(money.mas_bottom).offset(10);
        make.left.mas_equalTo(self.mas_left).offset(0);
        make.size.mas_equalTo(CGSizeMake(ScreenWidth/3, 20));
        
    }];
    
    
    //    中奖金额
    
    UILabel *zhongJiang = [[UILabel alloc]init];
    zhongJiang.textAlignment = NSTextAlignmentCenter;
    zhongJiang.text = @"中奖金额";
    zhongJiang.textColor = JCTTTColor;
    zhongJiang.font = FONT(14);
    [bgVieww addSubview:zhongJiang];
    [zhongJiang mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(bgVieww.mas_top).offset(10);
        make.left.mas_equalTo(ScreenWidth/3*1);
        make.size.mas_equalTo(CGSizeMake(ScreenWidth/3, 20));
        
    }];
    
    self.zhongJiangLabel = [[UILabel alloc]init];
    self.zhongJiangLabel.textAlignment = NSTextAlignmentCenter;
    self.zhongJiangLabel.textColor = [UIColor redColor];
    self.zhongJiangLabel.font = FONT(14);
    [bgVieww addSubview:self.zhongJiangLabel];
    [self.zhongJiangLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(zhongJiang.mas_bottom).offset(10);
        make.left.mas_equalTo(ScreenWidth/3*1);
        make.size.mas_equalTo(CGSizeMake(ScreenWidth/3, 20));
        
    }];
    
    //    加奖金额
    
    UILabel *jiaJiang = [[UILabel alloc]init];
    jiaJiang.numberOfLines = 0;
    jiaJiang.textAlignment = NSTextAlignmentCenter;
    jiaJiang.text = @"加奖金额";
    jiaJiang.textColor = JCTTTColor;
    jiaJiang.font = FONT(14);
    [bgVieww addSubview:jiaJiang];
    [jiaJiang mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(bgVieww.mas_top).offset(10);
        make.right.mas_equalTo(self.mas_right).offset(-10);
        make.size.mas_equalTo(CGSizeMake(ScreenWidth/3, 20));
        
        
    }];
    
    self.jiaJiangLabel = [[UILabel alloc]init];
    self.jiaJiangLabel.numberOfLines = 0;
    self.jiaJiangLabel.textAlignment = NSTextAlignmentCenter;
    self.jiaJiangLabel.textColor = [UIColor redColor];
    self.jiaJiangLabel.font = FONT(14);
    [bgVieww addSubview:self.jiaJiangLabel];
    [self.jiaJiangLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(jiaJiang.mas_bottom).offset(10);
        make.right.mas_equalTo(self.mas_right).offset(-10);
        make.size.mas_equalTo(CGSizeMake(ScreenWidth/3, 20));
        
        
    }];
    
    
    //单倍金额
    self.danBeiMoneyLab = [[UILabel alloc]init];
    self.danBeiMoneyLab.textColor = JCTTTColor;
    self.danBeiMoneyLab.font = FONT(15);
    self.danBeiMoneyLab.text = @"单倍金额：2元";
    [self addSubview:self.danBeiMoneyLab];
    [self.danBeiMoneyLab mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(bgVieww.mas_bottom).offset(5);
        make.left.mas_equalTo(self.mas_left).offset(15);
        make.size.mas_equalTo(CGSizeMake(150, 30));
        
        
    }];
    
    //单倍金额
    self.tichengLab = [[UILabel alloc]init];
    self.tichengLab.textColor = JCTTTColor;
    self.tichengLab.font = FONT(15);
    self.tichengLab.text = @"方案提成：10%";
    self.tichengLab.textAlignment = NSTextAlignmentCenter;
    self.tichengLab.layer.cornerRadius = 6;
    self.tichengLab.layer.borderWidth = 1;
    self.tichengLab.layer.borderColor = [UIColor grayColor].CGColor;
    self.tichengLab.layer.masksToBounds = YES;
    [self addSubview:self.tichengLab];
    [self.tichengLab mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(bgVieww.mas_bottom).offset(5);
        make.right.mas_equalTo(self.mas_right).offset(-15);
        make.size.mas_equalTo(CGSizeMake(150, 30));
        
    }];
    
    
    //    赋值
    
    
    JCNumberModel *model = [dataArray objectAtIndex:0];
    
    //    for (JCNumberSchemeDetailModel *schemeModel in model.schemeDetail) {
    //
    //        self.titleLabel.text = [NSString stringWithFormat:@"%@-%@期", model.lotteryName,schemeModel.issue];
    //
    //    }
    
    
    [self.touImgV sd_setImageWithURL:[NSURL URLWithString:model.avatar] placeholderImage:[UIImage imageNamed:@"mine_defaul_icon"]];
    self.nameLab.text = model.userName;
    self.IdLab.text = [NSString stringWithFormat:@"ID:%@",model.currentUserId];
    
    self.endTimeLab.text = [NSString stringWithFormat:@"%@截止",model.endTime];
    //    JCLog(@"model.describe.length  = %lu",(unsigned long)model.describe.length);
    
    CGSize size = [JCTool cjkt_getAttributionHeightWithString:model.describe lineSpace:1 font:[UIFont systemFontOfSize:14.f] width:ScreenWidth-30];
    //    JCLog(@"model.describe.height  = %f",size.height);
    
    //    if (model.describe.length >30) {
    //        self.describeLab.font = [UIFont systemFontOfSize:13.f];
    [self.describeLab mas_updateConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(IdlineView.mas_bottom).offset(2);
        make.height.mas_equalTo(size.height);
    }];
    //    }
    
    self.describeLab.text = [JCTool removeSpaceAndNewline:model.describe];;
    
    
    
    
    NSString *followNameStr = [NSString stringWithFormat:@"跟单于:%@",model.publisherName];
    
    NSMutableAttributedString  *attr = [JCTool pj_changeCorlorWithColor:[UIColor redColor] TotalString:followNameStr SubStringArray:@[model.publisherName]];
    self.followNameLab.attributedText = attr;
    
    self.moneyLabel.text = [NSString stringWithFormat:@"%.1f元", [model.buyAmount floatValue]];
    //    JCLog(@"订单金额 = %@",model.buyAmount);
    self.statueLabel.text = [NSString stringWithFormat:@" %@", model.statusDesc];
    
    //          subPrize中奖金额     pureSchemePrize嘉奖   schemePrize
    
    NSString *subPrize = model.pureSchemePrize?[NSString stringWithFormat:@"%.1f",[model.pureSchemePrize floatValue]]:@"0.0";
    
    self.zhongJiangLabel.text = [NSString stringWithFormat:@"%@元", subPrize];
    
    
    NSString *jiaPrize = model.subPrize?[NSString stringWithFormat:@"%.1f",[model.subPrize floatValue]]:@"0.0";
    self.jiaJiangLabel.text = [NSString stringWithFormat:@"%@元", jiaPrize];
    
    
    self.tichengLab.text = [NSString stringWithFormat:@"方案提成：%@%%",model.remuneration];
    
    
    self.danBeiMoneyLab.text  = [NSString stringWithFormat:@"单倍金额:%@元",model.singleMultipleMoney]; ;
    
    
    
    
    
}


@end
