//
//  JCGendanDSHomeTableViewCell.h
//  JiCaiLottery
//
//  Created by Peng Jun on 2018/5/22.
//  Copyright © 2018年 JiCaiLottery. All rights reserved.
//

#import <UIKit/UIKit.h>
@class JCGendanDSListModel;
@interface JCGendanDSHomeTableViewCell : UITableViewCell
@property (nonatomic, strong)JCGendanDSListModel *model;
@end
