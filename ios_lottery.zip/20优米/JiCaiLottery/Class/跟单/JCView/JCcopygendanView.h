//
//  JCcopygendanView.h
//  JiCaiLottery
//
//  Created by Peng Jun on 2017/11/24.
//  Copyright © 2017年 JiCaiLottery. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "PPNumberButton.h"
@class JCGendanCopyModel;
@interface JCcopygendanView : UIView
@property (nonatomic, strong) PPNumberButton *numberButton;
@property (nonatomic, strong) JCGendanCopyModel *model;
@property (nonatomic, strong)UILabel *jineLabel;
@end
