//
//  JCGendanDSHomeTableViewCell.m
//  JiCaiLottery
//
//  Created by Peng Jun on 2018/5/22.
//  Copyright © 2018年 JiCaiLottery. All rights reserved.
//

#import "JCGendanDSHomeTableViewCell.h"
#import "JCHeader.h"
#import "JCGendanInfoView.h"
#import "JCGendanDSListModel.h"
@implementation JCGendanDSHomeTableViewCell{
    UILabel *_startTime;
    UILabel *_myPrize;
    UIImageView *_timeIcon;
    JCGendanInfoView *_infoView;
    UIImageView *_zhongjiangStatus;
}

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}
- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        [self createUI];
    }
    return self;
}
- (void)createUI{
    _timeIcon = [[UIImageView alloc]init];
    _timeIcon.image = [UIImage imageNamed:@"日历"];
    [self.contentView addSubview:_timeIcon];
    
    _zhongjiangStatus = [[UIImageView alloc]init];
    [self.contentView addSubview:_zhongjiangStatus];
    _zhongjiangStatus.hidden = YES;
    
    _startTime = [[UILabel alloc]init];
    _startTime.text = @"推荐时间：05-14 10:28";
    _startTime.textColor = JCTTTColor;
    _startTime.font = FONT(14);
    [self.contentView addSubview:_startTime];
    
    _myPrize = [[UILabel alloc]init];
    _myPrize.textColor = allRedColor;
    _myPrize.font = FONT(14);
    [self.contentView addSubview:_myPrize];
    
    _infoView = [[JCGendanInfoView alloc]initWithFrame:CGRectMake(20, 34 *(ScreenScale>1?ScreenScale:1), ScreenWidth -40, 84*(ScreenScale>1?ScreenScale:1))];
    
    _infoView.layer.borderColor = UICOLOR_HEX(0xeeeeee).CGColor;
    _infoView.layer.borderWidth = 0.5;
    [self.contentView addSubview:_infoView];
//    _infoView = [[JCGendanInfoView alloc]init];
//    [self.contentView addSubview:_infoView];
    [_timeIcon mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(self.contentView.mas_left).offset(20);
        make.top.mas_equalTo(self.contentView.mas_top).offset(8);
        make.size.mas_equalTo(CGSizeMake(18, 18));
    }];
    [_startTime mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(_timeIcon.mas_right).offset(3);
        make.centerY.mas_equalTo(_timeIcon.mas_centerY);
    }];
    
    [_myPrize mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.mas_equalTo(self.contentView.mas_right).offset(-20);
        make.centerY.mas_equalTo(_timeIcon.mas_centerY);
    }];
    
    [_zhongjiangStatus mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.mas_equalTo(_infoView.mas_top);
        make.centerX.mas_equalTo(_infoView.mas_right).offset(- (ScreenWidth -40)/4);
        make.size.mas_equalTo(CGSizeMake(50, 50));
    }];
//    [_infoView mas_makeConstraints:^(MASConstraintMaker *make) {
//        make.top.mas_equalTo(_timeIcon.mas_bottom).offset(10);
//        make.size.mas_equalTo(CGSizeMake(ScreenWidth -40, 84));
//    }];
}
- (void)setModel:(JCGendanDSListModel *)model{
    _model = model;
    _startTime.text = [NSString stringWithFormat:@"推荐时间：%@",model.formatedRecommendTime];
    _infoView.lotteryName = model.betDescription?model.betDescription:@"未知";
    _infoView.singleMoney = model.money;
    _infoView.gendanMoney = model.followMoney;
    _infoView.joinners = model.participant;
    if ([model.prize floatValue] > 0) {
        _myPrize.text = [NSString stringWithFormat:@"%.1f元",model.prize.floatValue];
    }else{
        _myPrize.text = @"";
    }
//    501:中奖；601:未中奖；301:成功，其他编号:先作为成功处理(预留)
    [self changeCellStatus:[model.status integerValue]];
    
}
- (void)changeCellStatus:(NSInteger )status{

     if (status == 501){
        //中奖
         _zhongjiangStatus.image = [UIImage imageNamed:@"中奖了"];
         _zhongjiangStatus.hidden = NO;
         

         [self.contentView bringSubviewToFront:_zhongjiangStatus];
          _infoView.isGray = NO;
    }else if (status == 601){
        //未中奖
        _zhongjiangStatus.image = [UIImage imageNamed:@"未中奖"];

          [self.contentView bringSubviewToFront:_zhongjiangStatus];
        _infoView.isGray = YES;
        _zhongjiangStatus.hidden = NO;
    }else{
//        _zhongjiangStatus.hidden = YES;

          [self.contentView bringSubviewToFront:_zhongjiangStatus];
        _infoView.isGray = NO;
        _zhongjiangStatus.hidden = YES;
    }
}
- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
