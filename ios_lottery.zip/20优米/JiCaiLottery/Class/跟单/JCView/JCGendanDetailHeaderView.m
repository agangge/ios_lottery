//
//  JCGendanDetailHeaderView.m
//  JiCaiLottery
//
//  Created by Peng Jun on 2017/11/27.
//  Copyright © 2017年 JiCaiLottery. All rights reserved.
//

#import "JCGendanDetailHeaderView.h"
#import "JCHeader.h"
@implementation JCGendanDetailHeaderView

- (instancetype)initWithFrame:(CGRect)frame{
    if (self = [super initWithFrame:frame]) {
        [self cretateHeader];
    }
    return self;
}
- (instancetype)initWithReuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithReuseIdentifier:reuseIdentifier]) {
        [self cretateHeader];
    }
    return self;
}
- (void)cretateHeader{
    _leftLabel = [[UILabel alloc] init];
    _leftLabel.textColor = UICOLOR_HEX(0x333333);
    _leftLabel.font = FONT(16);
    [self.contentView addSubview:_leftLabel];
    
    
    _loteryLabel = [[UILabel alloc] init];
    _loteryLabel.textColor = UICOLOR_HEX(0x333333);
    _loteryLabel.font = FONT(14);
    [self.contentView addSubview:_loteryLabel];
    
    _zhushuLable = [[UILabel alloc] init];
    _zhushuLable.textColor = UICOLOR_HEX(0x333333);
    _zhushuLable.font = FONT(14);
    [self.contentView addSubview:_zhushuLable];
    [_leftLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(self.contentView.mas_centerY);
        make.left.equalTo(self.contentView.mas_left).offset(25);
        
    }];
    
    [_zhushuLable mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(self.contentView.mas_centerY);
        make.right.equalTo(self.contentView.mas_right).offset(-15);
        
    }];
    
    [_leftLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(self.contentView.mas_centerY);
        make.right.equalTo(_zhushuLable.mas_left).offset(-25);
        
    }];
}
@end
