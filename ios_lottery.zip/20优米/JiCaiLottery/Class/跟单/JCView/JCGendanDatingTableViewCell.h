//
//  JCGendanDatingTableViewCell.h
//  JiCaiLottery
//
//  Created by Peng Jun on 2018/5/22.
//  Copyright © 2018年 JiCaiLottery. All rights reserved.
//

#import <UIKit/UIKit.h>
@class JCGendanCenterListModel;

typedef void (^gendanDatingBlock)(NSInteger schemeId);
typedef void (^gendanDatingIconBlock)(NSInteger schemeId);
@interface JCGendanDatingTableViewCell : UITableViewCell
@property (nonatomic, copy)gendanDatingBlock gdBlcok;
@property (nonatomic, copy)gendanDatingIconBlock gdIconBlcok;
@property (nonatomic, strong)JCGendanCenterListModel *model;
@end
