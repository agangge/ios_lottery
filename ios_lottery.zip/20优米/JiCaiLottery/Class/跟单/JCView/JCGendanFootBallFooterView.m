//
//  JCGendanFootBallFooterView.m
//  JiCaiLottery
//
//  Created by Peng Jun on 2017/12/7.
//  Copyright © 2017年 JiCaiLottery. All rights reserved.
//

#import "JCGendanFootBallFooterView.h"
#import "JCHeader.h"
@implementation JCGendanFootBallFooterView

- (instancetype)initWithFrame:(CGRect)frame{
    if (self = [super initWithFrame:frame]) {
        self.backgroundColor = [UIColor whiteColor];
        [self createUI];
    }
    return self;
}
- (void)createUI{
    UILabel *ggfs = [[UILabel alloc ]init];
    ggfs.text = @"过关方式";
    ggfs.textColor = UICOLOR_HEX(0x666666);
    ggfs.font = FONT(12);
    [self addSubview:ggfs];
    
    _label = [[UILabel alloc ]init];
    _label.text = @"2串1-3倍";
    _label.textColor = UICOLOR_HEX(0xEF2F17);
    _label.font = FONT(12);
    [self addSubview:_label];
    
    UILabel *shuoming = [[UILabel alloc ]init];
    shuoming.text = @"＊方案中的赔率为提交时参考赔率，计算奖金以实际出票赔率为准！";
    shuoming.textColor = UICOLOR_HEX(0xEF2F17);
    shuoming.numberOfLines = 0;
    shuoming.font = FONT(12);
    [self addSubview:shuoming];
    
    [ggfs mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.mas_left).offset(15);
        make.top.equalTo(self.mas_top).offset(19);
    }];
    
    [_label mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(ggfs.mas_right).offset(3);
        make.top.equalTo(self.mas_top).offset(19);
    }];
    
    [shuoming mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.mas_left).offset(15);
        make.top.equalTo(ggfs.mas_bottom).offset(8);
        make.right.mas_lessThanOrEqualTo(self.mas_right).offset(-10);
    }];
    
}
@end
