//
//  JCGendanDSButtonCell.h
//  JiCaiLottery
//
//  Created by Peng Jun on 2018/5/23.
//  Copyright © 2018年 JiCaiLottery. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface JCGendanDSButtonCell : UITableViewCell

@end
