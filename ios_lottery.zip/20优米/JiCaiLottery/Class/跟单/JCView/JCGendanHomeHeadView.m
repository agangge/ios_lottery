//
//  JCGendanHomeHeadView.m
//  JiCaiLottery
//
//  Created by Peng Jun on 2018/5/23.
//  Copyright © 2018年 JiCaiLottery. All rights reserved.
//

#import "JCGendanHomeHeadView.h"
#import "JCHeader.h"
#import "ImageCenterButton.h"
#import "JCGendanSectionHeadView.h"
#import "UIButton+WebCache.h"
@implementation JCGendanHomeHeadView{
    UIImageView *_imageView;
    UILabel *_titleLabel;
    ImageCenterButton *_button;
}

- (instancetype)initWithFrame:(CGRect)frame{
    if (self = [super initWithFrame:frame]) {
        self.backgroundColor = allBackGroundColor;
        [self createUI];
    }
    return self;
}
- (void)createUI{
    NSArray *imageArr = @[@"gendan_yingli",@"gendan_mingzhong",@"gendan_jiangjin",@"myfocus2"];
    NSArray *titleArr = @[@"盈利榜",@"命中榜",@"奖金榜",@"我的关注"];
    for (int i = 0; i < titleArr.count; i++) {
        ImageCenterButton *button = [ImageCenterButton buttonWithType:UIButtonTypeCustom];
        button.tag = i + 1;
        button.backgroundColor = [UIColor whiteColor];
        button.frame = CGRectMake(ScreenWidth /  titleArr.count * i, 0, ScreenWidth / titleArr.count-0.5, 108);
        if (i>0) {
            UIView *line = [[UIView alloc]initWithFrame:CGRectMake(ScreenWidth / titleArr.count * i, 3, 0.5, 108-6)];
            line.backgroundColor = UICOLOR_HEX(0xEEEEEE);
            [self addSubview:line];
        }
        
        [button setImage:[UIImage imageNamed:imageArr[i]] forState:UIControlStateNormal];
        [button setTitle:titleArr[i] forState:UIControlStateNormal];
        [button setTitleColor:JCTTTColor forState:UIControlStateNormal];
        button.titleLabel.font = FONT(14);
        [button addTarget:self action:@selector(buttonAction:) forControlEvents:UIControlEventTouchUpInside];
        [self addSubview:button];
    }
    JCGendanSectionHeadView *listLotteryView = [[JCGendanSectionHeadView alloc]initWithFrame:CGRectMake(0, 118, ScreenWidth, 40)];
    listLotteryView.titleLabel.text = @"热门大神";
    listLotteryView.arrowImage.hidden = YES;
    listLotteryView.tuijainLabel.hidden = YES;
    listLotteryView.reJineListbutton .hidden = YES;
    listLotteryView.reRSListbutton.hidden = YES;
    listLotteryView.reDSListbutton.hidden = YES;
    listLotteryView.rightMiaoshuLabel.hidden = YES;
    listLotteryView.backgroundColor = [UIColor whiteColor];
    [self addSubview:listLotteryView];
    
}
- (void)setDSArray:(NSArray *)dSArray{
    _dSArray = dSArray;
    
    for (UIView *view in self.subviews) {
        if ([view isKindOfClass:[UIButton class]]) {
         
            UIButton *button = (UIButton *)view;
            if (button.tag>= 100) {
                [button removeFromSuperview];
            }
            
        }else{
            if (view.tag > 100) {
                [view removeFromSuperview];
            }
        }
    }
    
    for (int i = 0; i < _dSArray.count; i++) {
        NSDictionary *dsDic = _dSArray[i];
        NSString *avatar = [dsDic objectForKey:@"avatar"];
        NSString *name = [dsDic objectForKey:@"userName"];
//        int  daId = [[dsDic objectForKey:@"userId"] intValue];
        ImageCenterButton *button = [ImageCenterButton buttonWithType:UIButtonTypeCustom];
        button.tag = i + 100;
       
        button.backgroundColor = [UIColor whiteColor];
        float j = 0;
        if (i > 3) {
            j = 71.5;
        }
        button.frame = CGRectMake(ScreenWidth / 4 * (i%4), 118+40+j, ScreenWidth / 4, 150/2);
        button.imageView.contentMode = UIViewContentModeScaleAspectFill;
//        button.imageView.layer.cornerRadius = button.imageView.bounds.size.width/2;
        [button sd_setImageWithURL:[NSURL URLWithString:avatar] forState:UIControlStateNormal placeholderImage:[UIImage imageNamed:@"mine_defaul_icon"]];
        
         button.imageViewMaxSize = CGSizeMake(40, 40);
        button.imageTextSpace = 1;
        [button setTitle:(name?name:@"大神") forState:UIControlStateNormal];
        [button setTitleColor:JCTTTColor forState:UIControlStateNormal];
        button.titleLabel.font = FONT(14);
        [button addTarget:self action:@selector(buttonAction:) forControlEvents:UIControlEventTouchUpInside];
        button.imageIsRound = YES;
        [self addSubview:button];
    }
    
    if (_dSArray.count < 8) {
        for (NSInteger i = _dSArray.count; i< 8; i++) {
            float j = 0;
            if (i > 3) {
                j = 71.5;
            }
            UIView *view = [[UIView alloc]initWithFrame:CGRectMake(ScreenWidth / 4 * (i%4), 118+40+j, ScreenWidth / 4, 150/2)];
            view.tag = i +100;
            view.backgroundColor = [UIColor whiteColor];
            [self addSubview:view];
        }
    }
}
- (void)buttonAction:(UIButton *)button{
    if (self.bangdanBlcok) {
        self.bangdanBlcok(button.tag);
    }
}
@end
