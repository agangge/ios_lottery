//
//  JCJionGendanView.h
//  JiCaiLottery
//
//  Created by Peng Jun on 2017/11/27.
//  Copyright © 2017年 JiCaiLottery. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "PPNumberButton.h"
typedef void (^ToGendanBlcok)(void);
@class JCGendanCopyModel;
@interface JCJionGendanView : UIView
@property (nonatomic, strong) PPNumberButton *numberButton;
@property (nonatomic, strong)UILabel *totalMoneyLabel;
@property (nonatomic, copy)ToGendanBlcok toGdBlock;
@end
