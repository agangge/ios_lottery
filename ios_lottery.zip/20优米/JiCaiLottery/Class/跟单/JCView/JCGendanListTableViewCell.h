//
//  JCGendanListTableViewCell.h
//  JiCaiLottery
//
//  Created by Peng Jun on 2017/11/23.
//  Copyright © 2017年 JiCaiLottery. All rights reserved.
//

#import <UIKit/UIKit.h>
@class JCgendanListModel;
@interface JCGendanListTableViewCell : UITableViewCell
@property (nonatomic, strong)JCgendanListModel *model;

@end
