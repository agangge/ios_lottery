//
//  JCGendanListTableViewCell.m
//  JiCaiLottery
//
//  Created by Peng Jun on 2017/11/23.
//  Copyright © 2017年 JiCaiLottery. All rights reserved.
//

#import "JCGendanListTableViewCell.h"
#import "JCHeader.h"
#import "JCgendanListModel.h"
@implementation JCGendanListTableViewCell{
    UILabel *_nameLabel;
    UILabel *_jineLabel;
    UILabel *_timeLabel;
    UILabel *_jiangjinLabel;
}
- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        [self createCell];
    }
    return self;
}
- (void)createCell{
//    NSArray *arr = @[@"李***三",@"2元",@"12.12.12",@"---"];
    for (int i = 0; i<4; i++) {
        CGFloat x = i*ScreenWidth/4;
        
        UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(x, 0, ScreenWidth/4, self.frame.size.height)];
//        label.text =arr[i];
        label.textColor =UICOLOR_HEX(0x666666);
        label.font = FONT(14);
        label.tag = i +100;
        label.textAlignment = NSTextAlignmentCenter;
        [self.contentView addSubview:label];
        
    }
    
}
- (void)setModel:(JCgendanListModel *)model{
    _model = model;
//    NSArray *newarr = @[[_model.userName ],_model.money,_model.time,_model.prize];
    for (int i = 100; i<104; i++) {
        UILabel *label = [self.contentView viewWithTag:i];
        if (i == 100) {
            label.text =_model.username;
        }
        if (i == 103) {
            if ([_model.price floatValue] >0) {
                label.textColor = allRedColor;
                label.text =[NSString stringWithFormat:@"%@元",_model.price];
            }else{
                label.text = @"----";
            }
            
        }
        if (i == 102) {
            label.text =_model.time;
        }
        if (i == 101) {
            label.text =[NSString stringWithFormat:@"%@元",_model.money];
        }
     
    }
//    for (UILabel *label in self.contentView.subviews) {
    
//        switch (label.tag) {
//            case 100:
//             {
//                label.text = _model.userName;}
//            case 101:
//             {
//                 label.text = _model.money;}
//            case 102:
//             {
//                 label.text = _model.time;}
//            case 103:
//             {
//                 label.text = _model.prize;
//                 label.textColor = allRedColor;
//             }
//                break;
//
//            default:
//                break;
//        }
//    }
}
- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
