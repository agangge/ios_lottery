//
//  JCGendanInfoView.m
//  JiCaiLottery
//
//  Created by Peng Jun on 2018/5/22.
//  Copyright © 2018年 JiCaiLottery. All rights reserved.
//

#import "JCGendanInfoView.h"
#import "JCHeader.h"

@implementation JCGendanInfoView{
    UILabel *_fangAnMoney;
    UILabel *_dbje;
    UILabel *_gdje;
    UILabel *_gendanNumber;
    UILabel *_playNameLabel;
    UILabel *_singleMoneyLabel;
    UILabel *_gendanMoneyLabel;
    UILabel *_joinnersLabel;
    UIImageView *_stausImgV;
    
}
- (instancetype)initWithFrame:(CGRect)frame{
    if (self = [super initWithFrame:frame]) {
        
        self.layer.borderColor = UICOLOR_HEX(0xeeeeee).CGColor;
        self.layer.borderWidth = 0.5;
        [self createUI];
    }
    return self;
}
- (void)createUI{
    _fangAnMoney = [[UILabel alloc]init];
    _fangAnMoney.font = FONT(12);
    _fangAnMoney.textColor = JCNNNColor;
    _fangAnMoney.text = @"方案金额";
    
    _fangAnMoney.textAlignment = NSTextAlignmentCenter;
    _fangAnMoney.backgroundColor = UICOLOR_HEX(0xFFF7F7);
    [self addSubview:_fangAnMoney];
    
    _dbje = [[UILabel alloc]init];
    _dbje.font = FONT(12);
    _dbje.text = @"单倍金额";
    _dbje.textColor = JCNNNColor;
    _dbje.textAlignment = NSTextAlignmentCenter;
    _dbje.backgroundColor = UICOLOR_HEX(0xFFF7F7);
    [self addSubview:_dbje];
    
    
    _gendanNumber = [[UILabel alloc]init];
    _gendanNumber.font = FONT(12);
    _gendanNumber.text = @"跟单人数";
    _gendanNumber.textColor = JCNNNColor;
    _gendanNumber.textAlignment = NSTextAlignmentCenter;
    _gendanNumber.backgroundColor = UICOLOR_HEX(0xFFF7F7);
    [self addSubview:_gendanNumber];
    
    
    _gdje = [[UILabel alloc]init];
    _gdje.font = FONT(12);
    _gdje.textColor = JCNNNColor;
    _gdje.text = @"跟单金额";
    _gdje.textAlignment = NSTextAlignmentCenter;
    _gdje.backgroundColor = UICOLOR_HEX(0xFFF7F7);
    [self addSubview:_gdje];
    
    
    
    
    
    _playNameLabel = [[UILabel alloc]init];
    _playNameLabel.font = FONT(14);
    _playNameLabel.text = @"足球";
    _playNameLabel.numberOfLines = 3;
    _playNameLabel.textColor = JCTTTColor;
    _playNameLabel.adjustsFontSizeToFitWidth = YES;
    _playNameLabel.textAlignment = NSTextAlignmentCenter;
    [self addSubview:_playNameLabel];
    
    _singleMoneyLabel = [[UILabel alloc]init];
    _singleMoneyLabel.font = FONT(14);
    _singleMoneyLabel.text = @"10元";
    _singleMoneyLabel.textColor = JCTTTColor;
    _singleMoneyLabel.textAlignment = NSTextAlignmentCenter;
    [self addSubview:_singleMoneyLabel];
    
    _gendanMoneyLabel = [[UILabel alloc]init];
    _gendanMoneyLabel.font = FONT(14);
    _gendanMoneyLabel.text = @"100元";
    _gendanMoneyLabel.textColor = JCTTTColor;
    _gendanMoneyLabel.textAlignment = NSTextAlignmentCenter;
    [self addSubview:_gendanMoneyLabel];
    
    _joinnersLabel = [[UILabel alloc]init];
    _joinnersLabel.font = FONT(14);
    _joinnersLabel.text = @"10人";
    _joinnersLabel.textColor = JCTTTColor;
    _joinnersLabel.textAlignment = NSTextAlignmentCenter;
    [self addSubview:_joinnersLabel];
    
    _stausImgV = [[UIImageView alloc] init];
    //    _stausImgV.image = [UIImage imageNamed:@"basketball_icon"];
    [self addSubview:_stausImgV];
    
    
    
    [_fangAnMoney mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self.mas_top);
        make.left.mas_equalTo(self.mas_left);
        //        make.centerX.mas_equalTo(self.mas_centerX).offset(-self.bounds.size.width/8*3);
        make.size.mas_equalTo(CGSizeMake(self.bounds.size.width/4, 40));
        
    }];
    
    
    [_dbje mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self.mas_top);
        make.left.mas_equalTo(self->_fangAnMoney.mas_right);
        //        make.centerX.mas_equalTo(self.mas_centerX).offset(-self.bounds.size.width/8*1);
        make.size.mas_equalTo(CGSizeMake(self.bounds.size.width/4, 40));
    }];
    [_gendanNumber mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self.mas_top);
        make.left.mas_equalTo(self->_dbje.mas_right);
        //        make.centerX.mas_equalTo(self.mas_centerX).offset(self.bounds.size.width/8*1);
        make.size.mas_equalTo(CGSizeMake(self.bounds.size.width/4, 40));
    }];
    
    [_gdje mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self.mas_top);
        make.left.mas_equalTo(self->_gendanNumber.mas_right);
        //        make.centerX.mas_equalTo(self.mas_centerX).offset(self.bounds.size.width/8*3);
        make.size.mas_equalTo(CGSizeMake(self.bounds.size.width/4, 40));
    }];
    
    
    
    //
    [_playNameLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self->_fangAnMoney.mas_bottom);
        
        make.left.mas_equalTo(self.mas_left);
        //        make.centerX.mas_equalTo(self.mas_centerX).offset(-self.bounds.size.width/8*3);
        make.height.mas_equalTo(self.bounds.size.height - 40);
        make.width.mas_equalTo(self.bounds.size.width/4 - 10);
    }];
    
    
    //    图片标志
    //    [_stausImgV mas_makeConstraints:^(MASConstraintMaker *make) {
    //        make.top.mas_equalTo(self->_playNameLabel.mas_bottom).offset(-10);
    //        make.left.mas_equalTo(self->_playNameLabel.mas_left).offset(-8);
    //        make.height.mas_equalTo(20);
    //        make.width.mas_equalTo(20);
    //    }];
    //
    _stausImgV.backgroundColor = [UIColor whiteColor];
    
    
    [_singleMoneyLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self->_fangAnMoney.mas_bottom);
        make.centerX.mas_equalTo(self.mas_centerX).offset(-self.bounds.size.width/8*1);
        make.height.mas_equalTo(self.bounds.size.height - 40);
        make.width.mas_equalTo(self.bounds.size.width/4 - 10);
    }];
    
    [_joinnersLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self->_fangAnMoney.mas_bottom);
        make.centerX.mas_equalTo(self.mas_centerX).offset(self.bounds.size.width/8*1);
        make.height.mas_equalTo(self.bounds.size.height - 40);
        make.width.mas_equalTo(self.bounds.size.width/4 - 10);
    }];
    [_gendanMoneyLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self->_fangAnMoney.mas_bottom);
        make.centerX.mas_equalTo(self.mas_centerX).offset(self.bounds.size.width/8*3);
        make.height.mas_equalTo(self.bounds.size.height - 40);
        make.width.mas_equalTo(self.bounds.size.width/4 - 10);
    }];
    
    
    
}
- (void)setIsGray:(BOOL)isGray{
    if (isGray) {
        _fangAnMoney.textColor = UICOLOR_HEX(0xcccccc);
        _fangAnMoney.backgroundColor = UICOLOR_HEX(0xeeeeee);
        _dbje.textColor = UICOLOR_HEX(0xcccccc);
        _dbje.backgroundColor = UICOLOR_HEX(0xeeeeee);
        _gdje.textColor = UICOLOR_HEX(0xcccccc);
        _gdje.backgroundColor = UICOLOR_HEX(0xeeeeee);
        _gendanNumber.textColor = UICOLOR_HEX(0xcccccc);
        _gendanNumber.backgroundColor = UICOLOR_HEX(0xeeeeee);
        _playNameLabel.textColor = UICOLOR_HEX(0xcccccc);
        _singleMoneyLabel.textColor = UICOLOR_HEX(0xcccccc);
        _gendanMoneyLabel.textColor = UICOLOR_HEX(0xcccccc);
        _joinnersLabel.textColor = UICOLOR_HEX(0xcccccc);
    }else{
        _fangAnMoney.textColor = JCNNNColor;
        _fangAnMoney.backgroundColor = UICOLOR_HEX(0xFFF7F7);
        _dbje.textColor = JCNNNColor;
        _dbje.backgroundColor = UICOLOR_HEX(0xFFF7F7);
        _gdje.textColor = JCNNNColor;
        _gdje.backgroundColor = UICOLOR_HEX(0xFFF7F7);
        _gendanNumber.textColor = JCNNNColor;
        _gendanNumber.backgroundColor = UICOLOR_HEX(0xFFF7F7);
        _playNameLabel.textColor = JCTTTColor;
        _singleMoneyLabel.textColor =JCTTTColor;
        _gendanMoneyLabel.textColor = JCTTTColor;
        _joinnersLabel.textColor = JCTTTColor;
    }
}
- (void)setJoinners:(NSString *)joinners{
    _joinners = joinners;
    _joinnersLabel.text = [NSString stringWithFormat:@"%@人",_joinners];
}
- (void)setGendanMoney:(NSString *)gendanMoney{
    _gendanMoney = gendanMoney;
    _gendanMoneyLabel.text = [NSString stringWithFormat:@"%@元",_gendanMoney];
}
- (void)setLotteryName:(NSString *)lotteryName{
    _lotteryName = lotteryName;
    
    NSString *na = _lotteryName;
    NSArray *arr = [_lotteryName componentsSeparatedByString:@"_"];
    if (arr.count > 0) {
        na = arr[0];
    }
    _playNameLabel.text = [NSString stringWithFormat:@"%@",na];
    
    
    if ([_playNameLabel.text isEqualToString:@"竞彩足球"]) {
        _stausImgV.image = [UIImage imageNamed:@"football_icon"];
    }else if ([_playNameLabel.text isEqualToString:@"竞彩篮球"]) {
        _stausImgV.image = [UIImage imageNamed:@"basketball_icon"];
    }
    
    
}
-(void)setMoney:(NSString *)money{
    _money = money;
    _playNameLabel.text = [NSString stringWithFormat:@"%.f元",[_money doubleValue]];
}
- (void)setSingleMoney:(NSString *)singleMoney{
    _singleMoney = singleMoney;
    _singleMoneyLabel.text = [NSString stringWithFormat:@"%@元",_singleMoney];
}
/*
 // Only override drawRect: if you perform custom drawing.
 // An empty implementation adversely affects performance during animation.
 - (void)drawRect:(CGRect)rect {
 // Drawing code
 }
 */

@end
