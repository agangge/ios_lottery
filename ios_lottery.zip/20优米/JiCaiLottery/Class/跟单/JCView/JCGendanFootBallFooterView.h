//
//  JCGendanFootBallFooterView.h
//  JiCaiLottery
//
//  Created by Peng Jun on 2017/12/7.
//  Copyright © 2017年 JiCaiLottery. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface JCGendanFootBallFooterView : UIView

@property (nonatomic, strong)UILabel *label;
@end
