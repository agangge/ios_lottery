//
//  JCRemainTimeModel.h
//  JiCaiLottery
//
//  Created by 风外杏林香 on 2017/11/16.
//  Copyright © 2017年 JiCaiLottery. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface JCRemainTimeModel : NSObject
///用NSDate日期倒计时
- (void)countDownWithStratDate:(NSDate *)startDate finishDate:(NSDate *)finishDate completeBlock:(void (^)(NSInteger day,NSInteger hour,NSInteger minute,NSInteger second))completeBlock;
@end
