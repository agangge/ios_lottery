//
//  JCChooseCollectionViewCell.h
//  JiCaiLottery
//
//  Created by 风外杏林香 on 2017/4/14.
//  Copyright © 2017年 JiCaiLottery. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface JCChooseCollectionViewCell : UICollectionViewCell
@property(nonatomic,retain)UILabel *title; 
@end
