//
//  JCChooseCollectionViewCell.m
//  JiCaiLottery
//
//  Created by 风外杏林香 on 2017/4/14.
//  Copyright © 2017年 JiCaiLottery. All rights reserved.
//

#import "JCChooseCollectionViewCell.h"
#import "JCHeader.h"
@implementation JCChooseCollectionViewCell
- (instancetype)initWithFrame:(CGRect)frame{
    if (self = [super initWithFrame:frame]) {
        [self createTit:frame];
    }
    return self;
}
- (void)createTit:(CGRect)rect{
    self.title = [[UILabel alloc]init];
    self.title.textAlignment = NSTextAlignmentCenter;
    self.title.textColor = UICOLOR_HEX(0x666666);
    self.title.font = [UIFont systemFontOfSize:14];
    self.title.layer.borderColor = UICOLOR_HEX(0xd2d2d2).CGColor;
    self.title.layer.borderWidth = 0.5;
    self.title.layer.cornerRadius = 3;
    self.title.frame = CGRectMake(0, 0, rect.size.width, rect.size.height);
    [self.contentView addSubview:self.title];
}
- (void)setSelected:(BOOL)selected{
    if (selected) {
        self.title.textColor = allWhiteColor;
        self.title.layer.backgroundColor = allRedColor.CGColor;
        self.title.layer.borderColor = allRedColor.CGColor;
    }
    else{
        self.title.textColor = UICOLOR_HEX(0x666666);
        self.title.layer.backgroundColor = [UIColor clearColor].CGColor;
        self.title.layer.borderColor = UICOLOR_HEX(0xd2d2d2).CGColor;
    }
}
@end
