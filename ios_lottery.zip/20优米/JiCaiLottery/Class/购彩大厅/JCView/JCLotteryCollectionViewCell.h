//
//  JCLotteryCollectionViewCell.h
//  JiCaiLottery
//
//  Created by 风外杏林香 on 2017/5/5.
//  Copyright © 2017年 JiCaiLottery. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface JCLotteryCollectionViewCell : UICollectionViewCell

@property (nonatomic, strong)UIImageView *lotteryImage;
@property (nonatomic, strong)UILabel *lotteryLabel;
@property (nonatomic, assign)BOOL isStop;

@end
