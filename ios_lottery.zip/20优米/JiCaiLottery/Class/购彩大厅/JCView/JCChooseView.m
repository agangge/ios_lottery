//
//  JCChooseView.m
//  JiCaiLottery
//
//  Created by 风外杏林香 on 2017/4/14.
//  Copyright © 2017年 JiCaiLottery. All rights reserved.
//

#import "JCChooseView.h"
#import "JCChooseCollectionViewCell.h"
#import "JCHeader.h"
@implementation JCChooseView

{
    ChooseBlock chooseAction;
}
- (void)chooseAction:(ChooseBlock)block{
    chooseAction = block;
}
-(instancetype)initWithFrame:(CGRect)frame
{
    self=[super initWithFrame:frame];
    if (self) {
        [self createCollective];
    }
    return self;
}
-(void)createCollective
{
    self.backgroundColor = UICOLOR_HEX(0xffffff);
    UICollectionViewFlowLayout *layout = [[UICollectionViewFlowLayout alloc]init];
    layout.scrollDirection = UICollectionViewScrollDirectionVertical;
    UICollectionView *collectionView = [[UICollectionView alloc]initWithFrame:CGRectMake(0, 5, ScreenWidth, self.height) collectionViewLayout:layout];
    collectionView.delegate = self;
    collectionView.dataSource = self;

    collectionView.backgroundColor = [UIColor clearColor];
    [collectionView registerClass:[JCChooseCollectionViewCell class] forCellWithReuseIdentifier:@"cell"];
    [collectionView registerClass:[UICollectionReusableView class] forSupplementaryViewOfKind:UICollectionElementKindSectionHeader withReuseIdentifier:@"header"];
    [self addSubview:collectionView];
}
-(UIEdgeInsets)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout insetForSectionAtIndex:(NSInteger)section
{
    return UIEdgeInsetsMake(10,10,10,10);
}
- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath
{
    return CGSizeMake((ScreenWidth-50)/self.count, 30);
}
-(NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    NSArray *countArr = self.dataArray[section];
    return countArr.count;
}
- (UICollectionReusableView *)collectionView:(UICollectionView *)collectionView viewForSupplementaryElementOfKind:(NSString *)kind atIndexPath:(NSIndexPath *)indexPath
{
    UICollectionReusableView *header = [collectionView dequeueReusableSupplementaryViewOfKind:UICollectionElementKindSectionHeader withReuseIdentifier:@"header" forIndexPath:indexPath];
    UILabel *label = [[UILabel alloc]initWithFrame:CGRectMake(10, 0, ScreenWidth-20, header.height)];
    label.textColor = [UIColor whiteColor];
    label.font = [UIFont systemFontOfSize:14];
    if (self.sectionArray.count!=0) {
        label.text = self.sectionArray[indexPath.section];
    }
    [header addSubview:label];
    return header;
}
- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView{
    
    return self.sectionArray.count==0?1:self.sectionArray.count;
}
- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout referenceSizeForHeaderInSection:(NSInteger)section{
    return self.sectionArray.count==0? CGSizeMake(0, 0):CGSizeMake(ScreenWidth,20);
//    return self.sectionArray.count==0? CGSizeMake(0, 0):CGSizeMake(ScreenWidth,0);

    
}
-(UICollectionViewCell*)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    JCChooseCollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"cell" forIndexPath:indexPath];
    cell.title.text=[NSString stringWithFormat:@"%@",self.dataArray[indexPath.section][indexPath.row]];
//    默认选中第一个
    [collectionView selectItemAtIndexPath:[NSIndexPath indexPathForItem:0 inSection:0] animated:YES scrollPosition:UICollectionViewScrollPositionNone];
    return cell;
}

-(void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    JCChooseCollectionViewCell *cell = (JCChooseCollectionViewCell *)[collectionView cellForItemAtIndexPath:indexPath];
    if (chooseAction) {
        chooseAction(cell.title.text,indexPath.section,indexPath.row);
    }
}
@end
