//
//  JCLotteryActivivityCollectionViewCell.h
//  JiCaiLottery
//
//  Created by Peng Jun on 2018/2/25.
//  Copyright © 2018年 JiCaiLottery. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface JCLotteryActivivityCollectionViewCell : UICollectionViewCell
@property (nonatomic, strong)UILabel *label1;
@property (nonatomic, strong)UILabel *label2;
@property (nonatomic, strong)UILabel *label3;
@property (nonatomic, strong)UILabel *label4;
@property (nonatomic, strong)UIImageView *imageView1;
@end
