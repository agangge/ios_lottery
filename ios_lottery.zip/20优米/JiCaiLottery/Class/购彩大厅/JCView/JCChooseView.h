//
//  JCChooseView.h
//  JiCaiLottery
//
//  Created by 风外杏林香 on 2017/4/14.
//  Copyright © 2017年 JiCaiLottery. All rights reserved.
//

#import <UIKit/UIKit.h>
typedef void (^ChooseBlock)(NSString *title,NSInteger section,NSInteger index);
@interface JCChooseView : UIView<UICollectionViewDataSource,UICollectionViewDelegate,UICollectionViewDelegateFlowLayout>

/**
 数据源，⚠️里面存放的是数组
 */
@property(nonatomic,strong)NSArray <NSArray *> *dataArray;

/**
 头部数组
 */
@property(nonatomic,strong)NSArray *sectionArray;

/**
 每一排的个数
 */
@property(nonatomic,assign)NSInteger count;

-(void)chooseAction:(ChooseBlock)block;

@end
