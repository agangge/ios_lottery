//
//  JCTitleButton.m
//  JiCaiLottery
//
//  Created by 风外杏林香 on 2017/4/13.
//  Copyright © 2017年 JiCaiLottery. All rights reserved.
//

#import "JCTitleButton.h"
@implementation JCTitleButton
{
    CGFloat buttonX ;
    CGFloat buttonW ;
    CGFloat buttonY ;
    CGFloat buttonH ;
    
    UIImageView *image;
}
- (void)layoutSubviews{
    [super layoutSubviews];
    CGRect titleF = self.titleLabel.frame;
    CGRect imageF = self.imageView.frame;
    self.titleLabel.center = CGPointMake(self.center.x - 10, self.center.y);
    titleF.origin.x = buttonX + buttonW / 2 - titleF.size.width / 2 - 5;
    self.titleLabel.frame = titleF;
    imageF.origin.x = CGRectGetMaxX(titleF)+5;
    self.imageView.frame = imageF;
    UIImage *imageName = [UIImage imageNamed:@"down"];
     image.frame = CGRectMake(buttonX + buttonW / 2 + self.titleLabel.frame.size.width / 2 + 5, (buttonY + buttonH / 2 - imageName.size.height / 2), imageName.size.width, imageName.size.height);
}
- (void)drawRect:(CGRect)rect{
    [self.titleLabel setFont:[UIFont systemFontOfSize:18]];
    buttonX = rect.origin.x;
    buttonW = rect.size.width;
    buttonY = rect.origin.y;
    buttonH = rect.size.height;
    for (UIView *view in self.subviews) {
        if ([view isKindOfClass:[UIImageView class]]) {
            [view removeFromSuperview];
        }
    }
    image = [[UIImageView alloc]init];
    image.image = [UIImage imageNamed:@"down"];
    if (self.selected) {
        image.image = [UIImage imageNamed:@"up"];
    }
    [self addSubview:image];

}

@end
