//
//  JCLotteryActivivityCollectionViewCell.m
//  JiCaiLottery
//
//  Created by Peng Jun on 2018/2/25.
//  Copyright © 2018年 JiCaiLottery. All rights reserved.
//

#import "JCLotteryActivivityCollectionViewCell.h"
#import "JCHeader.h"
@implementation JCLotteryActivivityCollectionViewCell
- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        [self initWithImage];
    }
    return self;
}
- (void)initWithImage
{
    UIView *line = [[UIView alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, 0.5)];
    line.backgroundColor = allLineColor;
    [self addSubview:line];
    NSDictionary *infoDictionary = [[NSBundle mainBundle] infoDictionary];
    NSString *app_Name = [infoDictionary objectForKey:@"CFBundleDisplayName"];
    self.label1 = [[UILabel alloc]init];
    //    self.label1.backgroundColor = allBackGroundColor;
    self.label1.textColor = JCTTTColor;
    self.label1.font = [UIFont systemFontOfSize:18.f];
    self.label1.numberOfLines = 2;
    self.label1.textAlignment = NSTextAlignmentLeft;
    self.label1.text = @"大乐透17068期推荐:前区胆码看好12 28 29";
    self.label1.adjustsFontSizeToFitWidth = YES;
    
//    CGFloat width = (ScreenWidth - 120 - 20) / 3;
    
    self.label2 = [[UILabel alloc]init];
    //    self.label2.backgroundColor = allBackGroundColor;
    self.label2.textColor = JCNNNColor;
//    self.label2.textColor = UICOLOR_HEX(0x00a0ff);
    self.label2.font = [UIFont systemFontOfSize:11.f];
    self.label2.textAlignment = NSTextAlignmentLeft;
    self.label2.text = app_Name;
    self.label2.adjustsFontSizeToFitWidth = YES;
    
    self.label3 = [[UILabel alloc]init];
    //    self.label3.backgroundColor = allBackGroundColor;
    self.label3.textColor = JCNNNColor;
    self.label3.font = [UIFont systemFontOfSize:11.f];
    self.label3.textAlignment = NSTextAlignmentLeft;
    self.label3.text = @"06-28";
    self.label3.adjustsFontSizeToFitWidth = YES;
    
    self.label4 = [[UILabel alloc]init];
    //    self.label4.backgroundColor = allBackGroundColor;
    self.label4.textColor =JCNNNColor;
    self.label4.font = [UIFont systemFontOfSize:11.f];
    self.label4.textAlignment = NSTextAlignmentRight;
    self.label4.text = @"阅读:20";
    
    self.imageView1 = [[UIImageView alloc]init];
    //    self.imageView1.backgroundColor = allBackGroundColor;
    //    self.imageView1.image = [UIImage imageNamed:@"zixunbanner"];
    
    [self sd_addSubviews:@[self.label1, self.label2, self.label3, self.label4, self.imageView1]];
    
    [self.label1 mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(self.mas_left).offset(12);
        make.top.mas_equalTo(self.mas_top).offset(12);
        make.right.mas_equalTo(self.mas_right).offset(-143);
       
    }];
    
    [self.label2 mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(self.mas_left).offset(12);
        make.bottom.mas_equalTo(self.mas_bottom).offset(-12);
//        make.right.mas_equalTo(self.mas_right).offset(-143);
    }];
    
    [self.label3 mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(self.mas_left).offset(ScreenWidth/4);
        make.bottom.mas_equalTo(self.mas_bottom).offset(-12);
        
        
    }];
    
   
    
    [self.imageView1 mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.mas_equalTo(self.mas_centerY);
        make.right.mas_equalTo(self.mas_right).offset(-12);
        make.size.mas_equalTo(CGSizeMake(115, 84));
    }];
    
    
    [self.label4 mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.mas_equalTo(self.imageView1.mas_left).offset(-10);
        make.bottom.mas_equalTo(self.mas_bottom).offset(-12);
        
    }];

}
@end
