//
//  JCLotteryCollectionViewCell.m
//  JiCaiLottery
//
//  Created by 风外杏林香 on 2017/5/5.
//  Copyright © 2017年 JiCaiLottery. All rights reserved.
//

#import "JCLotteryCollectionViewCell.h"
#import "JCHeader.h"
@interface JCLotteryCollectionViewCell ()
@property  (nonatomic, strong) UILabel *stopLabel;
@property  (nonatomic, strong) UIView *stopbgView;
@property  (nonatomic, strong) UIImageView *stopImgV;
@end
@implementation JCLotteryCollectionViewCell{
  
}

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        [self initWithUI];
    }
    return self;
}

- (void)initWithUI
{
    
//    self.backgroundColor = [UIColor redColor];
    self.lotteryImage = [[UIImageView alloc]init];
    [self addSubview:self.lotteryImage];
    [self.lotteryImage mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self.mas_top).offset(10);
        make.centerX.mas_equalTo(self.mas_centerX);
        make.size.mas_equalTo(CGSizeMake(50, 50));
    }];
    
    self.lotteryLabel = [[UILabel alloc]init];
    self.lotteryLabel.textColor = UICOLOR_HEX(0x333333);
    self.lotteryLabel.font = [UIFont systemFontOfSize:12.f];
    self.lotteryLabel.textAlignment = NSTextAlignmentCenter;
    [self addSubview:self.lotteryLabel];
    [self.lotteryLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self.lotteryImage.mas_bottom).offset(5);
        make.centerX.mas_equalTo(self.mas_centerX);
    }];
    
    
//    //
//    _stopbgView = [[UIView alloc]init];
//
//    _stopbgView.backgroundColor = [UIColor colorWithRed:0 green:0 blue:0 alpha:0.5];
//    _stopbgView.layer.cornerRadius = 25;
//    _stopbgView.layer.masksToBounds = YES;
//    [self addSubview:_stopbgView];
//    [_stopbgView mas_makeConstraints:^(MASConstraintMaker *make) {
//        make.top.mas_equalTo(self.lotteryImage.mas_top);
//        make.centerX.mas_equalTo(self.mas_centerX);
//        make.size.mas_equalTo(self.lotteryImage);
//    }];
//

//    _stopLabel = [[UILabel alloc]init];
//    _stopLabel.textAlignment = NSTextAlignmentCenter;
//    _stopLabel.text = @"暂停销售";
//    _stopLabel.textColor = [UIColor whiteColor];
//    _stopLabel.font = FONT(12);
//    [_stopbgView addSubview:_stopLabel];
//    [_stopLabel mas_makeConstraints:^(MASConstraintMaker *make) {
//        make.centerY.mas_equalTo(_stopbgView.mas_centerY);
//        make.centerX.mas_equalTo(_stopbgView.mas_centerX);
//
//    }];
    
    self.stopImgV = [[UIImageView alloc] init];
    self.stopImgV.image = [UIImage imageNamed:@"icon_stopSell"];
    [self addSubview:self.stopImgV];
    [self.stopImgV mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self.lotteryImage.mas_top).offset(-5);;
        make.left.mas_equalTo(self.lotteryImage.mas_right).offset(-5);
        make.size.mas_equalTo(CGSizeMake(30, 15));
    }];
    


}
- (void)setIsStop:(BOOL)isStop{

    _isStop = isStop;
    if (_isStop) {
//        _stopbgView.hidden = NO;
//        self.lotteryLabel.textColor = UICOLOR_HEX(0x999999);
        self.stopImgV.hidden = NO;
    }else{
//        _stopbgView.hidden = YES;
//        self.lotteryLabel.textColor = UICOLOR_HEX(0x333333);
        self.stopImgV.hidden = YES;
    }

}

@end
