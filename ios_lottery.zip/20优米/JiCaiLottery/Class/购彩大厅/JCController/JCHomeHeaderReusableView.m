//
//  JCHomeHeaderReusableView.m
//  JiCaiLottery
//
//  Created by Dxc_iOS on 2019/4/7.
//  Copyright © 2019 JiCaiLottery. All rights reserved.
//

#import "JCHomeHeaderReusableView.h"
#import <Masonry.h>
#import "JCHeader.h"
@interface JCHomeHeaderReusableView()
@end
@implementation JCHomeHeaderReusableView

- (id)initWithFrame:(CGRect)frame{
    self = [super initWithFrame:frame];
    if (self) {
        [self initWithUI];
    }
    return self;
}
- (void)initWithUI
{
    //
    UIView *leftLineView = [[UIView alloc]init];
    leftLineView .backgroundColor = allRedColor;
    leftLineView.hidden = YES;
    [self addSubview:leftLineView];
    
    leftLineView.sd_layout
    .leftSpaceToView(self, 20)
    .topSpaceToView(self, 10)
    .heightIs(20)
    .widthIs(2);
    
    //
    self.iconImage = [[UIImageView alloc]init];
    self.iconImage.image = [UIImage imageNamed:@""];//热门彩种
    [self addSubview:self.iconImage];
    
    self.iconImage.sd_layout
    .leftSpaceToView(self, ScreenWidth/2-40)
    .topSpaceToView(self, 10)
    .heightIs(20)
    .widthIs(20);
    
    //
    self.titleLabel = [[UILabel alloc]init];
    self.titleLabel.textAlignment = NSTextAlignmentLeft;
    self.titleLabel.font = [UIFont systemFontOfSize:14.f];
    self.titleLabel.textColor =JCTTTColor;
    [self addSubview:self.titleLabel];
    
    self.titleLabel.sd_layout
    .leftSpaceToView(self.iconImage, 2)
    .topSpaceToView(self, 5)
    .widthIs(ScreenWidth/2)
    .heightIs(30);
    
    //
    self.arrowImage = [[UIImageView alloc]init];
    self.arrowImage.image = [UIImage imageNamed:@"小尖头"];//小尖头
    [self addSubview:self.arrowImage];
    self.arrowImage.hidden = YES;
    
    self.arrowImage.sd_layout
    .rightSpaceToView(self, 20)
    .bottomSpaceToView(self, 12.5)
    .heightIs(15)
    .widthIs(9);
    
    UIButton *rightBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    [self addSubview:rightBtn];
    [rightBtn addTarget:self action:@selector(rightBtnClicked) forControlEvents:UIControlEventTouchUpInside];
    rightBtn.sd_layout
    .rightSpaceToView(self, 0)
    .bottomSpaceToView(self, 5)
    .heightIs(30)
    .widthIs(60);
    
    
    
    //
    UIView *bottomLine = [[UIView alloc]init];
    bottomLine.backgroundColor = UICOLOR_HEX(0xeeeeee);
    [self addSubview:bottomLine];
    
    bottomLine.sd_layout
    .leftSpaceToView(self, 0)
    .bottomSpaceToView(self, -0.5)
    .heightIs(0.5)
    .widthIs(ScreenWidth);
    
    
}

-(void)rightBtnClicked{
    JCLog(@"goNext");
    if (self.goNextBlock) {
        self.goNextBlock();
    }
    
}

@end
