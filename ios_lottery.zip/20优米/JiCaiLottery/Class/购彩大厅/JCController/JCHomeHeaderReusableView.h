//
//  JCHomeHeaderReusableView.h
//  JiCaiLottery
//
//  Created by Dxc_iOS on 2019/4/7.
//  Copyright © 2019 JiCaiLottery. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN
typedef void(^goNextBlock)(void);
@interface JCHomeHeaderReusableView : UICollectionReusableView
@property (nonatomic, strong)UILabel *titleLabel;
@property (nonatomic, strong)UIImageView *arrowImage;
@property (nonatomic, strong)UIImageView *iconImage;
@property (nonatomic, copy)goNextBlock goNextBlock;
@end

NS_ASSUME_NONNULL_END
