//
//  JCHomeViewController.m
//  JiCaiLottery
//
//  Created by Dxc_iOS on 2019/4/7.
//  Copyright © 2019 JiCaiLottery. All rights reserved.
//

#import "JCHomeViewController.h"
#import "JCActivityViewController.h"
#import "JCZiXunViewController.h"
#import "JCFootBallViewController.h"

#import "JCBasketBallViewController.h"
#import "JCNineOrFourteenViewController.h"

#import "JCLottertySource.h"
#import "JCZXDetailVC.h"
#import "ZhiBoViewController.h"
#import "JCLoginViewController.h"
#import "JCZXDetailVC.h"
#import "JCHomeDetailViewController.h"
#import "JCNumberDetailViewController.h"
#import "JCAthleticsViewController.h"
#import "JCDanBasketBallViewController.h"

#import "JCScoreViewController.h"
//view
#import "JCTitleButton.h"
#import "JCFourButtonView.h"
#import "JCTitleButton.h"
#import "JCFourButtonView.h"
#import "JCLotteryNameAndImage.h"
#import "JCListLotteryView.h"
#import "JCHomeHeaderReusableView.h"
#import "JCBuySuccessView.h"
#import "JCMarqeeView.h"
#import "JCLotteryCollectionViewCell.h"
#import "JCLotteryActivivityCollectionViewCell.h"

//mode
#import <SystemConfiguration/CaptiveNetwork.h>
#import "JCHeader.h"

//第三方库
#import "AFNetworking.h"
#import "MBProgressHUD.h"
#import <FFPopup/FFPopup.h>
#import <DZNEmptyDataSet/UIScrollView+EmptyDataSet.h>

static CGFloat const middleSelectedMatchHeight = 227.f;
static CGFloat const middleNormalMatchHeight = 180.f;
@interface JCHomeViewController ()<UICollectionViewDelegate, UICollectionViewDataSource, SDCycleScrollViewDelegate, JCFourButtonViewDelegate,DZNEmptyDataSetSource, DZNEmptyDataSetDelegate>
@property (nonatomic, strong)UICollectionView *lotteryCollectionView;
@property (nonatomic, strong)NSMutableArray *hostListArray;
@property (nonatomic, strong)NSMutableArray *shuzilistArray;
@property (nonatomic, strong)NSMutableArray *jingjilistArray;
@property (nonatomic, strong)NSMutableArray *kuaikailistArray;
@property (nonatomic, strong)NSMutableArray *zixunlistArray;
@property (nonatomic, strong)NSMutableArray *bannerArray;
@property (nonatomic, strong)NSDictionary *contentDic;
@property (nonatomic, strong)NSDictionary *matchDic;
@property (nonatomic, strong)NSMutableArray *allListDataArryOfArray;
@property (nonatomic, strong)NSMutableArray *allListDataTitleArray;
@property (nonatomic, strong)UIImageView *imageView;
@property (nonatomic, strong)SDCycleScrollView *cycleScrollView;
@property (nonatomic, strong)JCFourButtonView *buttonView;
@property (nonatomic, strong)JCMarqeeView *marqeeView;
@property (nonatomic, strong)MBProgressHUD *hud;
@property (nonatomic, strong)UIView *popView;
@property (nonatomic, retain)UIView *mengBanView;
@property (nonatomic, strong)NSDictionary *schemeDictionary;//获取得到的schemeId

//@property (nonatomic, strong)NSDictionary *lotteryDictionary;
//@property (nonatomic, strong)NSDictionary *lotteryNameDictionary;
@property (nonatomic, strong)NSMutableArray *NewWinlistArr;//中奖数组
@property (nonatomic, strong)NSDictionary *NewWinDic;
@property(nonatomic,strong)FFPopup *popupView;
@property(nonatomic,strong) UIView *contentView;
@property(nonatomic,copy) NSString *NewWinschemeId;//中奖订单
@property(nonatomic,copy) NSString *NewWinlotteryId;//中奖的比赛ID
@property(nonatomic,copy) NSString *NewWinlotteryName;//中奖的比赛名称
@property(nonatomic,copy) NSString *NewWinprize;//中奖金额
@property (nonatomic, copy)NSString *isBrokerageWhite;//是否是白名单
@property (nonatomic, copy) NSString *basketballH5url;
@property (nonatomic, copy) NSString *footballH5url;
@property (nonatomic, copy)NSString *prizeRange;//预测奖金
@end

@implementation JCHomeViewController{
    BOOL _isFootBallMacth;
    NSString *_bifengHtmlUrl;
    UIView *middle;//单关view
    NSArray *peiLvArray;//赔率数组
    NSString *peiLv;//默认赔率
    int touzhuMoney;
    UIButton *touzhuBtn;
    NSMutableArray * SPFArray;//单关玩法选择数组
    BOOL isChoose;//判断是否弹出价格选择view
    UIView *jiaView; //弹出价格选择view
    UIButton *yuceButton;//预测金额按钮
    NSString *matchIssueId;
    NSString *dayOfWeekStr;
    NSInteger isSelectedSingleMatch;
    CGFloat middleMatchHeight;
    
}

- (NSDictionary *)contentDic
{
    if (!_contentDic) {
        _contentDic = [NSDictionary dictionary];
    }
    return _contentDic;
}
#pragma mark -- 数组懒加载
- (NSMutableArray *)bannerArray
{
    if (!_bannerArray) {
        _bannerArray = [NSMutableArray array];
    }
    return _bannerArray;
}
- (NSMutableArray *)hostListArray
{
    if (!_hostListArray) {
        _hostListArray = [NSMutableArray array];
    }
    return _hostListArray;
}
- (NSMutableArray *)zixunlistArray
{
    if (!_zixunlistArray) {
        _zixunlistArray = [NSMutableArray array];
    }
    return _zixunlistArray;
}
- (NSMutableArray *)allListDataArryOfArray
{
    if (!_allListDataArryOfArray) {
        _allListDataArryOfArray = [NSMutableArray array];
    }
    return _allListDataArryOfArray;
}
- (NSMutableArray *)allListDataTitleArray
{
    if (!_allListDataTitleArray) {
        _allListDataTitleArray = [NSMutableArray arrayWithObjects:@"热门彩种",@"竞技彩",@"数字彩",@"快开彩",@"资讯", nil];
    }
    return _allListDataTitleArray;
}
- (NSMutableArray *)shuzilistArray
{
    if (!_shuzilistArray) {
        _shuzilistArray = [NSMutableArray array];
    }
    return _shuzilistArray;
}

- (NSMutableArray *)jingjilistArray
{
    if (!_jingjilistArray) {
        _jingjilistArray = [NSMutableArray array];
    }
    return _jingjilistArray;
}

- (NSMutableArray *)kuaikailistArray
{
    if (!_kuaikailistArray) {
        _kuaikailistArray = [NSMutableArray array];
    }
    return _kuaikailistArray;
}
-(NSMutableArray *)NewWinlistArr{
    if (!_NewWinlistArr) {
        _NewWinlistArr = [NSMutableArray array];
    }
    return _NewWinlistArr;
}

- (JCFourButtonView *)buttonView
{
    if (!_buttonView) {
        _buttonView = [[JCFourButtonView alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(self.cycleScrollView.frame) + 30, ScreenWidth, 100)];
        _buttonView.delegate = self;
        __weak typeof(self) weakSelf = self;
        _buttonView.buttonClickedBlock = ^(NSInteger index) {
            switch (index) {
                case 0:
                {
                    JCZiXunViewController *zixunVC = [[JCZiXunViewController alloc]init];
                    [weakSelf.navigationController pushViewController:zixunVC animated:YES];
                }
                    break;
                case 1:
                {
//                    ZhiBoViewController *vc = [[ZhiBoViewController alloc]init];
//                    vc.titString = @"比分";
//                    vc.foundurl = self->_bifengHtmlUrl?self->_bifengHtmlUrl:@"";
                    JCScoreViewController *vc = [[JCScoreViewController alloc]init];
                    vc.footballH5url = weakSelf.footballH5url;
                    vc.basketballH5url = weakSelf.basketballH5url;
                    [weakSelf.navigationController pushViewController:vc animated:YES];
                   
                  
                }
                    break;
                case 2:
                {
                    JCActivityViewController *activityVC = [[JCActivityViewController alloc]init];
                    [weakSelf.navigationController pushViewController:activityVC animated:YES];
                }
                    break;
              
                default:
                    break;
            }
            
            
        };
    }
    return _buttonView;
}


-(void)showWinPopView{
    
    FFPopup *popup = [FFPopup popupWithContentView:self.contentView showType:FFPopupShowType_BounceIn dismissType:FFPopupDismissType_BounceOut maskType:FFPopupMaskType_Dimmed dismissOnBackgroundTouch:NO dismissOnContentTouch:NO];
    
    [popup show];
    self.popupView = popup;
    
    
}

-(UIView *)contentView{
    if (!_contentView) {
        _contentView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 280, 250)];
        _contentView.backgroundColor = [UIColor whiteColor];
        _contentView.layer.cornerRadius = 16.f;
        
        UIImageView *topImgV = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"zhongjiang"]];
        topImgV.frame = CGRectMake(15,-20, _contentView.size.width-30, 40);
        topImgV.contentMode = UIViewContentModeScaleAspectFill;
        [_contentView addSubview:topImgV];
    
        
        UIImageView *leftImgV = [[UIImageView alloc] initWithFrame:CGRectZero];
        leftImgV.image =[UIImage imageNamed:@"left_coin"];
        //        imgV2.contentMode = UIViewContentModeScaleAspectFill;

        [_contentView addSubview:leftImgV];
        [leftImgV mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(_contentView.mas_left).offset(10);
            make.top.mas_equalTo(topImgV.mas_bottom).offset(10);
        }];
        
        UIImageView *rightImgV = [[UIImageView alloc] initWithFrame:CGRectZero];
        rightImgV.image =[UIImage imageNamed:@"right_coin"];
        //        imgV2.contentMode = UIViewContentModeScaleAspectFill;
        [_contentView addSubview:rightImgV];
        [rightImgV mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.mas_equalTo(_contentView.mas_right).offset(-10);
            make.top.mas_equalTo(topImgV.mas_bottom).offset(15);
        }];
        
        UILabel *centLab = [[UILabel alloc] initWithFrame:CGRectZero];
        centLab.textColor = [UIColor blackColor];
        centLab.font = [UIFont systemFontOfSize:18.f];
        centLab.text = @"恭喜您！";
        centLab.textAlignment = NSTextAlignmentCenter;
        [_contentView addSubview:centLab];
        [centLab mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerY.mas_equalTo(leftImgV.mas_centerY);
            make.centerX.mas_equalTo(_contentView.mas_centerX);;
            make.height.mas_equalTo(20);
           
        }];
        
        UILabel *centSubLab = [[UILabel alloc] initWithFrame:CGRectZero];
        centSubLab.textColor = [UIColor blackColor];
        centSubLab.font = [UIFont systemFontOfSize:14.f];
        centSubLab.textAlignment = NSTextAlignmentCenter;
        centSubLab.text = [NSString stringWithFormat:@"您的%@已经中奖",[NSString stringWithFormat:@"%@", [[JCLotteryInfo GetLotteryName] objectForKey:self.NewWinlotteryId]]];
        [_contentView addSubview:centSubLab];
        [centSubLab mas_makeConstraints:^(MASConstraintMaker *make) {
//            make.top.mas_equalTo(centLab.mas_bottom).offset(10);
            make.centerY.mas_equalTo(_contentView.mas_centerY);
            make.centerX.mas_equalTo(_contentView.mas_centerX);;
            make.height.mas_equalTo(20);
            
        }];
        
        
        UILabel *centMoneyLab = [[UILabel alloc] initWithFrame:CGRectZero];
        centMoneyLab.textColor = [UIColor redColor];
        centMoneyLab.font = [UIFont systemFontOfSize:30.f];
        centMoneyLab.textAlignment = NSTextAlignmentCenter;
        centMoneyLab.text = [NSString stringWithFormat:@"%@元",self.NewWinprize];;
        [_contentView addSubview:centMoneyLab];
        [centMoneyLab mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(centSubLab.mas_bottom).offset(15);
            make.centerX.mas_equalTo(_contentView.mas_centerX);;
            make.height.mas_equalTo(20);
            
        }];
        
        
        UIButton *closeBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        closeBtn.frame = CGRectMake(30, _contentView.size.height-40, 60, 30);
        [_contentView addSubview:closeBtn];
        [closeBtn setTitle:@"关闭" forState:UIControlStateNormal];
        [closeBtn.titleLabel setFont:[UIFont systemFontOfSize:14.f ]];
        [closeBtn setTitleColor:[UIColor lightGrayColor] forState:UIControlStateNormal];
        [closeBtn addTarget:self  action:@selector(closeBtnClicked) forControlEvents:UIControlEventTouchUpInside];
        
        UIButton *detailBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        detailBtn.frame = CGRectMake(_contentView.size.width-90, _contentView.size.height-40, 60, 30);
        [_contentView addSubview:detailBtn];
        [detailBtn setTitle:@"详情" forState:UIControlStateNormal];
        [detailBtn.titleLabel setFont:[UIFont systemFontOfSize:14.f ]];
        [detailBtn setTitleColor:[UIColor blueColor] forState:UIControlStateNormal];
        [detailBtn addTarget:self  action:@selector(detailBtnClicked) forControlEvents:UIControlEventTouchUpInside];
        
   
    }
    return _contentView;
    
    
}
-(void)closeBtnClicked{
    JCLog(@"朕知道了");
    [self.popupView dismissAnimated:YES];
    [self.popView removeFromSuperview];
}

-(void)detailBtnClicked{
    JCLog(@"查看详情");
    [self.popupView dismissAnimated:YES];
    

 if ([self.NewWinlotteryName isEqualToString:@"竞彩篮球"] || [self.NewWinlotteryName isEqualToString:@"竞彩足球"] || [self.NewWinlotteryName isEqualToString:@"北京单场"]) {
 JCAthleticsViewController *atheticeVC = [[JCAthleticsViewController alloc]init];
 atheticeVC.schemeId = [NSString stringWithFormat:@"%@", self.NewWinschemeId];
 atheticeVC.prize = [NSString stringWithFormat:@"%@", self.NewWinprize];
  atheticeVC.isShowCopyGendan = NO;
// [self.navigationController pushViewController:atheticeVC animated:YES];
      [[[[UIApplication sharedApplication] delegate] window].rootViewController presentViewController:atheticeVC animated:YES completion:nil];
 
 } else  if ([self.NewWinlotteryName isEqualToString:@"世界杯"]||[self.NewWinlotteryName isEqualToString:@"亚洲杯"]) {

 }
 else {
 JCNumberDetailViewController *numberVC = [[JCNumberDetailViewController alloc]init];
 numberVC.schemeId = [NSString stringWithFormat:@"%@", self.NewWinschemeId];
 numberVC.prize = [NSString stringWithFormat:@"%@", self.NewWinprize];
 numberVC.isShowCopyGendan = NO;
// [self.navigationController pushViewController:numberVC animated:YES];
      [[[[UIApplication sharedApplication] delegate] window].rootViewController presentViewController:numberVC animated:YES completion:nil];
 }

}


#pragma mark -- JCFourButtonViewDelegate
- (void)clickAllButtonAction:(UIButton *)sender
{
    JCLog(@"%ld", (long)sender.tag);
    switch (sender.tag) {
        case 0:
        {
            JCZiXunViewController *zixunVC = [[JCZiXunViewController alloc]init];
            [self.navigationController pushViewController:zixunVC animated:YES];
        }
            break;
        case 1:
        {
            [self.tabBarController setSelectedIndex:2];
        }
            break;
        case 2:
        {
            JCActivityViewController *activityVC = [[JCActivityViewController alloc]init];
            [self.navigationController pushViewController:activityVC animated:YES];
        }
            break;
        case 3:
        {
//            ZhiBoViewController *vc = [[ZhiBoViewController alloc]init];
//            vc.titString = @"比分";
//            vc.foundurl = _bifengHtmlUrl?_bifengHtmlUrl:@"";
            JCScoreViewController *vc = [[JCScoreViewController alloc]init];
            vc.footballH5url = self.footballH5url;
            vc.basketballH5url = self.basketballH5url;
            [self.navigationController pushViewController:vc animated:YES];
            
            
        }
            break;
        default:
            break;
    }
}
#pragma mark--  懒加载 lotteryCollectionView
- (UICollectionView *)lotteryCollectionView
{
    if (!_lotteryCollectionView) {
        UICollectionViewFlowLayout *flowLayout = [[UICollectionViewFlowLayout alloc]init];
        if (iPhoneX) {
            _lotteryCollectionView = [[UICollectionView alloc]initWithFrame:CGRectMake(0, STATUSH, ScreenWidth, ScreenHeight - TabbarHeight - STATUSH) collectionViewLayout:flowLayout];
        } else {
            _lotteryCollectionView = [[UICollectionView alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, ScreenHeight - TabbarHeight) collectionViewLayout:flowLayout];
        }
        _lotteryCollectionView.delegate = self;
        _lotteryCollectionView.dataSource = self;
        _lotteryCollectionView.emptyDataSetSource = self;
        _lotteryCollectionView.emptyDataSetDelegate = self;
        [_lotteryCollectionView registerClass:[JCLotteryCollectionViewCell class] forCellWithReuseIdentifier:@"cell"];
        [_lotteryCollectionView registerClass:[JCLotteryActivivityCollectionViewCell class] forCellWithReuseIdentifier:@"zxcell"];
        [_lotteryCollectionView registerClass:[UICollectionReusableView class] forSupplementaryViewOfKind:UICollectionElementKindSectionHeader withReuseIdentifier:@"headerView"];
        [_lotteryCollectionView registerClass:[JCHomeHeaderReusableView class] forSupplementaryViewOfKind:UICollectionElementKindSectionHeader withReuseIdentifier:@"JCHomeHeaderReusableView"];
        [_lotteryCollectionView registerClass:[UICollectionReusableView class] forSupplementaryViewOfKind:UICollectionElementKindSectionFooter withReuseIdentifier:@"footerView"];
        flowLayout.footerReferenceSize = CGSizeMake(ScreenWidth, 5);
        _lotteryCollectionView.backgroundColor = allWhiteColor;
        if (@available(iOS 11.0, *)) {
            _lotteryCollectionView.contentInsetAdjustmentBehavior = UIScrollViewContentInsetAdjustmentNever;
            _lotteryCollectionView.contentInset = UIEdgeInsetsMake(0, 0, 0, 0);
            _lotteryCollectionView.scrollIndicatorInsets = _lotteryCollectionView.contentInset;
        }
        self.automaticallyAdjustsScrollViewInsets = false;
    }
    return _lotteryCollectionView;
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    
    [self.navigationController setNavigationBarHidden:YES animated:!self.closeAnimating];
//    [self requestURL];
}

-(void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:animated];

}
- (void)viewDidLoad {
    [super viewDidLoad];
    middleMatchHeight = 180.f;
    self.view.backgroundColor = allBackGroundColor;
    SPFArray = [NSMutableArray array];
    [self.view addSubview:self.lotteryCollectionView];
    __block JCHomeViewController *blockSelf = self;
    self.lotteryCollectionView.mj_header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
        [blockSelf requestURL];
    }];
    
    [self.lotteryCollectionView.mj_header beginRefreshing];
    
    [self requestURL];
    [self newVersionRequest];
    
    //    防止通知接收多次
    static dispatch_once_t onceToken;
    
    dispatch_once(&onceToken, ^{
        [[NSNotificationCenter defaultCenter] addObserverForName:AFNetworkingReachabilityDidChangeNotification object:nil queue:nil usingBlock:^(NSNotification * _Nonnull note) {
            JCLog(@"网络变化收到了通知");
            [self requestURL];
            [self newVersionRequest];
        }];
        [[NSNotificationCenter defaultCenter] addObserverForName:@"homeRefreshUrl" object:nil queue:nil usingBlock:^(NSNotification * _Nonnull note) {
            JCLog(@"homeRefreshUrl收到了通知");
            [self requestURL];
            [self newVersionRequest];
        }];
        
        [[NSNotificationCenter defaultCenter] addObserverForName:@"loginSuccess" object:nil queue:nil usingBlock:^(NSNotification * _Nonnull note) {
            JCLog(@"loginSuccess收到了通知");
            [self loginSuccessRequestNewWinsData];
        }];
    });
    
    
    
}

- (void)afNetworkStatusChanged:(NSNotification*)noti{
    [self requestURL];
    [self newVersionRequest];
}

-(void)loginSuccess{
    
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [self loginSuccessRequestNewWinsData];
        
    });
    
    
}

#pragma mark -- UICollectionViewDataSource UICollectionViewDelegate
- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView
{
    return self.allListDataArryOfArray.count>0 ?(self.allListDataArryOfArray.count): 5;
}
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    
    if (section <=(self.allListDataArryOfArray.count -2) ) {
        if (self.allListDataArryOfArray.count>0) {
            NSMutableArray *arr = self.allListDataArryOfArray[section];
            return arr.count+1;
//            return 9;
        }else{
            return 0;
        }
    }else if(section == (self.allListDataArryOfArray.count -1)){
        return self.zixunlistArray.count;
    }else{
        return 0;
    }
  
}


#pragma mark -- SectionHeader高度
-(CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout referenceSizeForHeaderInSection:(NSInteger)section
{
    if (section == 0) {
        if (_isFootBallMacth) {
            return CGSizeMake(ScreenWidth, 60+ 205*ScreenScale + 45 + 30+40+ middleMatchHeight*(ScreenScale>1?ScreenScale:1));
        }else{
            return CGSizeMake(ScreenWidth, 60 + 205*ScreenScale + 45 + 30+40);}
    } else {
        return CGSizeMake(ScreenWidth, 40);
    }
}

#pragma mark -- 自定义 SectionHeader
-(UICollectionReusableView *)collectionView:(UICollectionView *)collectionView viewForSupplementaryElementOfKind:(NSString *)kind atIndexPath:(NSIndexPath *)indexPath
{
   
    if (kind == UICollectionElementKindSectionHeader) {
        
        JCHomeHeaderReusableView  *headerView = [collectionView dequeueReusableSupplementaryViewOfKind:UICollectionElementKindSectionHeader withReuseIdentifier:@"JCHomeHeaderReusableView" forIndexPath:indexPath];
//        headerView.backgroundColor = [UIColor cyanColor];
        for(UIView *view in [headerView subviews]) {
            if (view) {
                if (view.tag == 6162) {
                    NSLog(@"%ld,",(long)view.tag);
                }else{
                    [view removeFromSuperview];//移除掉重复的view
                }
                
            }
        }
        if (_allListDataTitleArray.count>0){
            
            if (indexPath.section == 0) {
                _cycleScrollView = [SDCycleScrollView cycleScrollViewWithFrame:CGRectMake(0, 0, ScreenWidth, 205*ScreenScale) delegate:self placeholderImage:[UIImage imageNamed:@"banner"]];
                NSMutableArray *appbigImg = [NSMutableArray array];
                if (self.bannerArray.count > 0) {
                    for (int i = 0; i < self.bannerArray.count; i ++) {
                        NSDictionary *dict = [self.bannerArray objectAtIndex:i];
                        [appbigImg addObject:[dict objectForKey:@"bigImg"]];
                    }
                }
                if (self.bannerArray.count == 0) {
                    _cycleScrollView.localizationImageNamesGroup = @[@"banner", @"banner0", @"banner00", @"banner000"];
                } else {
                    _cycleScrollView.imageURLStringsGroup = appbigImg;
                }
                
                UIView *noticeView = [[UIView alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(_cycleScrollView.frame), ScreenWidth, 40)];
                noticeView.backgroundColor = [UIColor whiteColor];
                [headerView addSubview:noticeView];
                
                UITapGestureRecognizer *noticeTap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(gonggaoAction:)];
                [noticeView addGestureRecognizer:noticeTap];
                if ([[self.contentDic objectForKey:@"title"] length] > 0) {
                    self.marqeeView = [[JCMarqeeView alloc]initWithFrame:CGRectMake(50, 5, CGRectGetWidth(noticeView.frame) - 32, 30.0)];
                    NSString *contentString = [self.contentDic objectForKey:@"content"];
                    
                    self.marqeeView.title = [NSString stringWithFormat:@"%@ %@", [self.contentDic objectForKey:@"title"], contentString];
                    
                    [noticeView addSubview:self.marqeeView];
                }
                self.imageView = [[UIImageView alloc]initWithFrame:CGRectMake(0, 5, 50, 30)];
                self.imageView.image = [UIImage imageNamed:@"notice_image"];
                self.imageView.contentMode = UIViewContentModeCenter;
                self.imageView.backgroundColor = [UIColor whiteColor];
                [noticeView addSubview:self.imageView];
                [headerView addSubview:_cycleScrollView];
                //
                [headerView addSubview:self.buttonView];
                UIView *lineView;
                //        竞足单关
                if (_isFootBallMacth) {
                    UIView *colorView2 = [[UIView alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(self.buttonView.frame), ScreenWidth, 10)];
                    colorView2.backgroundColor = allBackGroundColor;
                    [headerView addSubview:colorView2];
                    
                    [self addMatch:headerView frame:CGRectMake(0, CGRectGetMaxY(colorView2.frame), ScreenWidth, middleMatchHeight*(ScreenScale>1?ScreenScale:1))];
                    lineView = [[UIView alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(middle.frame), ScreenWidth, 5)];
                }else{
                    if (middle) {
                        [middle removeFromSuperview];
                    }
                    lineView = [[UIView alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(self.buttonView.frame), ScreenWidth, 5)];
                }
                
                lineView.backgroundColor = allBackGroundColor;
                [headerView addSubview:lineView];
                
                
                //区头headView
                JCListLotteryView *listLotteryView = [[JCListLotteryView alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(lineView.frame), ScreenWidth, 40)];
                [headerView addSubview:listLotteryView];
                listLotteryView.titleLabel.text = self.allListDataTitleArray[indexPath.section];
                
                listLotteryView.goNextBlock = ^{
                    JCHomeDetailViewController*vc =  [JCHomeDetailViewController new];
                    vc.hidesBottomBarWhenPushed = YES;
                    [self.navigationController pushViewController:vc animated:YES];
                    
                };
                
            }
            else{
                
                //区头headView
                JCListLotteryView *listLotteryView = [[JCListLotteryView alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, 40)];
                [headerView addSubview:listLotteryView];
                listLotteryView.titleLabel.text = self.allListDataTitleArray[indexPath.section];
                if ([self.allListDataTitleArray[indexPath.section] isEqualToString:@"资讯"]) {
                    listLotteryView.arrowButton.hidden = YES;
                }
                
                
            }
            
            
            
            
        }
        
        return headerView;
        
        
    }
    if (kind == UICollectionElementKindSectionFooter) {
        UICollectionReusableView *footerView = [collectionView dequeueReusableSupplementaryViewOfKind:UICollectionElementKindSectionFooter withReuseIdentifier:@"footerView" forIndexPath:indexPath];
        for(UIView *view in [footerView subviews]) {
            if (view) {
                [view removeFromSuperview];//移除掉重复的view
            }
        }
        if (_allListDataTitleArray.count>0) {
            footerView.backgroundColor = allBackGroundColor;
        }
        return footerView;
        
        
    }
    
    return nil;
    
}

-(UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *identifier = @"cell";
    static NSString *zxidentifier = @"zxcell";
    
    if (indexPath.section<=(self.allListDataArryOfArray.count-2)) {
        
        JCLotteryCollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:identifier forIndexPath:indexPath];
        for (UIView *view in cell.contentView.subviews) {
            [view removeFromSuperview];
        }
        NSMutableArray *arr = self.allListDataArryOfArray[indexPath.section];
        
        if (indexPath.row < self.hostListArray.count) {//self.hostListArray.count
            
            NSDictionary *dict = [arr objectAtIndex:indexPath.row];
            NSString *lotteryId = [NSString stringWithFormat:@"%@", [dict objectForKey:@"lotteryId"]];
         
            cell.lotteryImage.image = [UIImage imageNamed:[[JCLotteryInfo GetLotteryPic] objectForKey:lotteryId]];

            cell.lotteryLabel.text = [NSString stringWithFormat:@"%@", [[JCLotteryInfo GetLotteryName] objectForKey:lotteryId]];
            
//     cell.isStop = ([[dict objectForKey:@"isStop"] integerValue] == 1);
            
            if ( [self.isBrokerageWhite integerValue] == 1 ) {//白名单显示彩种
                cell.isStop = NO;
                
            }else{
                cell.isStop = ([[dict objectForKey:@"isStop"] integerValue] == 1);
            }
        }
        else if (indexPath.row  == self.hostListArray.count)  {//self.hostListArray.count
            cell.isStop = 0;
            cell.lotteryLabel.text = @"更多";
            cell.lotteryImage.image = [UIImage imageNamed:@"home_more"];
        }
        
        
      
        return cell;
    }else{
        JCLotteryActivivityCollectionViewCell *zxcell = [collectionView dequeueReusableCellWithReuseIdentifier:zxidentifier forIndexPath:indexPath];
        for (UIView *view in zxcell.contentView.subviews) {
            [view removeFromSuperview];
        }
        NSMutableArray *arr = self.allListDataArryOfArray[indexPath.section];
        NSDictionary *dict = [arr objectAtIndex:indexPath.row];
        NSDictionary *infoDictionary = [[NSBundle mainBundle] infoDictionary];
        NSString *app_Name = [infoDictionary objectForKey:@"CFBundleDisplayName"];
        //            NSDictionary *dict = [self.dataArray objectAtIndex:indexPath.row];
        NSString *au = dict[@"author"];
        zxcell.label2.text =au.length>0?au:app_Name;
        zxcell.label1.text = [dict objectForKey:@"newstitle"];
        NSString *datestr = [dict objectForKey:@"dateTime"];
        NSArray *array = [datestr componentsSeparatedByString:@" "];
        if ([[array objectAtIndex:0] length] >= 5 && [[array objectAtIndex:1] length] >= 5) {
            zxcell.label3.text = [NSString stringWithFormat:@"%@", [[array objectAtIndex:0] substringFromIndex:5]];
        }
        //                actiVityCell.label3.text = dict[@"dateTime"];
        //        int ran = (arc4random() % 10);
        zxcell.label4.text =[NSString stringWithFormat:@"阅读:%@", dict[@"scanNums"]];
        [zxcell.imageView1 sd_setImageWithURL:[NSURL URLWithString:dict[@"bigImg"]] placeholderImage:[UIImage imageNamed:@"zixunbanner"]];
        zxcell.backgroundColor = allWhiteColor;
        return zxcell;
    }
    
}
#pragma mark -- 定义每个Item 的大小
- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.section <= (self.allListDataArryOfArray.count -2)) {
        return CGSizeMake((ScreenWidth - 50) / 3, 85);
    }else{
        return CGSizeMake(ScreenWidth, 108);
    }
    
}

#pragma mark -- 定义每个UICollectionView 的 margin
-(UIEdgeInsets)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout insetForSectionAtIndex:(NSInteger)section
{
    if (section <=(self.allListDataArryOfArray.count -2)) {
        return UIEdgeInsetsMake(5, 10, 10, 10);
    }else{
        return UIEdgeInsetsZero;
    }
    
}

#pragma mark -- 设置最小行间距，也就是前一行与后一行的中间最小间隔
- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout minimumLineSpacingForSectionAtIndex:(NSInteger)section {
    if (section<=(self.allListDataArryOfArray.count -2)) {
        return 10;
    }else{
        return 0.001;
    }
    
}

#pragma mark -- 设置最小列间距，也就是左行与右一行的中间最小间隔
- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout minimumInteritemSpacingForSectionAtIndex:(NSInteger)section {
    if (section <=3) {
        return 5;
    }else{
        return 0.001;
    }
    
}
#pragma mark -- 点击 Item
- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    
    
if (indexPath.section <=(self.allListDataArryOfArray.count -2)) {
    
    if (indexPath.row <self.hostListArray.count) {///self.hostListArray.count //8
        NSMutableArray *arr = self.allListDataArryOfArray[indexPath.section];
        NSDictionary *dict = [arr objectAtIndex:indexPath.row];
        

        
        
        if ( [self.isBrokerageWhite integerValue] == 1 ) {//白名单显示彩种
            //        [JCPopObject showMessage:@"暂停销售"];
            //        return;
        }else{
            //        不是白名单时 在判断 isStop
            if ([[dict objectForKey:@"isStop"] integerValue] == 1 ) {
                [JCPopObject showMessage:@"暂停销售"];
                return;
            }
        }
        NSInteger lotteryId = [[dict objectForKey:@"lotteryId"] integerValue];
        if (lotteryId ==10057) {
           
        }else if (lotteryId ==10058||//竞彩篮球
                  lotteryId ==10002){//竞篮单关
            
            NSString* lotteryIdStr =  @"10058";
            
            if (lotteryId ==10002) {
                //                basketVC.isShowDanguan = YES;
                JCDanBasketBallViewController *basketVC = [[JCDanBasketBallViewController alloc]init];
                basketVC.lotteryId = lotteryIdStr;
                
                [self.navigationController pushViewController:basketVC animated:YES];
            }else{
                JCBasketBallViewController *basketVC = [[JCBasketBallViewController alloc]init];
                basketVC.lotteryId = lotteryIdStr;
                
                [self.navigationController pushViewController:basketVC animated:YES];
            }
            
        }else if (lotteryId ==10059||//竞彩足球
                  lotteryId ==10001){//竞足单关
            JCFootBallViewController *footVC = [[JCFootBallViewController alloc]init];
            footVC.lotteryId = [NSString stringWithFormat:@"%ld", (long)lotteryId];
            JCLog(@"lotteryId = %@",footVC.lotteryId );
            //    footVC.isShowDanguan = YES;
            if (lotteryId ==10001) {
                footVC.isShowDanguan = YES;
            }else{
                 footVC.isShowDanguan = NO;
            }
            
            [self.navigationController pushViewController:footVC animated:YES];
        }else if (lotteryId ==10032){
          
        }else if (lotteryId ==10026){
            
        }else if (lotteryId ==10025){
          
        }else if (lotteryId ==10030){
           
        }else if (lotteryId ==10112){
            
        }else if (lotteryId ==10212){
           
        }else if (lotteryId ==10039||lotteryId ==10040||lotteryId ==10041||lotteryId ==10042){
            JCNineOrFourteenViewController *nineOrfourVC = [[JCNineOrFourteenViewController alloc]init];
            nineOrfourVC.lotteryId = [NSString stringWithFormat:@"%@", [dict objectForKey:@"lotteryId"]];
            [self.navigationController pushViewController:nineOrfourVC animated:YES];
        }else if (lotteryId == 10046 || lotteryId == 10060|| lotteryId == 10114  || lotteryId == 10062 || lotteryId == 10103 || lotteryId == 10104 || lotteryId == 10066 || lotteryId == 10086 || lotteryId == 10108 || lotteryId == 10109 || lotteryId == 10110|| lotteryId == 10111 || lotteryId == 10115|| lotteryId == 10202){
            
        }else if (lotteryId == 10064||lotteryId == 10201){//快乐十分
          
        }else if (lotteryId == 10038 || lotteryId == 10061 || lotteryId == 10105) {//时时彩
           
        }else if (lotteryId ==10067){
            
        }else if (lotteryId == 10073 || lotteryId == 10085 || lotteryId == 10102 || lotteryId == 10101 || lotteryId == 10065 || lotteryId == 10087 || lotteryId == 10106 || lotteryId == 10107||lotteryId == 10113||lotteryId == 10074||lotteryId == 10203){
          
        }else if (lotteryId == 10084){
          
        }else if (lotteryId == 10089){
           
        }else if (lotteryId ==10033){
          
        }else if (lotteryId ==10028){
           
        }else if (lotteryId ==10035){
          
        }else if (lotteryId ==10029){
          
        }else if (lotteryId ==100241){
            
        }else if (lotteryId ==10027){
            
        }else if (lotteryId ==10024){
          
        }else if (lotteryId ==10088){
           
        }
        
        
    }
    else{
        
        JCLog(@"点击最后一个");
        JCHomeDetailViewController*vc =  [JCHomeDetailViewController new];
        vc.hidesBottomBarWhenPushed = YES;
        [self.navigationController pushViewController:vc animated:YES];
        
    }
    
      }

else{
            if (self.zixunlistArray.count > 0) {
                NSDictionary *dict = [self.zixunlistArray objectAtIndex:indexPath.row];
                NSString *contentId = [dict objectForKey:@"id"];
                //        JCActivityDeatilViewController *activityVC = [[JCActivityDeatilViewController alloc]init];
                //        activityVC.contentId = [NSString stringWithFormat:@"%@", contentId];
                //        activityVC.titleString = @"活动";
                //        [self.navigationController pushViewController:activityVC animated:YES];
                JCZXDetailVC *zxVC = [[JCZXDetailVC alloc]init];
                zxVC.zxId = contentId;
                zxVC.isZiZun = YES;
                zxVC.titleText = @"活动详情";
                [self.navigationController pushViewController:zxVC animated:YES];
            }
        }

    
}

#pragma mark -- 数据请求
- (void)requestURL
{
    if (![JCRequestNetWork isNetWorkConnectionAvailable]) {
        [self.lotteryCollectionView.mj_header endRefreshing];
        return;
    }
    NSString *urlString = [JCAllUrl lotteryListUrl];
//    极店版
    NSDictionary *dic = @{
                          @"listType":@"1"
                          };
    [JCRequestNetWork postWithUrlString:urlString parameters:dic success:^(id data) {
        
        [self.lotteryCollectionView.mj_header endRefreshing];
        NSDictionary *dictionary = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableLeaves error:nil];
        
        if ([dictionary objectForKey:@"errorMessage"] || [[dictionary objectForKey:@"flag"] intValue] == -1) {
            [JCPopObject showMessage:dictionary[@"errorMessage"]];
            JCLoginViewController *jcLoginVC = [[JCLoginViewController alloc]init];
            [self presentViewController:jcLoginVC animated:YES completion:nil];
            return ;
        }
        
        
        self.hostListArray = [[dictionary objectForKey:@"list"] mutableCopy];//list //hotlist

        JCLog(@"self.hostListArray.count = %lu",(unsigned long)self.hostListArray.count);
        
        self.jingjilistArray = [[dictionary objectForKey:@"jingjilist"] mutableCopy];
        self.kuaikailistArray = [[dictionary objectForKey:@"kuaikailist"] mutableCopy];
        self.shuzilistArray = [[dictionary objectForKey:@"shuzilist"] mutableCopy];
        self.zixunlistArray =[NSMutableArray arrayWithArray:[dictionary objectForKey:@"indexZxlist"]];
        self.bannerArray = [dictionary objectForKey:@"appBanners"];
        self.contentDic = [dictionary objectForKey:@"content"];
        self.matchDic = [dictionary objectForKey:@"footballMatch"];
        dayOfWeekStr = [dictionary objectForKey:@"dayOfWeekStr"];
        matchIssueId = [dictionary objectForKey:@"issueId"];
        _isFootBallMacth = [[dictionary objectForKey:@"is_footballMatch"] boolValue];
        _bifengHtmlUrl = [dictionary objectForKey:@"h5Url"];
        self.basketballH5url = [dictionary objectForKey:@"basketballH5url"];
        self.footballH5url = [dictionary objectForKey:@"footballH5url"];
        peiLvArray = [dictionary objectForKey:@"peilv"];
        peiLv = peiLvArray[0];
        self.isBrokerageWhite =  [dictionary objectForKey:@"isBrokerageWhite"];
        JCLog(@"isBrokerageWhite = %@",self.isBrokerageWhite);
        

        //   10024 :排列3    100241:排列5
        NSArray *allLotteryKeys = [[JCLotteryInfo GetLotteryName] allKeys];
        for (int i = 0; i < self.shuzilistArray.count; i ++) {//插入排列5
            NSDictionary *dict = self.shuzilistArray[i];
            if ([dict[@"lotteryId"] integerValue] == 10024) {
                NSMutableDictionary *dic3 = [[NSMutableDictionary alloc]initWithDictionary:dict];
                [dic3 setValue:@"100241" forKey:@"lotteryId"];
                [self.shuzilistArray insertObject:dic3 atIndex:i + 1];
                break;
            }
        }
        
        //去掉后台返回，本地没有的彩种
        
        for (int i = 0; i < self.hostListArray.count; i ++) {
            NSDictionary *dict = self.hostListArray[i];
            NSString *LottteryidString =[NSString stringWithFormat:@"%@",dict[@"lotteryId"]];
            if (![allLotteryKeys containsObject:LottteryidString]) {
                [self.hostListArray removeObjectAtIndex:i];
                i = i - 1;
            }
        }
        for (int i = 0; i < self.jingjilistArray.count; i ++) {
            NSDictionary *dict = self.jingjilistArray[i];
            NSString *LottteryidString = [NSString stringWithFormat:@"%@",dict[@"lotteryId"]];
            if (![allLotteryKeys containsObject:LottteryidString]) {
                [self.jingjilistArray removeObjectAtIndex:i];
                i = i - 1;
            }
        }
        for (int i = 0; i < self.kuaikailistArray.count; i ++) {
            NSDictionary *dict = self.kuaikailistArray[i];
            NSString *LottteryidString = [NSString stringWithFormat:@"%@",dict[@"lotteryId"]];
            if (![allLotteryKeys containsObject:LottteryidString]) {
                [self.kuaikailistArray removeObjectAtIndex:i];
                i = i - 1;
            }
        }
        for (int i = 0; i < self.shuzilistArray.count; i ++) {
            NSDictionary *dict = self.shuzilistArray[i];
            NSString *LottteryidString = [NSString stringWithFormat:@"%@",dict[@"lotteryId"]];
            if (![allLotteryKeys containsObject:LottteryidString]) {
                [self.shuzilistArray removeObjectAtIndex:i];
                i = i - 1;
            }
        }
        if (self.hostListArray.count > 0) {
            [self.allListDataTitleArray removeAllObjects];
            [self.allListDataArryOfArray removeAllObjects];
        }
        [self AddArrayToAllDataArray:self.hostListArray andHeadTitle:@"热门彩种"];
        [self AddArrayToAllDataArray:self.jingjilistArray andHeadTitle:@"竞技彩"];
        [self AddArrayToAllDataArray:self.kuaikailistArray andHeadTitle:@"快开彩"];
        [self AddArrayToAllDataArray:self.shuzilistArray andHeadTitle:@"数字彩"];
        [self AddArrayToAllDataArray:self.zixunlistArray andHeadTitle:@"资讯"];
        //
        __weak typeof(self)weakSelf = self;
        dispatch_async(dispatch_get_main_queue(), ^{
            [weakSelf.lotteryCollectionView reloadData];
             [weakSelf.lotteryCollectionView   reloadEmptyDataSet];
        });
        
       
        
    } failure:^(NSError *error) {
        [self.lotteryCollectionView.mj_header endRefreshing];
        JCLog(@"errpr -- %@", error);
    } showView:nil];
}
#pragma mark --  中奖弹窗（只弹出一次）
-(void)requestNewWinsData{
     [self.NewWinlistArr removeAllObjects];
    if (![JCRequestNetWork isNetWorkConnectionAvailable]) {
        [self.lotteryCollectionView.mj_header endRefreshing];
        return;
    }
    NSString *urlString = [JCAllUrl lotteryListUrl];
    
    NSDictionary *dic = @{
                          @"listType":@"1"
                          };
    
    
    [JCRequestNetWork postWithUrlString:urlString parameters:dic success:^(id data) {
        
        [self.lotteryCollectionView.mj_header endRefreshing];
        NSDictionary *dictionary = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableLeaves error:nil];
        
        if ([dictionary objectForKey:@"errorMessage"] ||[[dictionary objectForKey:@"flag"] intValue] == -1) {
            [JCPopObject showMessage:dictionary[@"errorMessage"]];
            JCLoginViewController *jcLoginVC = [[JCLoginViewController alloc]init];
            [self presentViewController:jcLoginVC animated:YES completion:nil];
            return ;
        }
        
        
        self.NewWinlistArr = [[dictionary objectForKey:@"newWinlist"] mutableCopy];
        JCLog(@"self.NewWinlistArr = %@",self.NewWinlistArr);
        if (self.NewWinlistArr.count>0) {
            
            self.NewWinDic  = [self.NewWinlistArr lastObject];
            self.NewWinschemeId = self.NewWinDic[@"schemeId"];
            self.NewWinlotteryId = [NSString stringWithFormat:@"%@",self.NewWinDic[@"lotteryId"]]; ;
            self.NewWinprize = self.NewWinDic[@"prize"];
            self.NewWinlotteryName =  [[JCLotteryInfo GetLotteryName] objectForKey:self.NewWinlotteryId];
            JCLog(@" NewWinschemeId = %@, NewWinlotteryId = %@,NewWinprize =%@,lotteryName = %@",self.NewWinschemeId,self.NewWinlotteryId,self.NewWinprize ,self.NewWinlotteryName);
            
            [UserDefaults setObject:[NSString stringWithFormat:@"%@", self.NewWinschemeId] forKey:@"NewWinschemeId"];
            [UserDefaults synchronize];
            
            dispatch_async(dispatch_get_main_queue(), ^{
                
                if ([JCTool judgeIsFirstLoad:@"first"]) {
                    JCLog(@"第一次显示");
                    [self showWinPopView];
                }
                else if ([JCTool judgeIsFirstLoad:@"first"]&&
                        ![[UserDefaults objectForKey:@"NewWinschemeId"] isEqualToString:self.NewWinschemeId] )  {
                     JCLog(@"再次显示");
                     [self showWinPopView];
                }
                
            });
            
            
        }else{
            [UserDefaults setObject:@"" forKey:@"NewWinschemeId"];
            [UserDefaults synchronize];
        }
        
        
        
    } failure:^(NSError *error) {
        
        
        JCLog(@"errpr -- %@", error);
    } showView:nil];
}
#pragma mark -- 登录成功弹出 中奖弹窗
-(void)loginSuccessRequestNewWinsData{
    
    [self.NewWinlistArr removeAllObjects];
    if (![JCRequestNetWork isNetWorkConnectionAvailable]) {
        [self.lotteryCollectionView.mj_header endRefreshing];
        return;
    }
    NSString *urlString = [JCAllUrl lotteryListUrl];
    
    NSDictionary *dic = @{
                          @"listType":@"1"
                          };

    [JCRequestNetWork postWithUrlString:urlString parameters:dic success:^(id data) {
        
        [self.lotteryCollectionView.mj_header endRefreshing];
        NSDictionary *dictionary = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableLeaves error:nil];
        
        if ([dictionary objectForKey:@"errorMessage"] ||[[dictionary objectForKey:@"flag"] intValue] == -1) {
            [JCPopObject showMessage:dictionary[@"errorMessage"]];
            JCLoginViewController *jcLoginVC = [[JCLoginViewController alloc]init];
            [self presentViewController:jcLoginVC animated:YES completion:nil];
            return ;
        }
        
        self.NewWinlistArr = [[dictionary objectForKey:@"newWinlist"] mutableCopy];
       
        if (self.NewWinlistArr.count>0) {
            
            self.NewWinDic  = [self.NewWinlistArr lastObject];
            self.NewWinschemeId = self.NewWinDic[@"schemeId"];
            self.NewWinlotteryId = [NSString stringWithFormat:@"%@",self.NewWinDic[@"lotteryId"]]; ;
            self.NewWinprize = self.NewWinDic[@"prize"];
            self.NewWinlotteryName =  [[JCLotteryInfo GetLotteryName] objectForKey:self.NewWinlotteryId];
            [UserDefaults setObject:[NSString stringWithFormat:@"%@", self.NewWinschemeId] forKey:@"NewWinschemeId"];
            [UserDefaults synchronize];
            
            dispatch_async(dispatch_get_main_queue(), ^{
                
                 [self showWinPopView];
                JCLog(@"登录成功弹出一次");
            });
            
            
        }else{
            [UserDefaults setObject:@"" forKey:@"NewWinschemeId"];
            [UserDefaults synchronize];
        }
        
        
        
    } failure:^(NSError *error) {
        JCLog(@"errpr -- %@", error);
    } showView:nil];
    
}
#pragma mark --  SDCycleScrollViewDelegate
- (void)cycleScrollView:(SDCycleScrollView *)cycleScrollView didSelectItemAtIndex:(NSInteger)index
{
    NSString *isLogin = [UserDefaults objectForKey:@"isLogin"];
    if ([isLogin intValue] == 0) {
        [JCPopObject showMessage:@"请登录账号！"];
        return;
    }
    NSLog(@"点击第%ld",(long)index);
    if (self.bannerArray.count > 0) {
        NSDictionary *dict = [self.bannerArray objectAtIndex:index];
        JCLog(@"dict -- %@", dict);
        JCZXDetailVC *detailVC = [[JCZXDetailVC alloc]init];
        detailVC.zxId = [dict objectForKey:@"id"];
        detailVC.isZiZun = NO;
        [self.navigationController pushViewController:detailVC animated:YES];
    }
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
#pragma mark -- 公告点击
- (void)gonggaoAction:(UITapGestureRecognizer *)tap{
    NSString *isLogin = [UserDefaults objectForKey:@"isLogin"];
    if ([isLogin intValue] == 0) {
        [JCPopObject showMessage:@"请登录账号！"];
        return;
    }
    if (![self.contentDic objectForKey:@"id"]) {
        return;
    }
    //    NSLog(@"点击第%ld",(long)index);
    //    if (self.bannerArray.count > 0) {
    //        NSDictionary *dict = [self.bannerArray objectAtIndex:index];
    //        JCLog(@"dict -- %@", dict);
    JCZXDetailVC *detailVC = [[JCZXDetailVC alloc]init];
    detailVC.zxId = [self.contentDic objectForKey:@"id"];
    detailVC.isZiZun = NO;
    [self.navigationController pushViewController:detailVC animated:YES];
    //    }
}
- (void)AddArrayToAllDataArray:(NSMutableArray *)arr andHeadTitle:(NSString *)title{
    if ([title isEqualToString:@"资讯"]) {
        [self.allListDataArryOfArray addObject:arr];
        [self.allListDataTitleArray addObject:title];
        
//        JCLog(@"首页数据数组(资讯)allListDataArryOfArray = %@",self.allListDataArryOfArray);
        
//        JCLog(@"首页数据标题数组(资讯)allListDataArryOfArray = %@",self.allListDataTitleArray);
    }else{
        if (arr.count > 0) {
            [self.allListDataArryOfArray addObject:arr];
            [self.allListDataTitleArray addObject:title];
            
//            JCLog(@"首页数据数组allListDataArryOfArray = %@",self.allListDataArryOfArray);
            
//            JCLog(@"首页数据标题数组allListDataArryOfArray = %@",self.allListDataTitleArray);
            
        }}
}
#pragma mark 中间赛事
- (void)addMatch:(UIView*)headView frame:(CGRect)frame{
    if (!middle) {
        middle = [[UIView alloc]initWithFrame:frame];
        middle.tag = 6162;
        middle.backgroundColor = [UIColor whiteColor];
        [headView addSubview:middle];
        CGFloat magrn;
        if (ScreenWidth>375) {
            magrn = 15;
        }if (ScreenWidth<375) {
            magrn = 5;
        }else{
            magrn = 10;
        }
        CGFloat  width = (ScreenWidth-magrn*5)/4;
        
        UIImageView *leftImgV = [[UIImageView alloc]initWithImage:[UIImage imageNamed:@"home_zhudui"]];
        leftImgV.frame = CGRectMake(0, 0, 50, 50);
        leftImgV.center = CGPointMake(ScreenWidth / 4-20, 10+33+40);
        [middle addSubview:leftImgV];
        
        UILabel *label = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, width+20, 20)];
        label.text = [self dateFomatter:[self.matchDic[@"matchTime"] componentsSeparatedByString:@" "][0] ];
        label.center= CGPointMake(ScreenWidth / 2,40+ 20+10);
        label.textAlignment = NSTextAlignmentCenter;
        label.textColor = ColorRGB(51, 51, 51, 1);
        label.tag = 6000;
        label.font = [UIFont systemFontOfSize:12];
        label.adjustsFontSizeToFitWidth = YES;
        [middle addSubview:label];
        
        UILabel *timelabel = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, width+20, 20)];
        timelabel.text = @"截止";
        timelabel.tag = 6001;
        timelabel.center= CGPointMake(label.center.x  , CGRectGetMaxY(label.frame)+15);
        timelabel.textAlignment = NSTextAlignmentCenter;
        timelabel.textColor = ColorRGB(51, 51, 51, 1);
        timelabel.font = [UIFont systemFontOfSize:12];
        timelabel.adjustsFontSizeToFitWidth = YES;
        [middle addSubview:timelabel];
        
        UIImageView *rightImgV = [[UIImageView alloc]initWithImage:[UIImage imageNamed:@"home_kedui"]];
        rightImgV.frame = CGRectMake(0, 0, 50, 50);
        rightImgV.center = CGPointMake(ScreenWidth/4*3+20, leftImgV.center.y);
        [middle addSubview:rightImgV];
        
        JCListLotteryView *listLotteryView = [[JCListLotteryView alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, 40)];
        [middle addSubview:listLotteryView];
        listLotteryView.arrowImage.hidden = NO;
        listLotteryView.titleLabel.text = @"竞足单关";
        
        UIButton *moreBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        moreBtn.frame = CGRectMake(0, 0, ScreenWidth, 40);
        //    moreBtn.center = CGPointMake(magrn*4+width*1.2+width*2+width*0.8/2, per.center.y);
        //    moreBtn.bounds = CGRectMake(0, 0, width, 40);
        [moreBtn addTarget:self action:@selector(goDanguan) forControlEvents:UIControlEventTouchUpInside];
        [middle addSubview:moreBtn];
        for (int i = 0; i<4; i++) {
            UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
            [button setBackgroundImage:[UIImage imageNamed:@"empty－red"] forState:UIControlStateNormal];
            [button setBackgroundImage:[UIImage imageNamed:@"small－red"] forState:UIControlStateSelected];
            [button setTitleColor:allRedColor forState:0];
            [button setTitleColor:[UIColor whiteColor] forState:UIControlStateSelected];
            button.titleLabel.font = [UIFont systemFontOfSize:12];
            button.titleLabel.lineBreakMode = NSLineBreakByWordWrapping;
            button.titleLabel.textAlignment = NSTextAlignmentCenter;
            if (i<3) {
                [button addTarget:self action:@selector(chooseSPF:) forControlEvents:UIControlEventTouchUpInside];
            }
            button.tag = i+101;
            if (i== 0) {
                button.frame = CGRectMake(magrn,  128*(ScreenScale>1?ScreenScale:1), width*1.2, 40);
                [button setBackgroundImage:[UIImage imageNamed:@"big－red"] forState:UIControlStateNormal];
                float pei0 = [peiLvArray[0] floatValue];
                NSString *peiString0 = [NSString stringWithFormat:@"%.2f",pei0];
                NSString *host = [NSString stringWithFormat:@"%@\n胜%@",self.matchDic[@"hostName"],peiString0];
                [button setTitle:host forState:0];
                
            }
            else if (i==1){
                button.frame = CGRectMake(magrn*2+width*1.2,128*(ScreenScale>1?ScreenScale:1), width*0.8, 40);
                float pei1 = [peiLvArray[1] floatValue];
                NSString *peiString1 = [NSString stringWithFormat:@"%.2f",pei1];
                [button setTitle:[NSString stringWithFormat:@"平\n%@",peiString1] forState:0];
            }
            else if (i==2){
                button.frame = CGRectMake(magrn*3+width*2, 128*(ScreenScale>1?ScreenScale:1), width*1.2, 40);
                float pei2 = [peiLvArray[2] floatValue];
                NSString *peiString2 = [NSString stringWithFormat:@"%.2f",pei2];
                NSString *guestName = [NSString stringWithFormat:@"%@\n胜%@",self.matchDic[@"guestName"],peiString2];
                [button setTitle:guestName forState:0];
                [button setBackgroundImage:[UIImage imageNamed:@"big－red"] forState:UIControlStateNormal];
                
                
            }
            else if (i==3){
                button.frame = CGRectMake(magrn*4+width*1.2+width*2, 128*(ScreenScale>1?ScreenScale:1), width*0.8, 40);
                button.selected = YES;
                [button setTitle:@"投注\n50元" forState:0];
                touzhuMoney = 50;
                [button addTarget:self action:@selector(combit) forControlEvents:UIControlEventTouchUpInside];
                touzhuBtn = button;
                
            }
            [middle addSubview:button];
        }}else{
            UILabel *lable =(UILabel *)[middle viewWithTag:6001];
            UILabel *timelable =(UILabel *)[middle viewWithTag:6001];
            timelable.text =  [self dateFomatter:[self.matchDic[@"matchTime"] componentsSeparatedByString:@" "][0] ];
            lable.text = @"截止";
            UIButton *btn0 = (UIButton *)[middle viewWithTag:101];
            UIButton *btn1 = (UIButton *)[middle viewWithTag:102];
            UIButton *btn2 = (UIButton *)[middle viewWithTag:103];
            float pei0 = [peiLvArray[0] floatValue];
            NSString *peiString0 = [NSString stringWithFormat:@"%.2f",pei0];
            NSString *host = [NSString stringWithFormat:@"%@\n胜%@",self.matchDic[@"hostName"],peiString0];
            [btn0 setTitle:host forState:0];
            float pei1 = [peiLvArray[1] floatValue];
            NSString *peiString1 = [NSString stringWithFormat:@"%.2f",pei1];
            [btn1 setTitle:[NSString stringWithFormat:@"平\n%@",peiString1] forState:0];
            float pei2 = [peiLvArray[2] floatValue];
            NSString *peiString2 = [NSString stringWithFormat:@"%.2f",pei2];
            NSString *guestName = [NSString stringWithFormat:@"%@\n胜%@",self.matchDic[@"guestName"],peiString2];
            [btn2 setTitle:guestName forState:0];
            [btn2 setBackgroundImage:[UIImage imageNamed:@"big－red"] forState:UIControlStateNormal];
            middle.frame = frame;
            [headView addSubview:middle];
        }
}
- (NSString *)dateFomatter :(NSString *)date{
    NSDateFormatter *formatter = [[NSDateFormatter alloc]init];
    [formatter setDateFormat:@"yyyy-MM-dd"];
    NSDate *tempDate = [formatter dateFromString:date];
    NSString *lastDate = [formatter stringFromDate:tempDate];
    return lastDate;
}
#pragma mark ==选择玩法
-(void)chooseSPF:(UIButton *)btn{
    if (btn.selected) {
        middleMatchHeight = middleNormalMatchHeight;
    }else{
        middleMatchHeight = middleSelectedMatchHeight;
    }
    [self.lotteryCollectionView reloadData];
    [SPFArray removeAllObjects];
    //    [self removejiaView];
    NSNumber *btnTag = [NSNumber numberWithInteger:btn.tag-100];//从1开始
    peiLv = peiLvArray[btn.tag-101];//选中的赔率
    for (UIButton *view in [btn.superview subviews]) {
        if ([view isKindOfClass:[UIButton class]]) {
            UIButton *tempBtn = view;
            if (btn == tempBtn) {
                tempBtn.selected = !tempBtn.selected;
                if (tempBtn.selected) {
                    [SPFArray addObject:btnTag];
                }
            }
            else{
                if (tempBtn.tag<104) {
                    tempBtn.selected = NO;
                }
            }
        }
    }
    if (btn.selected) {
        //        for (UIButton *view in [btn.superview subviews]) {
        //            if ([view isKindOfClass:[UIButton class]]) {
        //                UIButton *tempBtn = view;
        //                CGRect rect = tempBtn.frame;
        //                rect.origin.y = 128-15;
        //                tempBtn.frame = rect;
        //            }
        //        }
        //        UIView *view = [[UIView alloc]initWithFrame:CGRectMake(20, 100, 30, 30)];
        //        view.backgroundColor = [UIColor redColor];
        //        [middle addSubview:view];
//        CGRect rec =CGRectMake(0.5, CGRectGetMaxY(btn.frame)+5, ScreenWidth-1, 40*ScreenScale);
        if (!jiaView) {
            [self jiaViewWithframe:CGRectMake(0.5, 128*(ScreenScale>1?ScreenScale:1) +50, ScreenWidth-1, 40*ScreenScale)];
        }else{
            jiaView.hidden = NO;
        }
        isChoose = YES;
        
        //固定金额不变切换胜平负时，刷新预测奖金
        NSMutableAttributedString *title = [self getYuCeMoney:touzhuMoney];
        
        [yuceButton setAttributedTitle:title forState:UIControlStateNormal];
     
    }
    else{
        [self removejiaView];
    }
}
#pragma mark == 选择价格
- (void)jiaViewWithframe :(CGRect)frame{
    jiaView = [[UIView alloc]initWithFrame:frame];//价格视图
    jiaView.backgroundColor = allRedColor;
    jiaView.layer.backgroundColor = [UIColor whiteColor].CGColor;
    jiaView.layer.borderColor = allLineColor.CGColor;
    jiaView.layer.borderWidth = 0.5;
    jiaView.layer.cornerRadius = 3;
    [middle addSubview:jiaView];
    NSArray *moneyArr = @[@"10元",@"50元",@"200元",@"500元"];
    CGFloat width = (ScreenWidth-6)/5;
    for (int i=0; i<5; i++) {
        UIButton *money = [UIButton buttonWithType:UIButtonTypeCustom];
        money.frame = CGRectMake((0.9*width+1)*i, 1, 0.9*width, 38*ScreenScale);
        if (i ==4) {
            money.titleEdgeInsets = UIEdgeInsetsMake(13*ScreenScale, 0, 0, 0);
        }
        
        [money addTarget:self action:@selector(chooseTouZhuMoney:) forControlEvents:UIControlEventTouchUpInside];
        money.titleLabel.textAlignment = NSTextAlignmentCenter;
        [money setTitleColor:[UIColor colorWithRed:119/255.0 green:120/255.0 blue:120/255.0 alpha:1] forState:0];
        money.titleLabel.font = [UIFont systemFontOfSize:12];
        money.tag = i;
        if (i<4) {
            if ([moneyArr[i] isEqualToString:[NSString stringWithFormat:@"%d元",touzhuMoney]]) {
                money.selected = YES;
            }
            [money setTitle:moneyArr[i] forState:UIControlStateNormal];
            UIView *line = [[UIView alloc]initWithFrame:CGRectMake(CGRectGetMaxX(money.frame), 2, 0.5, 38*ScreenScale)];
            [money setTitleColor:allRedColor forState:UIControlStateSelected];
            line.backgroundColor = allLineColor;
            [jiaView addSubview:line];
        }
        else{
            money.frame = CGRectMake((0.9*width+1)*i, 1, 1.4*width, 28);
            money.titleLabel.lineBreakMode = NSLineBreakByWordWrapping;
            NSMutableAttributedString *title = [self getYuCeMoney:touzhuMoney==0?50:touzhuMoney];
            [money setAttributedTitle:title forState:UIControlStateNormal];
            yuceButton = money;
        }
        [jiaView addSubview:money];
    }
    
    
}
- (void)chooseTouZhuMoney:(UIButton *)button{
    for (UIButton *btn in [button.superview subviews]) {
        if ([btn isKindOfClass:[UIButton class]]) {
            if (btn==button) {
                button.selected = YES;
            }
            else{
                if (btn.tag<4) {
                    btn.selected = NO;
                }
            }
            
        }
    }
    switch (button.tag) {
        case 0:
            touzhuMoney = 10;
            break;
        case 1:
            touzhuMoney = 50;
            break;
            
        case 2:
            touzhuMoney = 200;
            break;
        case 3:
            touzhuMoney = 500;
            break;
        case 4:
            //            [self removejiaView];
            
        default:
            break;
    }
    NSMutableAttributedString *buttonTitle = [self getYuCeMoney:touzhuMoney];
    NSString * touzhuTitle = [NSString stringWithFormat:@"投注\n%d元",touzhuMoney];
    [yuceButton setAttributedTitle:buttonTitle forState:UIControlStateNormal];
    [touzhuBtn setTitle:touzhuTitle forState:UIControlStateNormal];
}
- (NSMutableAttributedString *)getYuCeMoney:(int)moneyCount
{
    NSString *yuceMoney = [NSString stringWithFormat:@"预测奖金\n%.2f元",[peiLv floatValue]*moneyCount];
    NSMutableAttributedString *title = [[NSMutableAttributedString alloc]initWithString:yuceMoney attributes:@{NSForegroundColorAttributeName:allRedColor}];
    [title addAttributes:@{NSFontAttributeName:[UIFont systemFontOfSize:11],NSForegroundColorAttributeName:[UIColor colorWithRed:119/255.0 green:120/255.0 blue:120/255.0 alpha:1]} range:[yuceMoney rangeOfString:@"预测奖金"]];
    self.prizeRange = [NSString stringWithFormat:@"%.2f",[peiLv floatValue]*moneyCount];
    return title;
}
#pragma mark ===单关购买

-  (void)removejiaView{
    [jiaView setHidden:YES];
    isChoose = NO;
    //    for (UIButton *view in [touzhuBtn.superview subviews]) {
    //        if ([view isKindOfClass:[UIButton class]]) {
    //            UIButton *tempBtn = view;
    //            CGRect rect = tempBtn.frame;
    //            rect.origin.y = middle.frame.origin.y +128;
    //            tempBtn.frame = rect;
    //        }
    //    }
}
- (void)combit{
    //    [self removejiaView];
    NSString *isLogin = [UserDefaults objectForKey:@"isLogin"];
    if ([isLogin intValue] == 0) {
        JCLoginViewController *jcLoginVC = [[JCLoginViewController alloc]init];
        [self presentViewController:jcLoginVC animated:YES completion:nil];
        return;
        
    }
    NSString *urlString = [JCAllUrl schemeIdUrl];
    NSString *clientUserSession = [UserDefaults objectForKey:@"clientUserSession"];
    if (SPFArray.count<=0) {
        [JCPopObject showMessage:@"无法获取投注内容"];
        return;
    }
    //    NSString *issueId = [JCManageSelectSource getIssueId:self.countArray playFlag:self.playFlag dataArray:self.dataArray];
    
    NSString *passStr = @"";
//    NSString *schemeNumber = @"";
    passStr = @"单关";
    
    //    if (self.playFlag == 290) { //比分
    //        schemeNumber = [JCManageSelectSource sureBFBuyLottery:self.selectArray countArray:self.countArray dataArray:self.dataArray];
    //    } else if (self.playFlag == 291) { //半全场
    //        schemeNumber = [JCManageSelectSource sureBQCBuyLottery:self.selectArray countArray:self.countArray dataArray:self.dataArray];
    //    } else if (self.playFlag == 289) { // 总进球
    //        schemeNumber = [JCManageSelectSource sureZJQBuyLottery:self.selectArray countArray:self.countArray dataArray:self.dataArray];
    //    } else if (self.playFlag == 424) {
    //        schemeNumber = [JCManageSelectSource sureHHBuyLottery:self.selectArray countArray:self.countArray dataArray:self.dataArray];
    //    } else {
    //        //        self.playFlag = 424;
    //        //胜平负拼接参数
    //        //        schemeNumber = [JCManageSelectSource sureHHBuyLottery:self.selectArray countArray:self.countArray dataArray:self.dataArray];
    //        //        schemeNumber = [JCManageSelectSource sureHHSPFBuyLottery:self.selectArray countArray:self.countArray dataArray:self.dataArray];
    //        schemeNumber = [JCManageSelectSource sureSpfBuyLottery:self.selectArray countArray:self.countArray dataArray:self.dataArray];
    //    }
    NSDictionary *dict = @{@"clientUserSession": clientUserSession,
                           @"lotteryId" : [NSNumber numberWithInt:10059],
                           @"issueId" : matchIssueId,
                           @"issueCount" : [NSNumber numberWithInt:1],
                           @"schemeNumberUnit" : [NSNumber numberWithInt:1],
                           @"schemeNumber" : [self getHHSPFSchemeNumber],
                           @"buyType" : [NSNumber numberWithInt:1],
                           @"betType" : [NSNumber numberWithInt:288],
                           @"sels" : self.matchDic[@"issue"],
                           @"cutRepeat" : @"false",
                           @"multiple" : [NSNumber numberWithInt:touzhuMoney/2],
                           @"schemeAmount" : [NSNumber numberWithInt:touzhuMoney],
                           @"buyAmount" : [NSNumber numberWithInt:touzhuMoney],
                           @"pass" : passStr};
    
    self.hud = [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    self.hud.label.text = @"正在加载...";
    [JCRequestNetWork postWithUrlString:urlString parameters:dict success:^(id data) {
         [self.hud hideAnimated:YES];
        NSDictionary *dictionary = (NSDictionary *)[NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableLeaves error:nil];
        JCLog(@"dictionary -- %@", dictionary);
        if ([[dictionary objectForKey:@"flag"] intValue] == 1) {
            //            schemeId = [NSString stringWithFormat:@"%@", [dictionary objectForKey:@"schemeId"]];
            self.schemeDictionary = [NSDictionary dictionaryWithDictionary:dictionary];
            //            [self initWithSureBuyView:[NSString stringWithFormat:@"%d", [self countAllMoney:allCountString]] zhuStr:allCountString multiStr:self.multiView.multiText.text];
            [self initWithPopView];
            
        } else{
            [JCPopObject showMessage:[dictionary objectForKey:@"errorMessage"]];
        }
    } failure:^(NSError *error) {
         [self.hud hideAnimated:YES];
        JCLog(@"error -- %@", error);
    } showView:nil];
    
}

///////投注内容
- (NSString *)getHHSPFSchemeNumber
{
    NSMutableString *resultStr = [[NSMutableString alloc] initWithCapacity:1];
    NSMutableString *SPF = [[NSMutableString alloc] initWithCapacity:1];
    [SPFArray sortedArrayUsingSelector:@selector(compare:)];
    for (int j=0; j<[SPFArray count]; j++) {
        if ([[SPFArray objectAtIndex:j] intValue] == 1) {
            [SPF appendString:@"3"];
        }
        else if ([[SPFArray objectAtIndex:j] intValue] == 2) {
            [SPF appendString:@"1"];
        }
        else if ([[SPFArray objectAtIndex:j] intValue] == 3) {
            [SPF appendString:@"0"];
        }
        NSMutableString *matchCodeStr = [NSMutableString stringWithFormat:@"%@",[self.matchDic objectForKey:@"matchCode"]];
        
        NSString *number = self.matchDic[@"teamId"];
        NSString *dantuoFlag = @"flase";
        NSString *hostStr = [NSString stringWithString:[self.matchDic objectForKey:@"hostName"]];
        NSString *guestStr = [NSString stringWithString:[self.matchDic objectForKey:@"guestName"]];
        NSString *rateStr = [NSString stringWithFormat:@"%@%@",matchCodeStr,@"_0"];
        NSString *tempResultStr = [NSString stringWithFormat:@"%@`%@ %@`%@`%@`%@`%@`%@",matchCodeStr,self.matchDic[@"dayOfWeekStr"],number,hostStr,guestStr,rateStr,dantuoFlag,SPF];
        [resultStr appendString:tempResultStr];
        
        
    }
    NSString *tempStr = [NSString stringWithFormat:@"content=%@",resultStr];
    return tempStr;
}
#pragma mark -- 销毁视图
- (void)disMiss:(BOOL)animate
{
    if (!animate) {
        [self.popView removeFromSuperview];
        return;
    }
    
    [UIView animateWithDuration:0.3f animations:^{
        
        self.popView.transform = CGAffineTransformMakeScale(0.1f, 0.1f);
        self.popView.alpha = 0.f;
        
    } completion:^(BOOL finished) {
        
        [_mengBanView removeFromSuperview];
        [self.popView removeFromSuperview];
    }];
}
#pragma mark -- 加载蒙版视图
- (UIView *)mengBanView
{
    if (!_mengBanView) {
        _mengBanView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, ScreenHeight)];
        _mengBanView.backgroundColor = [UIColor blackColor];
        _mengBanView.alpha = 0.6;
    }
    return _mengBanView;
}

#pragma mark -- 加载弹出购买视图
- (void)initWithPopView
{
    [self.view addSubview:self.mengBanView];
    self.popView = [[UIView alloc]initWithFrame:CGRectMake(20, 0, ScreenWidth - 40, 260)];
    self.popView.center = self.view.center;
    self.popView.backgroundColor = [UIColor whiteColor];
    self.popView.layer.cornerRadius = 10;
    self.popView.layer.masksToBounds = YES;
    [self.view addSubview:self.popView];
    
    UIView *diviews = [[UIView alloc]initWithFrame:CGRectMake(0, 0, CGRectGetWidth(self.popView.frame), 110)];
    diviews.backgroundColor = ColorRGB(236, 105, 105, 1);
    diviews.userInteractionEnabled = YES;
    [self.popView addSubview:diviews];
    UILabel *sureLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 5, CGRectGetWidth(self.popView.frame), 30)];
    sureLabel.text = @"确认购买";
    sureLabel.textColor = [UIColor whiteColor];
    sureLabel.font = [UIFont systemFontOfSize:18.f];
    sureLabel.textAlignment = NSTextAlignmentCenter;
    [diviews addSubview:sureLabel];
    
    UILabel *thingLabel = [[UILabel alloc]initWithFrame:CGRectMake(0, 35, CGRectGetWidth(sureLabel.frame), 75)];
    thingLabel.textAlignment = NSTextAlignmentCenter;
    thingLabel.textColor = [UIColor whiteColor];
    thingLabel.font = [UIFont systemFontOfSize:14.f];
    thingLabel.numberOfLines = 0;
    thingLabel.text = @"    *注：提交后不支持撤单，若出现流单，资金将退回现金账户";
    [diviews addSubview:thingLabel];
    
    
    CGFloat height = 70 / 3;
    
    
    for (int i = 0; i < 3; i ++) {
        UILabel *jiLabel = [[UILabel alloc]initWithFrame:CGRectMake(90*ScreenScale, CGRectGetMaxY(diviews.frame) + 10 + i * (height + 5), CGRectGetWidth(diviews.frame) - 40, height)];
        jiLabel.textAlignment = NSTextAlignmentLeft;
        jiLabel.font = [UIFont systemFontOfSize:15.f];
        jiLabel.tag = i;
        if (i == 0) {
            jiLabel.text = [NSString stringWithFormat:@"   购买金额     共%d元", touzhuMoney];
            NSMutableAttributedString * att3 = [[NSMutableAttributedString alloc]initWithString:jiLabel.text attributes:@{NSFontAttributeName:[UIFont systemFontOfSize:15],NSForegroundColorAttributeName:ColorRGB(51, 51, 51, 1)}];
            [att3 addAttributes:@{NSFontAttributeName:[UIFont systemFontOfSize:15],NSForegroundColorAttributeName:allRedColor} range:[jiLabel.text rangeOfString:[NSString stringWithFormat:@"共%d元",touzhuMoney]]];
            jiLabel.attributedText = att3;
            
        }
        else if (i == 1) {
            
            jiLabel.text = [NSString stringWithFormat:@"   购买注数     %d注", 1];
            NSMutableAttributedString * att3 = [[NSMutableAttributedString alloc]initWithString:jiLabel.text attributes:@{NSFontAttributeName:[UIFont systemFontOfSize:15],NSForegroundColorAttributeName:ColorRGB(51, 51, 51, 1)}];
            [att3 addAttributes:@{NSFontAttributeName:[UIFont systemFontOfSize:15],NSForegroundColorAttributeName:allRedColor} range:[jiLabel.text rangeOfString:[NSString stringWithFormat:@"%d注",1]]];
            jiLabel.attributedText = att3;
        }
        else {
            
            jiLabel.text = [NSString stringWithFormat:@"   购买倍数     %d倍", touzhuMoney/2];
            NSMutableAttributedString * att3 = [[NSMutableAttributedString alloc]initWithString:jiLabel.text attributes:@{NSFontAttributeName:[UIFont systemFontOfSize:15],NSForegroundColorAttributeName:ColorRGB(51, 51, 51, 1)}];
            [att3 addAttributes:@{NSFontAttributeName:[UIFont systemFontOfSize:15],NSForegroundColorAttributeName:allRedColor} range:[jiLabel.text rangeOfString:[NSString stringWithFormat:@"%d倍",touzhuMoney/2]]];
            jiLabel.attributedText = att3;
        }
        
        [self.popView addSubview:jiLabel];
    }
    
    UIButton *quxiaoBtn = [UIButton buttonWithType:(UIButtonTypeCustom)];
    quxiaoBtn.frame = CGRectMake(CGRectGetWidth(self.popView.frame) / 2 - 110, CGRectGetHeight(self.popView.frame) - 40, 80, 30);
    [quxiaoBtn setTitle:@"取消" forState:(UIControlStateNormal)];
    [quxiaoBtn setTitleColor:ColorRGB(113, 113, 113, 1) forState:(UIControlStateNormal)];
    quxiaoBtn.layer.cornerRadius = 15;
    quxiaoBtn.layer.masksToBounds = YES;
    quxiaoBtn.layer.borderWidth = 0.5;
    quxiaoBtn.titleLabel.font = [UIFont systemFontOfSize:13.f];
    quxiaoBtn.layer.borderColor = ColorRGB(113, 113, 113, 1).CGColor;
    quxiaoBtn.tag = 1;
    [quxiaoBtn addTarget:self action:@selector(popViewAction:) forControlEvents:(UIControlEventTouchUpInside)];
    [self.popView addSubview:quxiaoBtn];
    
    UIButton *sureBtn = [UIButton buttonWithType:(UIButtonTypeCustom)];
    sureBtn.frame = CGRectMake(CGRectGetWidth(self.popView.frame) / 2 + 30, CGRectGetHeight(self.popView.frame) - 40, 80, 30);
    [sureBtn setTitle:@"确认" forState:(UIControlStateNormal)];
    [sureBtn setTitleColor:allRedColor forState:(UIControlStateNormal)];
    sureBtn.layer.cornerRadius = 15;
    sureBtn.layer.masksToBounds = YES;
    sureBtn.layer.borderWidth = 0.5;
    sureBtn.titleLabel.font = [UIFont systemFontOfSize:13.f];
    sureBtn.layer.borderColor = allRedColor.CGColor;
    sureBtn.tag = 2;
    [sureBtn addTarget:self action:@selector(popViewAction:) forControlEvents:(UIControlEventTouchUpInside)];
    
    [self.popView addSubview:sureBtn];
}
- (void)popViewAction:(UIButton *)sender
{
    switch (sender.tag) {
        case 1:
        {
            [self disMiss:YES];
        }
            break;
        case 2:
        {
            [self requestBuySuccess:[self.schemeDictionary objectForKey:@"schemeId"]];
        }
            break;
            
        default:
            break;
    }
}
- (void)requestBuySuccess:(NSString *)schemesId
{
    NSString *urlString = [JCAllUrl buySucceedUrl];
    NSString *clientUserSession = [UserDefaults objectForKey:@"clientUserSession"];
    NSDictionary *dict = @{@"clientUserSession" : clientUserSession,
                           @"app_schemeId" : schemesId,
                           @"buyMoney" : [NSNumber numberWithInt:touzhuMoney],
                           @"betType" : [NSNumber numberWithInt:288],
                           @"lotteryId" : [NSNumber numberWithInt:10059],
                           @"prizeRange":[NSString stringWithFormat:@"%@~%@",@"0.00",self.prizeRange],//奖金范围
                           };
    [JCRequestNetWork postWithUrlString:urlString parameters:dict success:^(id data) {
        NSDictionary *dictionary = (NSDictionary *)[NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableLeaves error:nil];
        JCLog(@"dictionary -- %@", dictionary);
        if ([[dictionary objectForKey:@"flag"] intValue] == 1) {
             [self.popView removeFromSuperview];
             [self disMiss:YES];
            
//            JCBuySuccessView *buySeccessView = [[JCBuySuccessView alloc]initWithTitle:@"提交成功" andWithMassage:@"购买方案提交成功，祝您购彩愉快" andWithTag:0 andWithButtonTitle:@"返回", nil];
//            [buySeccessView show];
//            
//
//            __block JCBuySuccessView *blockSelf = buySeccessView;
//            buySeccessView.resultIndex = ^(NSInteger titleBtnTag,NSInteger alertViewTag){
//                if (titleBtnTag == 0) {
//                    [blockSelf removeFromSuperview];
//                    //                    [_sureBuyView removeFromSuperview];
//                    [self disMiss:YES];
//                    //                    [self reloadDataAndPopView];
//                }
//            };
//            
            
            JCBuySuccessViewController * vc = [[JCBuySuccessViewController alloc] init];
            vc.lotteryId = @"10059";
            vc.schemeId  =  dictionary[@"schemeId"];
            vc.buyNum = dictionary[@"schemeMoney"];
            vc.balanceNum = dictionary[@"balance"];;
            vc.handselNum = dictionary[@"handsel"];;
            vc.lotteryName = dictionary[@"lotteryName"];;
            vc.multiple = [NSString stringWithFormat:@"%d",touzhuMoney/2];;
            vc.zhuShu = @"1";
            vc.lotteryVCName = @"JCFootBallViewController";
            [self.navigationController pushViewController:vc animated:YES];
#pragma mark --   购买成功后发通知，刷新余额
            [[NSNotificationCenter defaultCenter] postNotificationName:@"BuyLotterySuccess" object: nil];
            
            
        }
    } failure:^(NSError *error) {
        JCLog(@"error -- %@", error);
    } showView:nil];
}
#pragma mark ==跳单关
- (void)goDanguan{
    //    [self removejiaView];
    JCFootBallViewController *footVC = [[JCFootBallViewController alloc]init];
    footVC.lotteryId = @"10059";
    footVC.isShowDanguan = YES;
    [self.navigationController pushViewController:footVC animated:YES];
    
}

#pragma mark - 版本更新检测
- (void)newVersionRequest
{
 
    NSString *url = @"user/app_newVersion.htm?requestType=2";
    NSString *urlString =  [NSString stringWithFormat:@"%@%@",MAINJIYUNURL,url];
    
    [JCRequestNetWork requestWithURLString:urlString parameters:nil type:HttpRequestTypeGet success:^(id responseObject) {
        
        NSDictionary *cdd = [NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingMutableLeaves error:nil];
                JCLog(@"版本更新信息cdd = %@",cdd);
        
        if (cdd !=NULL) {
            NSString *version_content = [cdd objectForKey:@"version_content"];
            //        JCLog(@"version_content = %@",version_content);
            
            //        处理字符串 version_content (后台返回version_content是字符串，里面包含字典信息)
            
            NSData *jsonData = [version_content dataUsingEncoding:NSUTF8StringEncoding];
            NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:jsonData options:NSJSONReadingMutableContainers  error:nil];
            
            NSString *ios_update_url = dic[@"ios_update_url"];
            NSString *IOSnewVersion = dic[@"IOSnewVersion"];
            NSString *ios_forceUpdate =  dic[@"ios_forceUpdate"];
            
            JCLog(@"ios_update_url=%@",ios_update_url);
            JCLog(@"IOSnewVersion=%@",IOSnewVersion);
            JCLog(@"ios_forceUpdate=%@",ios_forceUpdate);
            
            BOOL isneedUpdate  =  [JCTool checkWithNewVersion:dic[@"IOSnewVersion"]];
            
            if (isneedUpdate) {
                
                if ([ios_forceUpdate isEqualToString:@"1"]) {
                    // 强制跟新
                    jxt_showAlertOneButton(@"提示", @"检测到有新版本", @"确定", ^(NSInteger buttonIndex) {
                      JCLog(@"强制跟新");
                        [[UIApplication sharedApplication] openURL:[NSURL URLWithString:ios_update_url]];

                    });

                }else{
                    // 不强制跟新
                    jxt_showAlertTwoButton(@"提示", @"检测到有新版本" , @"取消", ^(NSInteger buttonIndex) {
                        
                    }, @"更新", ^(NSInteger buttonIndex) {
                        JCLog(@"不强制跟新");
                        [[UIApplication sharedApplication] openURL:[NSURL URLWithString:ios_update_url]];
                    });
                }
            }
        }
        
        
        
    } failure:^(NSError *error) {
        
        
    } showView:nil];
}




#pragma mark --  DZNEmptyDataSetSource 、
//空白页显示图片
- (UIImage *)imageForEmptyDataSet:(UIScrollView *)scrollView {
    return [UIImage imageNamed:@"placeholder_No_Network"];
}
//空白页显示标题 返回 NSAttributedString
//- (NSAttributedString *)titleForEmptyDataSet:(UIScrollView *)scrollView {
//    NSString *title = @"网络不给力，请点击重试哦~！";
//    NSDictionary *attributes = @{
//                                 NSFontAttributeName:[UIFont boldSystemFontOfSize:15.0f],
//                                 NSForegroundColorAttributeName:[UIColor darkGrayColor]
//                                 };
//    return [[NSAttributedString alloc] initWithString:title attributes:attributes];
//}
//空白页显示详细描述 返回 NSAttributedString
//- (NSAttributedString *)descriptionForEmptyDataSet:(UIScrollView *)scrollView {
//    NSString *text = @"网络不给力，请点击重试哦~！";
//
//    NSMutableParagraphStyle *paragraph = [NSMutableParagraphStyle new];
//    paragraph.lineBreakMode = NSLineBreakByWordWrapping;
//    paragraph.alignment = NSTextAlignmentCenter;
//
//    NSDictionary *attributes = @{
//                                 NSFontAttributeName:[UIFont systemFontOfSize:15.0f],
//                                 NSForegroundColorAttributeName:[UIColor lightGrayColor],
//                                 NSParagraphStyleAttributeName:paragraph
//                                 };
//
//    return [[NSAttributedString alloc] initWithString:text attributes:attributes];
//}
//空白页显示按钮 返回 NSAttributedString
//- (NSAttributedString *)buttonTitleForEmptyDataSet:(UIScrollView *)scrollView forState:(UIControlState)state {
//
//    NSString *buttonTitle = @"点击重试";
//    UIColor  *textColor = [UIColor cjkt_colorWithHexString:(state == UIControlStateNormal) ? @"007ee5" : @"48a1ea"];
//
//    NSDictionary *attributes = @{
//                                 NSFontAttributeName:[UIFont boldSystemFontOfSize:15.0f],
//                                 NSForegroundColorAttributeName:textColor
//                                 };
//
//
//    return [[NSAttributedString alloc] initWithString:buttonTitle attributes:attributes];
//}
//返回自定义视图
//- (UIView *)customViewForEmptyDataSet:(UIScrollView *)scrollView {
//    UIActivityIndicatorView *activityView = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
//    [activityView startAnimating];
//    return activityView;
//}

#pragma mark -- DZNEmptyDataSetDelegate
//空白页是否显示：默认YES
- (BOOL)emptyDataSetShouldDisplay:(UIScrollView *)scrollView
{
    return YES;
}
//空白页是否响应交互：默认YES ..(如：点击事件)
- (BOOL)emptyDataSetShouldAllowTouch:(UIScrollView *)scrollView
{
    return YES;
}
//空白页是能滚动：默认NO
- (BOOL)emptyDataSetShouldAllowScroll:(UIScrollView *)scrollView
{
    return YES;
}
//空白页上view点击事件
- (void)emptyDataSet:(UIScrollView *)scrollView didTapView:(UIView *)view
{
    JCLog(@"空白页上view点击事件");
    // Do something
    [self.lotteryCollectionView.mj_header beginRefreshing];
}

//空白页上Btn点击事件
- (void)emptyDataSet:(UIScrollView *)scrollView didTapButton:(UIButton *)button
{
    // Do something
    JCLog(@"空白页上Btn点击事件");
}




@end
