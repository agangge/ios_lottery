//
//  JCHomeDetailViewController.m
//  JiCaiLottery
//
//  Created by Dxc_iOS on 2019/4/10.
//  Copyright © 2019 JiCaiLottery. All rights reserved.
//

#import "JCHomeDetailViewController.h"
#import "JCActivityViewController.h"
#import "JCZiXunViewController.h"
#import "JCFootBallViewController.h"

#import "JCBasketBallViewController.h"
#import "JCNineOrFourteenViewController.h"

#import "JCLottertySource.h"

#import "JCZXDetailVC.h"

#import "ZhiBoViewController.h"

#import "JCLoginViewController.h"

#import "JCDanBasketBallViewController.h"

//view
#import "JCTitleButton.h"
#import "JCLotteryNameAndImage.h"
#import "JCListLotteryView.h"
#import "JCHomeHeaderReusableView.h"
#import "JCLotteryCollectionViewCell.h"
#import "JCLotteryActivivityCollectionViewCell.h"
//#import "JCNewkinoViewController2.h"
//mode
#import <SystemConfiguration/CaptiveNetwork.h>
#import "JCHeader.h"

//
#import "AFNetworking.h"
#import "MBProgressHUD.h"

@interface JCHomeDetailViewController ()<UICollectionViewDelegate, UICollectionViewDataSource, SDCycleScrollViewDelegate,JCTitleViewDelegate>
@property (nonatomic, strong)UICollectionView *lotteryCollectionView;
@property (nonatomic, strong)NSMutableArray *hostListArray;
@property (nonatomic, strong)NSMutableArray *shuzilistArray;
@property (nonatomic, strong)NSMutableArray *jingjilistArray;
@property (nonatomic, strong)NSMutableArray *kuaikailistArray;
@property (nonatomic, strong)NSMutableArray *zixunlistArray;
@property (nonatomic, strong)NSMutableArray *bannerArray;
@property (nonatomic, strong)NSDictionary *contentDic;
@property (nonatomic, strong)NSDictionary *matchDic;
@property (nonatomic, strong)NSMutableArray *allListDataArryOfArray;
@property (nonatomic, strong)NSMutableArray *allListDataTitleArray;


@property (nonatomic, strong)MBProgressHUD *hud;

@property (strong, nonatomic) JCTitleView *titleView;
@property (nonatomic, copy)NSString *isBrokerageWhite;//是否是白名单

@end

@implementation JCHomeDetailViewController{
    BOOL _isFootBallMacth;
    NSString *_bifengHtmlUrl;
    UIView *middle;//单关view
    NSArray *peiLvArray;//赔率数组
    NSString *peiLv;//默认赔率
    int touzhuMoney;
    UIButton *touzhuBtn;
    NSMutableArray * SPFArray;//单关玩法选择数组
    BOOL isChoose;//判断是否弹出价格选择view
    UIView *jiaView; //弹出价格选择view
    UIButton *yuceButton;//预测金额按钮
    NSString *matchIssueId;
    NSString *dayOfWeekStr;
    NSInteger isSelectedSingleMatch;
    CGFloat middleMatchHeight;
}

- (void)loadView
{
    self.titleView = [[JCTitleView alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, StatusBarAndNavigationBarHeight) titleLabel:@"全部彩种"];
    self.view = self.titleView;
}
- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    [self.navigationController setNavigationBarHidden:NO];
}
-(void)viewDidDisappear:(BOOL)animated{
    [super viewDidDisappear:animated];
    [self.navigationController setNavigationBarHidden:YES];
}
- (NSDictionary *)contentDic
{
    if (!_contentDic) {
        _contentDic = [NSDictionary dictionary];
    }
    return _contentDic;
}
#pragma mark -- 数组懒加载
- (NSMutableArray *)bannerArray
{
    if (!_bannerArray) {
        _bannerArray = [NSMutableArray array];
    }
    return _bannerArray;
}
- (NSMutableArray *)hostListArray
{
    if (!_hostListArray) {
        _hostListArray = [NSMutableArray array];
    }
    return _hostListArray;
}
- (NSMutableArray *)zixunlistArray
{
    if (!_zixunlistArray) {
        _zixunlistArray = [NSMutableArray array];
    }
    return _zixunlistArray;
}
- (NSMutableArray *)allListDataArryOfArray
{
    if (!_allListDataArryOfArray) {
        _allListDataArryOfArray = [NSMutableArray array];
    }
    return _allListDataArryOfArray;
}
- (NSMutableArray *)allListDataTitleArray
{
    if (!_allListDataTitleArray) {
        _allListDataTitleArray = [NSMutableArray arrayWithObjects:@"热门彩种",@"竞技彩",@"数字彩",@"快开彩",@"资讯", nil];
    }
    return _allListDataTitleArray;
}
- (NSMutableArray *)shuzilistArray
{
    if (!_shuzilistArray) {
        _shuzilistArray = [NSMutableArray array];
    }
    return _shuzilistArray;
}

- (NSMutableArray *)jingjilistArray
{
    if (!_jingjilistArray) {
        _jingjilistArray = [NSMutableArray array];
    }
    return _jingjilistArray;
}

- (NSMutableArray *)kuaikailistArray
{
    if (!_kuaikailistArray) {
        _kuaikailistArray = [NSMutableArray array];
    }
    return _kuaikailistArray;
}



- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.navigationItem.title = @"全部彩种";
    self.view.backgroundColor = allBackGroundColor;
    SPFArray = [NSMutableArray array];
    [self.view addSubview:self.lotteryCollectionView];
    __block JCHomeDetailViewController *blockSelf = self;
    self.lotteryCollectionView.mj_header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
        [blockSelf requestURL];
    }];
    
    [self requestURL];
    
    
}

- (UICollectionView *)lotteryCollectionView
{
    if (!_lotteryCollectionView) {
        UICollectionViewFlowLayout *flowLayout = [[UICollectionViewFlowLayout alloc]init];
        
        _lotteryCollectionView = [[UICollectionView alloc]initWithFrame:CGRectMake(0,StatusBarAndNavigationBarHeight , ScreenWidth, ScreenHeight - TabbarSafeBottomMargin-StatusBarAndNavigationBarHeight) collectionViewLayout:flowLayout];
        
        _lotteryCollectionView.delegate = self;
        _lotteryCollectionView.dataSource = self;
        [_lotteryCollectionView registerClass:[JCLotteryCollectionViewCell class] forCellWithReuseIdentifier:@"cell"];
        [_lotteryCollectionView registerClass:[JCLotteryActivivityCollectionViewCell class] forCellWithReuseIdentifier:@"zxcell"];
        [_lotteryCollectionView registerClass:[UICollectionReusableView class] forSupplementaryViewOfKind:UICollectionElementKindSectionHeader withReuseIdentifier:@"headerView"];
        [_lotteryCollectionView registerClass:[JCHomeHeaderReusableView class] forSupplementaryViewOfKind:UICollectionElementKindSectionHeader withReuseIdentifier:@"JCHomeHeaderReusableView"];
        [_lotteryCollectionView registerClass:[UICollectionReusableView class] forSupplementaryViewOfKind:UICollectionElementKindSectionFooter withReuseIdentifier:@"footerView"];
        flowLayout.footerReferenceSize = CGSizeMake(ScreenWidth, 5);
        _lotteryCollectionView.backgroundColor = allWhiteColor;
        if (@available(iOS 11.0, *)) {
            _lotteryCollectionView.contentInsetAdjustmentBehavior = UIScrollViewContentInsetAdjustmentNever;
            _lotteryCollectionView.contentInset = UIEdgeInsetsMake(0, 0, 0, 0);
            _lotteryCollectionView.scrollIndicatorInsets = _lotteryCollectionView.contentInset;
        }
        self.automaticallyAdjustsScrollViewInsets = false;
    }
    return _lotteryCollectionView;
}



#pragma mark -- UICollectionViewDataSource UICollectionViewDelegate
- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView
{
    return 1;
}
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    
    if (section <=(self.allListDataArryOfArray.count -2) ) {
        if (self.allListDataArryOfArray.count>0) {
            NSMutableArray *arr = self.allListDataArryOfArray[section];
            return arr.count;
            
        }else{
            return 0;
        }
    }else if(section == (self.allListDataArryOfArray.count -1)){
        return self.zixunlistArray.count;
    }else{
        return 0;
    }
    
}



-(CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout referenceSizeForHeaderInSection:(NSInteger)section
{
    
    return CGSizeMake(ScreenWidth, 20);
}


-(UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *identifier = @"cell";
    static NSString *zxidentifier = @"zxcell";
    
    if (indexPath.section<=(self.allListDataArryOfArray.count-2)) {
        
        JCLotteryCollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:identifier forIndexPath:indexPath];
        for (UIView *view in cell.contentView.subviews) {
            [view removeFromSuperview];
        }
        NSMutableArray *arr = self.allListDataArryOfArray[indexPath.section];
        
        
        NSDictionary *dict = [arr objectAtIndex:indexPath.row];
        NSString *lotteryId = [NSString stringWithFormat:@"%@", [dict objectForKey:@"lotteryId"]];
        
        cell.lotteryImage.image = [UIImage imageNamed:[[JCLotteryInfo GetLotteryPic] objectForKey:lotteryId]];
        cell.lotteryLabel.text = [NSString stringWithFormat:@"%@", [[JCLotteryInfo GetLotteryName] objectForKey:lotteryId]];
        
        if ( [self.isBrokerageWhite integerValue] == 1 ) {//白名单显示彩种
            cell.isStop = NO;
            
        }else{
            cell.isStop = ([[dict objectForKey:@"isStop"] integerValue] == 1);
        }
        
        return cell;
    }else{
        JCLotteryActivivityCollectionViewCell *zxcell = [collectionView dequeueReusableCellWithReuseIdentifier:zxidentifier forIndexPath:indexPath];
        for (UIView *view in zxcell.contentView.subviews) {
            [view removeFromSuperview];
        }
        NSMutableArray *arr = self.allListDataArryOfArray[indexPath.section];
        NSDictionary *dict = [arr objectAtIndex:indexPath.row];
        NSDictionary *infoDictionary = [[NSBundle mainBundle] infoDictionary];
        NSString *app_Name = [infoDictionary objectForKey:@"CFBundleDisplayName"];
        
        NSString *au = dict[@"author"];
        zxcell.label2.text =au.length>0?au:app_Name;
        zxcell.label1.text = [dict objectForKey:@"newstitle"];
        NSString *datestr = [dict objectForKey:@"dateTime"];
        NSArray *array = [datestr componentsSeparatedByString:@" "];
        if ([[array objectAtIndex:0] length] >= 5 && [[array objectAtIndex:1] length] >= 5) {
            zxcell.label3.text = [NSString stringWithFormat:@"%@", [[array objectAtIndex:0] substringFromIndex:5]];
        }
        //                actiVityCell.label3.text = dict[@"dateTime"];
        //        int ran = (arc4random() % 10);
        zxcell.label4.text =[NSString stringWithFormat:@"%@阅读", dict[@"scanNums"]];
        [zxcell.imageView1 sd_setImageWithURL:[NSURL URLWithString:dict[@"bigImg"]] placeholderImage:[UIImage imageNamed:@"zixunbanner"]];
        zxcell.backgroundColor = allWhiteColor;
        return zxcell;
    }
    
}
#pragma mark -- 定义每个Item 的大小
- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.section <= (self.allListDataArryOfArray.count -2)) {
        return CGSizeMake((ScreenWidth - 50) / 3, 85);
    }else{
        return CGSizeMake(ScreenWidth, 108);
    }
    
}

#pragma mark -- 定义每个UICollectionView 的 margin
-(UIEdgeInsets)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout insetForSectionAtIndex:(NSInteger)section
{
    if (section <=(self.allListDataArryOfArray.count -2)) {
        return UIEdgeInsetsMake(5, 10, 10, 10);
    }else{
        return UIEdgeInsetsZero;
    }
    
}

#pragma mark -- 设置最小行间距，也就是前一行与后一行的中间最小间隔
- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout minimumLineSpacingForSectionAtIndex:(NSInteger)section {
    if (section<=(self.allListDataArryOfArray.count -2)) {
        return 10;
    }else{
        return 0.001;
    }
    
}

#pragma mark -- 设置最小列间距，也就是左行与右一行的中间最小间隔
- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout minimumInteritemSpacingForSectionAtIndex:(NSInteger)section {
    if (section <=3) {
        return 5;
    }else{
        return 0.001;
    }
    
}
#pragma mark -- 点击 Item
- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    
    NSMutableArray *arr = self.allListDataArryOfArray[indexPath.section];
    NSDictionary *dict = [arr objectAtIndex:indexPath.row];
    
    if ( [self.isBrokerageWhite integerValue] == 1 ) {//白名单显示彩种
        //        [JCPopObject showMessage:@"暂停销售"];
        //        return;
    }else{
        //        不是白名单时 在判断 isStop
        if ([[dict objectForKey:@"isStop"] integerValue] == 1 ) {
            [JCPopObject showMessage:@"暂停销售"];
            return;
        }
    }
    
    NSInteger lotteryId = [[dict objectForKey:@"lotteryId"] integerValue];
    if (lotteryId ==10057) {
       
    }
    else if (lotteryId ==10058||//竞彩篮球
             lotteryId ==10002){//竞篮单关
        
        NSString* lotteryIdStr =  @"10058";
        
        if (lotteryId ==10002) {
            //                basketVC.isShowDanguan = YES;
            JCDanBasketBallViewController *basketVC = [[JCDanBasketBallViewController alloc]init];
            basketVC.lotteryId = lotteryIdStr;
            
            [self.navigationController pushViewController:basketVC animated:YES];
        }else{
            JCBasketBallViewController *basketVC = [[JCBasketBallViewController alloc]init];
            basketVC.lotteryId = lotteryIdStr;
            
            [self.navigationController pushViewController:basketVC animated:YES];
        }
        
    }
    
    else if (lotteryId ==10059||//竞彩足球
             lotteryId ==10001){//竞足单关
        JCFootBallViewController *footVC = [[JCFootBallViewController alloc]init];
        footVC.lotteryId = [NSString stringWithFormat:@"%ld", (long)lotteryId];
        JCLog(@"lotteryId = %@",footVC.lotteryId );
        //    footVC.isShowDanguan = YES;
        if (lotteryId ==10001) {
            footVC.isShowDanguan = YES;
        }
        
        [self.navigationController pushViewController:footVC animated:YES];
    }
    
    else if (lotteryId ==10032){
       
    }else if (lotteryId ==10026){
        
    }else if (lotteryId ==10025){
        
    }else if (lotteryId ==10030){
       
    }
  
    else if (lotteryId ==10039||lotteryId ==10040||lotteryId ==10041||lotteryId ==10042){
        JCNineOrFourteenViewController *nineOrfourVC = [[JCNineOrFourteenViewController alloc]init];
        nineOrfourVC.lotteryId = [NSString stringWithFormat:@"%@", [dict objectForKey:@"lotteryId"]];
        [self.navigationController pushViewController:nineOrfourVC animated:YES];
    }else if (lotteryId == 10046 || lotteryId == 10060|| lotteryId == 10114  || lotteryId == 10062 || lotteryId == 10103 || lotteryId == 10104 || lotteryId == 10066 || lotteryId == 10086 || lotteryId == 10108 || lotteryId == 10109 || lotteryId == 10110|| lotteryId == 10111 || lotteryId == 10115|| lotteryId == 10202){
       
    }
    

    
    else if (lotteryId == 10064||lotteryId == 10201){//快乐十分
        
    }else if (lotteryId == 10038 || lotteryId == 10061 || lotteryId == 10105) {//时时彩
        
    }else if (lotteryId ==10067){
       
    }else if (lotteryId == 10073 || lotteryId == 10085 || lotteryId == 10102 || lotteryId == 10101 || lotteryId == 10065 || lotteryId == 10087 || lotteryId == 10106 || lotteryId == 10107||lotteryId == 10113||lotteryId == 10074||lotteryId == 10203){
        
    }else if (lotteryId == 10084){
        
    }else if (lotteryId == 10089){
       
    }else if (lotteryId ==10033){
       
    }else if (lotteryId ==10028){
        
    }else if (lotteryId ==10035){
        
    }else if (lotteryId ==10029){
        
    }else if (lotteryId ==100241){
        
    }else if (lotteryId ==10027){
       
    }else if (lotteryId ==10024){
       
    }else if (lotteryId ==10088){
        JCLog(@"新3D");
       
    }
    
    
    
}

#pragma mark -- 数据请求
- (void)requestURL
{
    if (![JCRequestNetWork isNetWorkConnectionAvailable]) {
        [self.lotteryCollectionView.mj_header endRefreshing];
        return;
    }
    NSString *urlString = [JCAllUrl lotteryListUrl];
    //    极店版
    NSDictionary *dic = @{
                          @"listType":@"1"
                          };
    self.hud = [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    self.hud.label.text = @"加载中...";
    [JCRequestNetWork postWithUrlString:urlString parameters:dic success:^(id data) {
        [self.hud hideAnimated:YES];
        [self.lotteryCollectionView.mj_header endRefreshing];
        NSDictionary *dictionary = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableLeaves error:nil];
        
        if ([dictionary objectForKey:@"errorMessage"]) {
            [JCPopObject showMessage:dictionary[@"errorMessage"]];
            return ;
        }
        
        self.hostListArray = [[dictionary objectForKey:@"list"] mutableCopy];//list //hotlist
        
        JCLog(@"self.hostListArray.count = %lu",(unsigned long)self.hostListArray.count);
        
        self.jingjilistArray = [[dictionary objectForKey:@"jingjilist"] mutableCopy];
        self.kuaikailistArray = [[dictionary objectForKey:@"kuaikailist"] mutableCopy];
        self.shuzilistArray = [[dictionary objectForKey:@"shuzilist"] mutableCopy];
        self.zixunlistArray =[NSMutableArray arrayWithArray:[dictionary objectForKey:@"indexZxlist"]];
        self.bannerArray = [dictionary objectForKey:@"appBanners"];
        self.contentDic = [dictionary objectForKey:@"content"];
        self.matchDic = [dictionary objectForKey:@"footballMatch"];
        dayOfWeekStr = [dictionary objectForKey:@"dayOfWeekStr"];
        matchIssueId = [dictionary objectForKey:@"issueId"];
        _isFootBallMacth = [[dictionary objectForKey:@"is_footballMatch"] boolValue];
        _bifengHtmlUrl = [dictionary objectForKey:@"h5Url"];
        peiLvArray = [dictionary objectForKey:@"peilv"];
        peiLv = peiLvArray[0];
        
        
        NSArray *allLotteryKeys = [[JCLotteryInfo GetLotteryName] allKeys];
        for (int i = 0; i < self.shuzilistArray.count; i ++) {//插入排列5
            NSDictionary *dict = self.shuzilistArray[i];
            if ([dict[@"lotteryId"] integerValue] == 10024) {
                NSMutableDictionary *dic3 = [[NSMutableDictionary alloc]initWithDictionary:dict];
                [dic3 setValue:@"100241" forKey:@"lotteryId"];
                [self.shuzilistArray insertObject:dic3 atIndex:i + 1];
                break;
            }
        }
        //        极店版 排列5加入 hostListArray
        for (int i = 0; i < self.hostListArray.count; i ++) {//插入排列5
            NSDictionary *dict = self.hostListArray[i];
            if ([dict[@"lotteryId"] integerValue] == 10024) {
                NSMutableDictionary *dic3 = [[NSMutableDictionary alloc]initWithDictionary:dict];
                [dic3 setValue:@"100241" forKey:@"lotteryId"];
                [self.hostListArray insertObject:dic3 atIndex:i + 1];
                break;
            }
        }
        
        //去掉后台返回，本地没有的彩种
        
        for (int i = 0; i < self.hostListArray.count; i ++) {
            NSDictionary *dict = self.hostListArray[i];
            NSString *LottteryidString =[NSString stringWithFormat:@"%@",dict[@"lotteryId"]];
            if (![allLotteryKeys containsObject:LottteryidString]) {
                [self.hostListArray removeObjectAtIndex:i];
                i = i - 1;
            }
        }
        for (int i = 0; i < self.jingjilistArray.count; i ++) {
            NSDictionary *dict = self.jingjilistArray[i];
            NSString *LottteryidString = [NSString stringWithFormat:@"%@",dict[@"lotteryId"]];
            if (![allLotteryKeys containsObject:LottteryidString]) {
                [self.jingjilistArray removeObjectAtIndex:i];
                i = i - 1;
            }
        }
        for (int i = 0; i < self.kuaikailistArray.count; i ++) {
            NSDictionary *dict = self.kuaikailistArray[i];
            NSString *LottteryidString = [NSString stringWithFormat:@"%@",dict[@"lotteryId"]];
            if (![allLotteryKeys containsObject:LottteryidString]) {
                [self.kuaikailistArray removeObjectAtIndex:i];
                i = i - 1;
            }
        }
        for (int i = 0; i < self.shuzilistArray.count; i ++) {
            NSDictionary *dict = self.shuzilistArray[i];
            NSString *LottteryidString = [NSString stringWithFormat:@"%@",dict[@"lotteryId"]];
            if (![allLotteryKeys containsObject:LottteryidString]) {
                [self.shuzilistArray removeObjectAtIndex:i];
                i = i - 1;
            }
        }
        if (self.hostListArray.count > 0) {
            [self.allListDataTitleArray removeAllObjects];
            [self.allListDataArryOfArray removeAllObjects];
        }
        [self AddArrayToAllDataArray:self.hostListArray andHeadTitle:@"热门彩种"];
        [self AddArrayToAllDataArray:self.jingjilistArray andHeadTitle:@"竞技彩"];
        [self AddArrayToAllDataArray:self.kuaikailistArray andHeadTitle:@"快开彩"];
        [self AddArrayToAllDataArray:self.shuzilistArray andHeadTitle:@"数字彩"];
        [self AddArrayToAllDataArray:self.zixunlistArray andHeadTitle:@"资讯"];
        //
        __weak typeof(self)weakSelf = self;
        dispatch_async(dispatch_get_main_queue(), ^{
            [weakSelf.lotteryCollectionView reloadData];
        });
        
        
    } failure:^(NSError *error) {
        [self.hud hideAnimated:YES];
        [self.lotteryCollectionView.mj_header endRefreshing];
        JCLog(@"errpr -- %@", error);
    } showView:nil];
}




- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    
}

- (void)AddArrayToAllDataArray:(NSMutableArray *)arr andHeadTitle:(NSString *)title{
    if ([title isEqualToString:@"资讯"]) {
        [self.allListDataArryOfArray addObject:arr];
        [self.allListDataTitleArray addObject:title];
        
        //        JCLog(@"首页数据数组(资讯)allListDataArryOfArray = %@",self.allListDataArryOfArray);
        
        JCLog(@"首页数据标题数组(资讯)allListDataArryOfArray = %@",self.allListDataTitleArray);
    }else{
        if (arr.count > 0) {
            [self.allListDataArryOfArray addObject:arr];
            [self.allListDataTitleArray addObject:title];
            
            //            JCLog(@"首页数据数组allListDataArryOfArray = %@",self.allListDataArryOfArray);
            
            JCLog(@"首页数据标题数组allListDataArryOfArray = %@",self.allListDataTitleArray);
            
        }}
}
#pragma mark --  DZNEmptyDataSetSource 、
//空白页显示图片
- (UIImage *)imageForEmptyDataSet:(UIScrollView *)scrollView {
    return [UIImage imageNamed:@"placeholder_No_Network"];
}
//空白页显示标题 返回 NSAttributedString
- (NSAttributedString *)titleForEmptyDataSet:(UIScrollView *)scrollView {
    NSString *title = @"网络不给力，请点击重试哦~！";
    NSDictionary *attributes = @{
                                 NSFontAttributeName:[UIFont boldSystemFontOfSize:15.0f],
                                 NSForegroundColorAttributeName:[UIColor darkGrayColor]
                                 };
    return [[NSAttributedString alloc] initWithString:title attributes:attributes];
}
//空白页显示详细描述 返回 NSAttributedString
//- (NSAttributedString *)descriptionForEmptyDataSet:(UIScrollView *)scrollView {
//    NSString *text = @"网络不给力，请点击重试哦~！";
//
//    NSMutableParagraphStyle *paragraph = [NSMutableParagraphStyle new];
//    paragraph.lineBreakMode = NSLineBreakByWordWrapping;
//    paragraph.alignment = NSTextAlignmentCenter;
//
//    NSDictionary *attributes = @{
//                                 NSFontAttributeName:[UIFont systemFontOfSize:15.0f],
//                                 NSForegroundColorAttributeName:[UIColor lightGrayColor],
//                                 NSParagraphStyleAttributeName:paragraph
//                                 };
//
//    return [[NSAttributedString alloc] initWithString:text attributes:attributes];
//}
//空白页显示按钮 返回 NSAttributedString
//- (NSAttributedString *)buttonTitleForEmptyDataSet:(UIScrollView *)scrollView forState:(UIControlState)state {
//
//    NSString *buttonTitle = @"点击重试";
//    UIColor  *textColor = [UIColor cjkt_colorWithHexString:(state == UIControlStateNormal) ? @"007ee5" : @"48a1ea"];
//
//    NSDictionary *attributes = @{
//                                 NSFontAttributeName:[UIFont boldSystemFontOfSize:15.0f],
//                                 NSForegroundColorAttributeName:textColor
//                                 };
//
//
//    return [[NSAttributedString alloc] initWithString:buttonTitle attributes:attributes];
//}
//返回自定义视图
//- (UIView *)customViewForEmptyDataSet:(UIScrollView *)scrollView {
//    UIActivityIndicatorView *activityView = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
//    [activityView startAnimating];
//    return activityView;
//}

#pragma mark -- DZNEmptyDataSetDelegate
//空白页是否显示：默认YES
- (BOOL)emptyDataSetShouldDisplay:(UIScrollView *)scrollView
{
    return YES;
}
//空白页是否响应交互：默认YES ..(如：点击事件)
- (BOOL)emptyDataSetShouldAllowTouch:(UIScrollView *)scrollView
{
    return YES;
}
//空白页是能滚动：默认NO
- (BOOL)emptyDataSetShouldAllowScroll:(UIScrollView *)scrollView
{
    return YES;
}
//空白页上view点击事件
- (void)emptyDataSet:(UIScrollView *)scrollView didTapView:(UIView *)view
{
    JCLog(@"空白页上view点击事件");
    // Do something
    [self.lotteryCollectionView.mj_header beginRefreshing];
}

//空白页上Btn点击事件
- (void)emptyDataSet:(UIScrollView *)scrollView didTapButton:(UIButton *)button
{
    // Do something
    JCLog(@"空白页上Btn点击事件");
}


@end


/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */


