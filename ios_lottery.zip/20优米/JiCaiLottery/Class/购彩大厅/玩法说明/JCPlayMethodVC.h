//
//  JCPlayMethodVC.h
//  JiCaiLottery
//
//  Created by 风外杏林香 on 2017/8/17.
//  Copyright © 2017年 JiCaiLottery. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface JCPlayMethodVC : UIViewController
@property (nonatomic, strong)NSString *titleStr;
@property (nonatomic, assign)NSInteger lotteryId;

@end
