//
//  JCPlayMethodVC.m
//  JiCaiLottery
//
//  Created by 风外杏林香 on 2017/8/17.
//  Copyright © 2017年 JiCaiLottery. All rights reserved.
//

#import "JCPlayMethodVC.h"
#import "JCHeader.h"
@interface JCPlayMethodVC ()<JCTitleViewDelegate>
@property (strong, nonatomic) JCTitleView *titleView;
@property (weak, nonatomic) IBOutlet UILabel *titleLabel;
@property (strong, nonatomic) UIWebView *webView;

@end

@implementation JCPlayMethodVC

- (void)loadView
{
    self.titleView = [[JCTitleView alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, StatusBarAndNavigationBarHeight) titleLabel:@"玩法说明"];
    self.view = self.titleView;
}
- (void)clickPopBtnAction:(UIButton *)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    self.titleView.backgroundColor = allWhiteColor;
    self.titleView.delegate = self;
    self.titleLabel.text = @"玩法说明";
    
    self.webView = [[UIWebView alloc]initWithFrame:CGRectMake(0, StatusBarAndNavigationBarHeight, ScreenWidth, ScreenHeight - StatusBarAndNavigationBarHeight - TabbarSafeBottomMargin)];
    self.webView.backgroundColor = allWhiteColor;
    [self.view addSubview:self.webView];
    
    NSString *htmlPath= [[NSBundle mainBundle]pathForResource:[NSString stringWithFormat:@"%ld", self.lotteryId] ofType:@"html"];
    JCLog(@"htmlPath = %@ \n self.lotteryId = %ld",htmlPath,(long)self.lotteryId);
    NSString *htmlContent = [NSString stringWithContentsOfFile:htmlPath encoding:NSUTF8StringEncoding error:nil];
    NSURL *pathUrl = [NSURL fileURLWithPath:[[NSBundle  mainBundle] bundlePath]];
    [self.webView loadHTMLString:htmlContent baseURL:pathUrl];

}
- (IBAction)popAction:(id)sender {
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
