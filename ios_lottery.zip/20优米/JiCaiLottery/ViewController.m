//
//  ViewController.m
//  JiCaiLottery
//
//  Created by 风外杏林香 on 2017/3/18.
//  Copyright © 2017年 风外杏林香. All rights reserved.
//

#import "ViewController.h"
#import "JCHeader.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
