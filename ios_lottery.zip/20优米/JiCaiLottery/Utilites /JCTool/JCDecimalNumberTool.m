//
//  JCDecimalNumberTool.m
//  JiCaiLottery
//
//  Created by Peng Jun on 2018/7/3.
//  Copyright © 2018年 JiCaiLottery. All rights reserved.
//

#import "JCDecimalNumberTool.h"
//扩展NSDecimalNumber实现高精度金额计算

@implementation JCDecimalNumberTool
+ (float)floatWithDecimaNumber:(double)num{
    return [[self decimalNumber:num] floatValue];
}

+ (double)doubleWithDecimaNumber:(double)num{
    return [[self decimalNumber:num] doubleValue];
}

+ (NSString *)stringWithDecimaNumber:(double)num{
    return [[self decimalNumber:num] stringValue];
}

+ (NSDecimalNumber *)decimalNumber:(double)num{
    NSString *numberString = [NSString stringWithFormat:@"%lf",num];
    return [NSDecimalNumber decimalNumberWithString:numberString];
}













@end
