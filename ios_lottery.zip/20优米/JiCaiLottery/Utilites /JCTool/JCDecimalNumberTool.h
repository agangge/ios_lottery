//
//  JCDecimalNumberTool.h
//  JiCaiLottery
//
//  Created by Peng Jun on 2018/7/3.
//  Copyright © 2018年 JiCaiLottery. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface JCDecimalNumberTool : NSObject

+ (float)floatWithDecimaNumber:(double)num;


+ (double)doubleWithDecimaNumber:(double)num;


+ (NSString *)stringWithDecimaNumber:(double)num;





@end
