//
//  JCLotteryInfo.h
//  JiCaiLottery
//
//  Created by Dxc_iOS on 2019/6/10.
//  Copyright © 2019 JiCaiLottery. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
NS_ASSUME_NONNULL_BEGIN

@interface JCLotteryInfo : NSObject

+(NSDictionary *)GetLotteryPic;

+(NSDictionary *)GetLotteryName;

+(NSDictionary *)GetLotteryImageWithLotteryName;
@end

NS_ASSUME_NONNULL_END
