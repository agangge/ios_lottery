//
//  UIFont+JCFont.m
//  JiCaiLottery
//
//  Created by 风外杏林香 on 2017/4/15.
//  Copyright © 2017年 JiCaiLottery. All rights reserved.
//

#import "UIFont+JCFont.h"
#define ScreenWidth     [UIScreen mainScreen].bounds.size.width
@implementation UIFont (JCFont)
+(UIFont *)systemFontOfSize:(CGFloat)fontSize{
    if (ScreenWidth < 375) {
        fontSize = fontSize * 1;
    }
    else if (ScreenWidth > 375){
        fontSize = fontSize * 1.1;
    }
    UIFont *newFont = [ UIFont preferredFontForTextStyle : UIFontTextStyleBody ];
    
    UIFontDescriptor *ctfFont = newFont.fontDescriptor ;
    
    NSString *fontString = [ctfFont objectForKey : @"NSFontNameAttribute"];
    
    //使用 fontWithName 设置字体
    
    return [UIFont fontWithName:fontString size:fontSize];
}
@end
