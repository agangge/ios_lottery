//
//  UIScrollView+JCTouch.h
//  JiCaiLottery
//
//  Created by Peng Jun on 2017/11/24.
//  Copyright © 2017年 JiCaiLottery. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIScrollView (JCTouch)

@end
