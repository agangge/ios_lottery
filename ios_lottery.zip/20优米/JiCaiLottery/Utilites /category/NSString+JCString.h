//
//  NSString+JCString.h
//  JiCaiLottery
//
//  Created by Peng Jun on 2017/11/16.
//  Copyright © 2017年 JiCaiLottery. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (JCString)
//- (BOOL)isStringContainNumberWith:(NSString *)str;
@end

