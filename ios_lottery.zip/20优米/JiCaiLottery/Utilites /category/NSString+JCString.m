//
//  NSString+JCString.m
//  JiCaiLottery
//
//  Created by Peng Jun on 2017/11/16.
//  Copyright © 2017年 JiCaiLottery. All rights reserved.
//

#import "NSString+JCString.h"

@implementation NSString (JCString)
//- (BOOL)isStringContainNumberWith:(NSString *)str {
//    NSRegularExpression *numberRegular = [NSRegularExpression regularExpressionWithPattern:@"[0-9]" options:NSRegularExpressionCaseInsensitive error:nil];
//    NSInteger count = [numberRegular numberOfMatchesInString:str options:NSMatchingReportProgress range:NSMakeRange(0, str.length)];
//    //count是str中包含[0-9]数字的个数，只要count>0，说明str中包含数字
//    if (count > 0) {
//        return YES;
//    }
//    return NO;
//}
@end
