//
//  JCPopObject.m
//  JiCaiLottery
//
//  Created by 风外杏林香 on 2017/5/4.
//  Copyright © 2017年 JiCaiLottery. All rights reserved.
//

#import "JCPopObject.h"
#import "JCHeader.h"
#import <UIKit/UIKit.h>

@implementation JCPopObject

+ (void)showMessage:(NSString *)message
{
    // 获取window
    UIWindow *window = [UIApplication sharedApplication].keyWindow;
    UIView *showView = [[UIView alloc] init];
    showView.backgroundColor = [UIColor blackColor];
    showView.alpha = 1.0f;
    showView.layer.cornerRadius = 5.0f;
    showView.layer.masksToBounds = YES;
    [window addSubview:showView];
    
    UILabel *label = [[UILabel alloc] init];
    UIFont *font = [UIFont systemFontOfSize:15];
    CGRect labelRect = [message boundingRectWithSize:CGSizeMake(CGFLOAT_MAX, 30) options:NSStringDrawingUsesLineFragmentOrigin attributes:@{NSFontAttributeName: font} context:nil];
    label.frame = CGRectMake(10, 5, ceil(CGRectGetWidth(labelRect)), CGRectGetHeight(labelRect));
    label.text = message;
    label.textColor = [UIColor whiteColor];
    label.font = [UIFont systemFontOfSize:15];
    label.textAlignment = NSTextAlignmentCenter;
    label.backgroundColor = [UIColor clearColor];
    [showView addSubview:label];
    showView.frame = CGRectMake((ScreenWidth - CGRectGetWidth(labelRect) - 20) / 2, ScreenHeight / 2, CGRectGetWidth(labelRect) + 20, CGRectGetHeight(labelRect) + 10);
    [UIView animateWithDuration:1.5 animations:^{
        showView.alpha = 0;
    } completion:^(BOOL finished) {
        [showView removeFromSuperview];
    }];

}


@end
