//
//  JCAllUrl.m
//  JiCaiLottery
//
//  Created by 风外杏林香 on 2017/4/13.
//
//

#import "JCAllUrl.h"
#import "JCHeader.h"
@implementation JCAllUrl

/*
 * 登录URL
 */
+ (NSString *)loginUrl
{
    return [NSString stringWithFormat:@"user/login.htm"];
}


/*
 * 注册方式URL
 */
+ (NSString *)registMethodUrl
{
    return [NSString stringWithFormat:@"user/register_method.htm"];
}

/*
 * 注册获取验证码
 */
+ (NSString *)register_validateCode{//user/register_validateCode.htm
    return [NSString stringWithFormat:@"user/register_validateCode.htm"];
}
/*
 * 注册URL
 */
+ (NSString *)registUrl
{
    return [NSString stringWithFormat:@"user/register.htm"];
}
/*
 *找回密码URL
 */
+ (NSString *)foundPasswordUrl
{
    return [NSString stringWithFormat:@"user/get_forget_password.htm"];
}
/*
 * 个人中心
 */
+ (NSString *)userCenterUrl
{
    return [NSString stringWithFormat:@"user/query_balance.htm"];
}
/*
 * 个人信息
 */
+ (NSString *)userInfoUrl
{
    return [NSString stringWithFormat:@"user/my_info.htm"];
}
/*
 * 上传头像
 */
+ (NSString *)uploadAvatar
{
    return [NSString stringWithFormat:@"user/uploadAvatar.htm"];
}
/*
 * 绑定身份证
 */
+ (NSString *)bangDingBankCard
{
    return [NSString stringWithFormat:@"user/bind_identify_name.htm"];
}
/*
 * 绑定手机号
 */
+ (NSString *)bangDingPhoneNumber
{
    return [NSString stringWithFormat:@"user/bind_mobile_validate.htm"];
}
/*
 * 手机验证码
 */
+ (NSString *)phoneNumberCode
{
    return [NSString stringWithFormat:@"user/bind_mobile.htm"];
}
/*
 * 支付接口
 */
+ (NSString *)shouMiPayUrl
{
    return [NSString stringWithFormat:@"user/shoumi_app.htm"];
}
/*
 * 提款接口
 */
+ (NSString *)takeMoneyUrl
{
    return [NSString stringWithFormat:@"user/app_withdraw.htm"];
}
/*
 * 修改密码接口
 */
+ (NSString *)changePassword
{
    return [NSString stringWithFormat:@"user/update_password.htm"];
}
/*
 * 意见反馈
 */
+ (NSString *)handleIdeaUrl
{
    return [NSString stringWithFormat:@"user/leave_word.htm"];
}
/*
 * 帮助中心
 */
+ (NSString *)helpCenterUrl
{
    return [NSString stringWithFormat:@"news/help.htm"];
}
/*
 * 绑定姓名、身份证
 */
+ (NSString *)nameAndCardUrl
{
    return [NSString stringWithFormat:@"user/bind_identify_name.htm"];
}
/*
 * 绑定银行卡时候获取手机验证码
 */
+ (NSString *)bankCodeUrl
{
    return [NSString stringWithFormat:@"user/send_validate_modify_bank_info.htm"];
}
/*
 * 绑定银行卡
 */
+ (NSString *)bindingBankUrl
{
    return [NSString stringWithFormat:@"user/bind_bank_card.htm"];
}
/*
 * 资金明细全部
 */
+ (NSString *)capitalUrl
{
    return [NSString stringWithFormat:@"user/capital_detail.htm"];
}
/*
 * 资金明细提款(也是被🐩日了。。。)
 */
+ (NSString *)capitalTakeMoneyUrl
{
    return [NSString stringWithFormat:@"user/capitalInOut_detail.htm"];
}
/*
 * 方案列表
 */
+ (NSString *)schemeHistoryUrl
{
    return [NSString stringWithFormat:@"lottery/my_scheme.htm"];
}
/*
 * 方案详情
 */
+ (NSString *)schemeDetailUrl
{
    return [NSString stringWithFormat:@"lottery/scheme_detail.htm"];
}
/*
 * 合买列表
 */
+ (NSString *)heMaiListUrl
{
    return [NSString stringWithFormat:@"lottery/scheme_hm.htm"];
}
/*
 * 参加合买
 */
+ (NSString *)joinHeMaiUrl
{
    return [NSString stringWithFormat:@"lottery/app_join_buy.htm"];
}
#pragma mark 跟单
/*
 * 跟单大厅
 */
+ (NSString *)gendanCenterUrl
{
    return [NSString stringWithFormat:@"/lottery/copy_list.htm"];
}
/*
 * 跟单大厅新的2018.6
 */
+ (NSString *)gendanGaibanCenterUrl
{
    return [NSString stringWithFormat:@"/lottery/opt_copy_list.htm"];
}

/*
 * 跟单关注
 */
+ (NSString *)gendanCare_personUrl
{
    return [NSString stringWithFormat:@"/lottery/care_person.htm"];
}
/*
 * 取消关注
 */
+ (NSString *)gendanCancel_care_personUrl
{
    return [NSString stringWithFormat:@"/lottery/cancel_care_person.htm"];
}
/*
 * 复制跟单
 */
+ (NSString *)gendanCopyUrl
{
    return [NSString stringWithFormat:@"/lottery/simple_copy.htm"];
}
/*
 * 去跟单
 */
+ (NSString *)gendanTodoCopyUrl
{
    return [NSString stringWithFormat:@"/lottery/do_copy.htm"];
}
/*
 * 跟单列表
 */
+ (NSString *)gendanListUrl
{
    return [NSString stringWithFormat:@"/lottery/copy_buy_list.htm"];
}
/*
 * 跟单编辑
 */
+ (NSString *)gendanEditPageUrl
{
    return [NSString stringWithFormat:@"/lottery/copy_publish.htm"];
}
/*
 * 跟单发布到大厅
 */
+ (NSString *)gendanToPubilishUrl
{
    return [NSString stringWithFormat:@"/lottery/do_copy_publish.htm"];
}
/*
 * 跟单大厅搜索2018.9
 */
+ (NSString *)gendansearchrUrl
{
    return [NSString stringWithFormat:@"/user/getUserId.htm"];
}

#pragma mark --
/*
 * 首页彩种列表
 */
+ (NSString *)lotteryListUrl
{
    return [NSString stringWithFormat:@"lottery/lottery_list_hot.htm"];
}
/*
 * 活动列表
 */
+ (NSString *)activityUrl
{
    return [NSString stringWithFormat:@"activity/newsList.htm"];
}
/*
 * 活动详情
 */
+ (NSString *)activityDetailUrl
{
    return [NSString stringWithFormat:@"activity/contentDetail.htm"];
}
/*
 * 资讯列表
 */
+ (NSString *)ziXunListUrl
{
    return [NSString stringWithFormat:@"activity/newsList.htm"];
}
/*
 * 北京单场
 */
+ (NSString *)bjdcUrl
{
    return [NSString stringWithFormat:@"lottery/bjdc.htm"];
}
/*
 * 竞彩足球
 */
+ (NSString *)jczqUrl
{
    return [NSString stringWithFormat:@"lottery/spf.htm"];
}
/*
 * 竞彩篮球
 */
+ (NSString *)jclqUrl
{
    return [NSString stringWithFormat:@"lottery/basketball.htm"];
}
/*
 * 世界杯列表
 */
+ (NSString *)gjjcUrl
{
    return [NSString stringWithFormat:@"lottery/champion_list.htm"];
}
/*
 * 提交购彩获取schemeId
 */
+ (NSString *)schemeIdUrl
{
    return [NSString stringWithFormat:@"lottery/buy_lottery.htm"];
}
/*
 * 购彩成功接口
 */
+ (NSString *)buySucceedUrl
{
    return [NSString stringWithFormat:@"lottery/app_buy_lottery.htm"];
}
/*
 * 胜负彩请求接口
 */
+ (NSString *)winLoseUrl
{
    return [NSString stringWithFormat:@"lottery/"];
}
/*
 * 数字彩获取奖期
 */
+ (NSString *)numberIssueUrl
{
    return [NSString stringWithFormat:@"lottery/query_cur_issue.htm"];
}
/*
 * 数字彩头部开奖
 */
+ (NSString *)numberKaiJiangUrl
{
    return [NSString stringWithFormat:@"lottery/issue_notify.htm"];
}
/*
 * 彩票圈
 */
+ (NSString *)friendUrl
{
    return [NSString stringWithFormat:@"lottery/lottery_share_list.htm"];
}
/*
 * 分享图片
 */
+ (NSString *)shareUrl
{
    return [NSString stringWithFormat:@"lottery/lottery_share_share.htm"];
}

/*
 * 彩票圈点赞
 */
+ (NSString *)likeUrl
{
    return [NSString stringWithFormat:@"lottery/lottery_share_like.htm"];
}
/*
 * 彩票圈评论
 */
+ (NSString *)commentUrl
{
    return [NSString stringWithFormat:@"lottery/lottery_share_comment.htm"];
}
/*
 * 走势图
 */
+ (NSString *)zouSTUrl
{
    return [NSString stringWithFormat:@"lottery/trend_chart.htm"];
}
/*
 * 资讯详情
 */
+ (NSString *)zxxqUrl
{
    return [NSString stringWithFormat:@"activity/contentDetail.htm"];
}
/*
 * 资讯评论
 */
+ (NSString *)zxxqplUrl
{
    return [NSString stringWithFormat:@"activity/newsComment.htm"];
}
/*
 * 资讯点赞
 */
+ (NSString *)zxxqdzUrl
{
    return [NSString stringWithFormat:@"activity/newsZan.htm"];
}
/*
 * 资讯评论列表
 */
+ (NSString *)zxxqCommentUrl
{
    return [NSString stringWithFormat:@"activity/newsCommentList.htm"];
}
/*
 * 认购列表
 */
+ (NSString *)hmRenGouListUrl
{
    return [NSString stringWithFormat:@"lottery/join_buy_list.htm"];
}

+ (NSString *)kjDetailTradionnalListUrl{
    
    return [NSString stringWithFormat:@"lottery/issue_notify_ctzq.htm"];
}

/*
 * 竞彩篮球开奖详情
 */
+ (NSString *)basketballUrl
{
    return [NSString stringWithFormat:@"lottery/issue_notify_jclq.htm"];
}
/*
 * 竞彩足球开奖详情
 */
+ (NSString *)footballUrl
{
    return [NSString stringWithFormat:@"lottery/issue_notify_jczq.htm"];
}
/*
 * 北京单场开奖详情
 */
+ (NSString *)beijingdanUrl
{
    return [NSString stringWithFormat:@"lottery/issue_notify_bjdc.htm"];
}
/*
 * 查询奖期接口
 */
+ (NSString *)findIssueUrl
{
    return [NSString stringWithFormat:@"lottery/issue_notify_issue.htm"];
}
/*
 * 支付通道列表
 */
+ (NSString *)payListUrl
{
    return [NSString stringWithFormat:@"user/payment.htm"];
}
/*
 * 热门大神
 */
+ (NSString *)gendanHotDasheng{
    return [NSString stringWithFormat:@"/lottery/hot_recommendor.htm"];
}
/*
 * 大神主页信息
 */
+ (NSString *)gendanDashengInfo{
    return [NSString stringWithFormat:@"/lottery/recommendor_home.htm"];
}
/*
 * 大神主页列表
 */
+ (NSString *)gendanDashengHomeList{
    return [NSString stringWithFormat:@"/lottery/recommendor_scheme.htm"];
}
/*
 *跟单排行
 */
+ (NSString *)gendanRank{
    return [NSString stringWithFormat:@"/lottery/copy_rank.htm"];
}
/*
 *版本检测
 */
+ (NSString *)newVersionCheck{
    return [NSString stringWithFormat:@"user/app_newVersion.htm"];
}
/*
 * 支付通道
 */
+ (NSString *)payLoadUrl
{
    return [NSString stringWithFormat:@"user/chengyipay.htm"];
}
@end
