//
//  JCWebViewController.m
//  JiCaiLottery
//
//  Created by 风外杏林香 on 2017/6/17.
//  Copyright © 2017年 JiCaiLottery. All rights reserved.
//

#import "JCWebViewController.h"
#import "JCHeader.h"
@interface JCWebViewController ()<UITableViewDelegate, UITableViewDataSource, UIWebViewDelegate>

@property (nonatomic, strong)NSDictionary *dataDictionary;

@property (nonatomic, strong)UITableView *dataTableView;

@property (nonatomic, strong)UIWebView *webView;

@end

@implementation JCWebViewController

- (UIWebView *)webView
{
    if (!_webView) {
        _webView = [[UIWebView alloc]initWithFrame:CGRectMake(0, 64, ScreenWidth, 100)];
        _webView.delegate = self;
    }
    return _webView;
}

- (NSDictionary *)dataDictionary
{
    if (!_dataDictionary) {
        _dataDictionary = [NSDictionary dictionary];
    }
    return _dataDictionary;
}

- (UITableView *)dataTableView
{
    if (!_dataTableView) {
        _dataTableView = [[UITableView alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, ScreenHeight) style:(UITableViewStyleGrouped)];
        _dataTableView.delegate = self;
        _dataTableView.dataSource = self;
    }
    return _dataTableView;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    [self requestURL];
    
    [self.view addSubview:self.dataTableView];

    
    
}

- (void)webViewDidFinishLoad:(UIWebView *)webView
{
    self.webView.height = self.webView.scrollView.contentSize.height;
    [self.dataTableView reloadData];
}


- (void)requestURL
{
//    NSString *urlString = @"http://c.m.163.com/nc/article/CN5A0A3E0001875P/full.html";
    NSString *urlString = @"http://client.jicai500.com/activity/contentDetail.htm?id=29";
    [JCRequestNetWork requestWithURLString:urlString parameters:nil type:(HttpRequestTypeGet) success:^(id responseObject) {
        NSDictionary *dict = (NSDictionary *)[NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingMutableLeaves error:nil];
//        self.dataDictionary = [NSDictionary dictionaryWithDictionary:[dict objectForKey:@"CN5A0A3E0001875P"]];
        self.dataDictionary = [NSDictionary dictionaryWithDictionary:[dict objectForKey:@"content"]];
        JCLog(@"dict -- %ld", self.dataDictionary.count);

        
        
        [self.dataTableView reloadData];
        
        NSString *str = [self getHtmlString];
        
        [self.webView loadHTMLString:str baseURL:nil];
        
//        [self.view addSubview:self.webView];
        
    } failure:^(NSError *error) {
        JCLog(@"error -- %@", error);
    } showView:nil];
    
    
}


- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 2;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 3;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
    if (cell == nil) {
        cell = [[UITableViewCell alloc]initWithStyle:(UITableViewCellStyleDefault) reuseIdentifier:@"cell"];
    }
    
    
    return cell;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    if (section == 0) {
         return self.webView;
    } else {
        return [UIView new];
    }
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    if (section == 0) {
        return self.webView.height;
    } else {
        return 10;
    }
}



- (NSString *)getBodyString
{
    
    NSMutableString *body = [NSMutableString string];
    
    if (self.dataDictionary.count != 0) {
        [body appendFormat:@"<div class=\"title\">%@</div>",[self.dataDictionary objectForKey:@"title"]];
        [body appendFormat:@"<div class=\"time\">%@</div>",[self.dataDictionary objectForKey:@"ptime"]];
        
//        NSString *str = [NSString stringWithFormat:@"%@", [self.dataDictionary objectForKey:@"body"]];
        
        [body appendString:[self.dataDictionary objectForKey:@"content"]];
        
//        NSMutableArray *imageArr = [self.dataDictionary objectForKey:@"img"];
//        for (int i = 0; i < imageArr.count; i ++) {
//            NSDictionary *dict = [imageArr objectAtIndex:i];
//            NSMutableString *imgHtml = [NSMutableString string];
//            // 设置img的div
//            [imgHtml appendString:@"<div class=\"img-parent\">"];
//            NSArray *pixel = [[dict objectForKey:@"pixel"] componentsSeparatedByString:@"*"];
//            CGFloat width = [[pixel firstObject]floatValue];
//            CGFloat height = [[pixel lastObject]floatValue];
//            // 判断是否超过最大宽度
//            CGFloat maxWidth = [UIScreen mainScreen].bounds.size.width * 0.96;
//            if (width > maxWidth) {
//                height = maxWidth / width * height;
//                width = maxWidth;
//            }
//            
//            NSString *onload = @"this.onclick = function() {"
//            "  window.location.href = 'sx://github.com/dsxNiubility?src=' +this.src+'&top=' + this.getBoundingClientRect().top + '&whscale=' + this.clientWidth/this.clientHeight ;"
//            "};";
//            [imgHtml appendFormat:@"<img onload=\"%@\" width=\"%f\" height=\"%f\" src=\"%@\">",onload,width,height,[dict objectForKey:@"src"]];
//            [imgHtml appendString:@"</div>"];
//            [body replaceOccurrencesOfString:[dict objectForKey:@"ref"] withString:imgHtml options:NSCaseInsensitiveSearch range:NSMakeRange(0, body.length)];
//        }

    }
    
    return body;
}

- (NSString *)getHtmlString
{
    NSMutableString *html = [NSMutableString string];
    [html appendString:@"<html>"];
    [html appendString:@"<head>"];
    [html appendFormat:@"<link rel=\"stylesheet\" href=\"%@\">",[[NSBundle mainBundle] URLForResource:@"SXDetails.css" withExtension:nil]];
    [html appendString:@"</head>"];
    
    [html appendString:@"<body style=\"background:#f6f6f6\">"];
    [html appendString:[self getBodyString]];
    [html appendString:@"</body>"];
    
    [html appendString:@"</html>"];
    
    
    return html;
}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
