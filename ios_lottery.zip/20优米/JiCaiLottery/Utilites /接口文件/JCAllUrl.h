//
//  JCAllUrl.h
//  JiCaiLottery
//
//  Created by 风外杏林香 on 2017/4/13.
//
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
@interface JCAllUrl : NSObject
/*
 * 登录URL
 */
+ (NSString *)loginUrl;

/*
 * 注册方式URL
 */
+ (NSString *)registMethodUrl;


/*
 * 注册获取验证码
 */
+ (NSString *)register_validateCode;
/*
 * 注册URL
 */
+ (NSString *)registUrl;
/*
 * 找回密码URL
 */
+ (NSString *)foundPasswordUrl;
/*
 * 个人中心
 */
+ (NSString *)userCenterUrl;
/*
 * 个人信息
 */
+ (NSString *)userInfoUrl;
/*
 * 上传头像
 */
+ (NSString *)uploadAvatar;
/*
 * 绑定身份证
 */
+ (NSString *)bangDingBankCard;
/*
 * 绑定手机号
 */
+ (NSString *)bangDingPhoneNumber;
/*
 * 手机验证码
 */
+ (NSString *)phoneNumberCode;
/*
 * 支付接口
 */
+ (NSString *)shouMiPayUrl;
/*
 * 提款接口
 */
+ (NSString *)takeMoneyUrl;
/*
 * 修改密码接口
 */
+ (NSString *)changePassword;
/*
 * 意见反馈
 */
+ (NSString *)handleIdeaUrl;
/*
 * 帮助中心
 */
+ (NSString *)helpCenterUrl;
/*
 * 绑定姓名、身份证
 */
+ (NSString *)nameAndCardUrl;
/*
 * 绑定银行卡时候获取手机验证码
 */
+ (NSString *)bankCodeUrl;
/*
 * 绑定银行卡
 */
+ (NSString *)bindingBankUrl;
/*
 * 资金明细全部
 */
+ (NSString *)capitalUrl;
/*
 * 资金明细提款(也是被🐩日了。。。)
 */
+ (NSString *)capitalTakeMoneyUrl;
/*
 * 方案列表
 */
+ (NSString *)schemeHistoryUrl;
/*
 * 方案详情
 */
+ (NSString *)schemeDetailUrl;
/*
 * 合买列表
 */
+ (NSString *)heMaiListUrl;
/*
 * 参加合买
 */
+ (NSString *)joinHeMaiUrl;
/*
 * 跟单大厅
 */
+ (NSString *)gendanCenterUrl;
/*
 * 跟单关注
 */
+ (NSString *)gendanCare_personUrl;
/*
 * 取消关注
 */
+ (NSString *)gendanCancel_care_personUrl;
/*
 * 复制跟单
 */
+ (NSString *)gendanCopyUrl;
/*
 * 去跟单
 */
+ (NSString *)gendanTodoCopyUrl;
/*
 * 跟单列表
 */
+ (NSString *)gendanListUrl;
/*
 * 跟单编辑
 */
+ (NSString *)gendanEditPageUrl;
/*
 * 跟单发布到大厅
 */

+ (NSString *)gendanToPubilishUrl;

/*
 * 跟单大厅搜索2018.9
 */
+ (NSString *)gendansearchrUrl;

/*
 * 首页彩种列表
 */
+ (NSString *)lotteryListUrl;
/*
 * 活动列表
 */
+ (NSString *)activityUrl;
/*
 * 活动详情
 */
+ (NSString *)activityDetailUrl;
/*
 * 资讯列表
 */
+ (NSString *)ziXunListUrl;
/*
 * 北京单场
 */
+ (NSString *)bjdcUrl;
/*
 * 竞彩足球
 */
+ (NSString *)jczqUrl;
/*
 * 竞彩篮球
 */
+ (NSString *)jclqUrl;
/*
 * 世界杯列表
 */
+ (NSString *)gjjcUrl;
/*
 * 提交购彩获取schemeId
 */
+ (NSString *)schemeIdUrl;
/*
 * 购彩成功接口
 */
+ (NSString *)buySucceedUrl;
/*
 * 胜负彩请求接口
 */
+ (NSString *)winLoseUrl;
/*
 * 数字彩获取奖期
 */
+ (NSString *)numberIssueUrl;
/*
 * 数字彩头部开奖
 */
+ (NSString *)numberKaiJiangUrl;
/*
 * 彩票圈
 */
+ (NSString *)friendUrl;
/*
 * 分享图片
 */
+ (NSString *)shareUrl;
/*
 * 彩票圈点赞
 */
+ (NSString *)likeUrl;
/*
 * 彩票圈评论
 */
+ (NSString *)commentUrl;
/*
 * 走势图
 */
+ (NSString *)zouSTUrl;
/*
 * 资讯详情
 */
+ (NSString *)zxxqUrl;
/*
 * 资讯评论
 */
+ (NSString *)zxxqplUrl;
/*
 * 资讯点赞
 */
+ (NSString *)zxxqdzUrl;
/*
 * 资讯评论列表
 */
+ (NSString *)zxxqCommentUrl;
/*
 * 认购列表
 */
+ (NSString *)hmRenGouListUrl;
/*
 * 竞彩篮球开奖详情
 */
+ (NSString *)basketballUrl;
/*
 * 竞彩足球开奖详情
 */
+ (NSString *)footballUrl;
/*
 * 北京单场开奖详情
 */
+ (NSString *)beijingdanUrl;
/*
 * 查询奖期接口
 */
+ (NSString *)findIssueUrl;


/*
 * 开奖中心 传统足球开奖列表
 */
+ (NSString *)kjDetailTradionnalListUrl;
/*
 * 支付通道列表
 */
+ (NSString *)payListUrl;

/*
 * 热门大神
 */
+ (NSString *)gendanHotDasheng;
/*
 * 大神主页信息
 */
+ (NSString *)gendanDashengInfo;
/*
 * 大神主页列表
 */
+ (NSString *)gendanDashengHomeList;
/*
 *跟单排行
 */
+ (NSString *)gendanRank;
/*
 * 跟单大厅新的2018.6
 */
+ (NSString *)gendanGaibanCenterUrl;
/*
 *版本检测
 */
+ (NSString *)newVersionCheck;
/*
 * 支付通道
 */
+ (NSString *)payLoadUrl;
@end
