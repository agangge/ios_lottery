//
//  JCSetTagObject.h
//  JiCaiLottery
//
//  Created by 风外杏林香 on 2017/5/22.
//  Copyright © 2017年 JiCaiLottery. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface JCSetTagObject : NSObject

/*
 * 北京单场、竞彩足球半全场、比分cell buttonTag
 */
+ (NSInteger)setBQCTag:(NSInteger)section indexPathRow:(NSInteger)row;

/*
 * 北京单场半全场点击之后每个buttonTag
 */
+ (NSInteger)setBQCspfTag:(NSInteger)section indexPathRow:(NSInteger)row spf:(NSInteger)curspf;

/*
 * 竞彩足球cell 更多button tag
 */
+ (NSInteger)setHHTag:(NSInteger)section indexPathRow:(NSInteger)row;

/*
 * 设置选中之后button title
 */
+ (NSMutableString *)setTitleString:(NSMutableArray *)array titleArray:(NSArray *)titleArray;

/*
 *  设置cell上面button选中状态
 */
+ (BOOL)isSelectedButton:(NSInteger)tag dictionary:(NSMutableDictionary *)dict;

/*
 * 竞彩足球混合过关buttonTag
 */
+ (NSInteger)setHHButtonTag:(NSInteger)section indexPathRow:(NSInteger)row;

/*
 * 设置胜平负button选中状态
 */
+ (BOOL)setSpfButtonSelected:(NSInteger)tag dataArray:(NSMutableArray *)selectArray;

/*
 * 设置混合投注胜分差选中状态
 */
+ (BOOL)isBasketSelectedButton:(NSInteger)tag dictionary:(NSMutableDictionary *)dict;

@end
