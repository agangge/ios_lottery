//
//  JCPopView.h
//  JiCaiLottery
//
//  Created by 风外杏林香 on 2017/4/18.
//  Copyright © 2017年 JiCaiLottery. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface JCPopView : UIView

@property (nonatomic, strong)UILabel *titleLabel;

- (instancetype)initWithFrame:(CGRect)frame
                   titleLabel:(NSString *)titleText;

- (void)showView;

@end
