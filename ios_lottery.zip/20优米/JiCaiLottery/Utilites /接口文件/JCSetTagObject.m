//
//  JCSetTagObject.m
//  JiCaiLottery
//
//  Created by 风外杏林香 on 2017/5/22.
//  Copyright © 2017年 JiCaiLottery. All rights reserved.
//

#import "JCSetTagObject.h"

@implementation JCSetTagObject

/*
 * 北京单场半全场buttonTag
 */
+ (NSInteger)setBQCTag:(NSInteger)section indexPathRow:(NSInteger)row
{
    return 100000 * section + row * 100;
}

/*
 *北京单场半全场点击之后每个buttonTag
 */
+ (NSInteger)setBQCspfTag:(NSInteger)section indexPathRow:(NSInteger)row spf:(NSInteger)curspf
{
    return 100000 * section + row * 100 + curspf;
}

/*
 * 竞彩足球cell 更多button tag
 */
+ (NSInteger)setHHTag:(NSInteger)section indexPathRow:(NSInteger)row
{
    return section * 100000 + 100 * row;
}
#pragma mark -- 设置选中之后button title
+ (NSMutableString *)setTitleString:(NSMutableArray *)array titleArray:(NSArray *)titleArray
{
    NSMutableString *selectText = [[NSMutableString alloc]initWithCapacity:1];
    for (int i = 0; i < array.count; i ++) {
        int k = [[array objectAtIndex:i] intValue] % 100;
        NSString *str = [NSString stringWithFormat:@"%@  ",[titleArray objectAtIndex:k - 1]];
        [selectText appendString:str];
    }
    return selectText;
}
/*
 *  设置cell上面button选中状态
 */
+ (BOOL)isSelectedButton:(NSInteger)tag dictionary:(NSMutableDictionary *)dict
{
    NSArray *alllkey = [dict allKeys];
    
    for (int i = 0; i < [alllkey count]; i++) {
        if ([[alllkey objectAtIndex:i] intValue] == tag) {
            return YES;
        }
    }
    return NO;
}

/*
 * 竞彩足球混合过关buttonTag
 */
+ (NSInteger)setHHButtonTag:(NSInteger)section indexPathRow:(NSInteger)row
{
    return section * 100000 + row * 100;
}

/*
 * 设置胜平负button选中状态
 */
+ (BOOL)setSpfButtonSelected:(NSInteger)tag dataArray:(NSMutableArray *)selectArray
{
    for (int i = 0; i < [selectArray count]; i ++) {
        if ([[selectArray objectAtIndex:i] intValue] == tag) {
            return YES;
        }
    }
    return NO;
}
/*
 * 设置混合投注胜分差选中状态
 */
+ (BOOL)isBasketSelectedButton:(NSInteger)tag dictionary:(NSMutableDictionary *)dict
{
    NSArray *alllkey = [dict allKeys];
    
    for (int i = 0; i < [alllkey count]; i++) {
        if ([[alllkey objectAtIndex:i] intValue] == tag - 7) {
            return YES;
        }
    }
    return NO;
}

@end
