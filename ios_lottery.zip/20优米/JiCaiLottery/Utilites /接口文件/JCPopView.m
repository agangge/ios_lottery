//
//  JCPopView.m
//  JiCaiLottery
//
//  Created by 风外杏林香 on 2017/4/18.
//  Copyright © 2017年 JiCaiLottery. All rights reserved.
//

#import "JCPopView.h"
#import "JCHeader.h"
@implementation JCPopView

- (instancetype)initWithFrame:(CGRect)frame titleLabel:(NSString *)titleText
{
    self = [super initWithFrame:frame];
    if (self) {
        self.titleLabel = [[UILabel alloc]init];
        self.titleLabel.font = [UIFont systemFontOfSize:16.f];
        self.titleLabel.textColor = [UIColor whiteColor];
        self.titleLabel.textAlignment = NSTextAlignmentCenter;
        self.titleLabel.text = [NSString stringWithFormat:@"%@", titleText];
        [self sd_addSubviews:@[self.titleLabel]];
        
        CGSize size = [self.titleLabel.text sizeWithAttributes:@{NSFontAttributeName: [UIFont systemFontOfSize:16.0f]}];
        CGSize statuseStrSize = CGSizeMake(ceilf(size.width), ceilf(size.height));
        
        JCLog(@"%@_width:%f_height:%f",NSStringFromCGSize(statuseStrSize),size.width,size.height);
        
        
        self.titleLabel.sd_layout
        .centerXIs(self.centerX)
        .centerYIs(self.centerY)
        .leftSpaceToView(self, 0)
        .widthIs(size.width)
        .heightIs(40);
        
        
        
        
    }
    return self;
}

- (void)showView
{
    
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
