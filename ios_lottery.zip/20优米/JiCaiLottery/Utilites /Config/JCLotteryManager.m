//
//  JCLotteryManager.m
//  JiCaiLottery
//
//  Created by 风外杏林香 on 2017/4/13.
//  Copyright © 2017年 JiCaiLottery. All rights reserved.
//

#import "JCLotteryManager.h"

@implementation JCLotteryManager

//组合算法。n>=m
+ (NSInteger)Comb :(NSInteger)n Count:(NSInteger)m
{
    if (n < m) {
        return 1;
    }
    return (m == 0||n == m) ? 1:[self Comb:n - 1 Count:m] + [self Comb:n - 1 Count:m - 1];
}
//排列算法。n>=m
+ (NSInteger)AComb:(NSInteger)n Count:(NSInteger)m
{
    if (n < m) {
        return 1;
    }
    NSInteger count = 1;
    for (int i = 0; i < m; i ++) {
        count *=(n - i);
    }
    return count;
}
+ (int )combSelectedArray:(NSArray *)list playIndex:(NSInteger)index{
    int Zcount = 0;
    NSArray * set1 = list[0];
    
    for (int a = 0; a<set1.count; a++) {
        int i = 0;
        NSMutableArray *temArr = [NSMutableArray array];
        [temArr addObject:set1[a]];
        NSArray *set2 = nil;
        if (list.count>1) {
            set2 = list[1];
        }else{
            Zcount++;
        }
        for (int b = 0; b<set2.count; b++) {
            if (b==0) {
                i++;
            }
            NSMutableArray *temArr2 = [temArr mutableCopy];
            if ([temArr2 containsObject:set2[b]]) {
                continue;
            }
            [temArr2 addObject:set2[b]];
            NSArray *set3= nil;
            if (list.count>2) {
                set3 = list[2];
            }else{
                Zcount++;
            }
            for (int c = 0; c<set3.count; c++) {
                if (c==0) {
                    i++;
                }
                NSMutableArray *temArr3 = [temArr2 mutableCopy];
                if ([temArr3 containsObject:set3[c]]) {
                    continue;
                }
                [temArr3 addObject:set3[c]];
                NSArray *set4= nil;
                if (list.count>3) {
                    set4 = list[3];
                }else{
                    Zcount++;
                }
                for (int d = 0; d<set4.count; d++) {
                    if (d==0) {
                        i++;
                    }
                    NSMutableArray *temArr4 = [temArr3 mutableCopy];
                    if ([temArr4 containsObject:set4[d]]) {
                        continue;
                    }
                    [temArr4 addObject:set4[d]];
                    NSArray *set5= nil;
                    if (list.count>4) {
                        set5 = list[4];
                    }else{
                        Zcount++;
                    }
                    for (int e = 0; e<set5.count; e++) {
                        if (e==0) {
                            i++;
                        }
                        NSMutableArray *temArr5 = [temArr4 mutableCopy];
                        if ([temArr5 containsObject:set5[e]]) {
                            continue;
                        }
                        [temArr5 addObject:set5[e]];
                        NSArray *set6= nil;
                        if (list.count>5) {
                            set6 = list[5];
                        }else{
                            Zcount++;
                        }
                        for (int f = 0; f<set6.count; f++) {
                            NSMutableArray *temArr6 = [temArr5 mutableCopy];
                            if ([temArr6 containsObject:set6[f]]) {
                                continue;
                            }
                            [temArr6 addObject:set6[f]];
                            
                            NSArray *set7= nil;
                            if (list.count>6) {
                                set7 = list[6];
                            }else{
                                Zcount++;
                            }
                            for (int g = 0; g<set7.count; g++) {
                                NSMutableArray *temArr7 = [temArr6 mutableCopy];
                                
                                if ([temArr7 containsObject:set7[g]]) {
                                    continue;
                                }
                                [temArr7 addObject:set7[g]];
                                
                                NSArray *set8= nil;
                                if (list.count>7) {
                                    set8 = list[7];
                                }else{
                                    Zcount++;
                                }
                                for (int k = 0; k<set8.count; k++) {
                                    
                                    NSMutableArray *temArr8 = [temArr7 mutableCopy];
                                    if ([temArr8 containsObject:set8[k]]) {
                                        continue;
                                    }
                                    [temArr8 addObject:set8[k]];
                                    NSArray *set9= nil;
                                    if (list.count>8) {
                                        set9 = list[8];
                                    }else{
                                        Zcount++;
                                    }
                                    for (int l = 0; l<set9.count; l++) {
                                        NSMutableArray *temArr9 = [temArr8 mutableCopy];
                                        if ([temArr9 containsObject:set9[l]]) {
                                            continue;
                                        }
                                        [temArr9 addObject:set9[l]];
                                        NSArray *set10= nil;
                                        if (list.count>9) {
                                            set10 = list[9];
                                        }else{
                                            Zcount++;
                                        }
                                        for (int j = 0; j<set10.count; j++) {
                                            NSMutableArray *temArr10 = [temArr9 mutableCopy];
                                            if ([temArr10 containsObject:set10[j]]) {
                                                continue;
                                            }
                                            [temArr10 addObject:set10[j]];
                                            Zcount++;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    return Zcount;
}



//组合算法 （返回数组） （n>=m）
+(NSMutableArray *)CombinationWithTotalArray:(NSMutableArray *)array chooseCount:(NSInteger)m{
    NSInteger n = [array count];
    
    if (m > n)
    {
        return nil;
    }
    
    NSMutableArray *allChooseArray = [[NSMutableArray alloc] init];
    NSMutableArray *retArray = [array copy];
    
    
    for(int i=0;i < n;i++){
        if (i < m){
            [array replaceObjectAtIndex:i withObject:@"1"];
        }else{
            [array replaceObjectAtIndex:i withObject:@"0"];
        }
    }
    
    
    
    NSMutableArray *firstArray = [[NSMutableArray alloc] init];
    
    for(int i=0; i<n; i++){
        if ([[array objectAtIndex:i] intValue] == 1){
            
            [firstArray addObject:[retArray objectAtIndex:i]];
        }
    }
    
    [allChooseArray addObject:firstArray];
    
    int count = 0;
    for(int i = 0; i < n-1; i++){
        
        if ([[array objectAtIndex:i] intValue] == 1 && [[array objectAtIndex:(i + 1)] intValue] == 0){
            [array replaceObjectAtIndex:i withObject:@"0"];
            [array replaceObjectAtIndex:(i + 1) withObject:@"1"];
            
            
            for (int k = 0; k < i; k++){
                if ([[array objectAtIndex:k] intValue] == 1){
                    count ++;
                }
            }
            
            if (count > 0){
                for (int k = 0; k < i; k++){
                    if (k < count){
                        [array replaceObjectAtIndex:k withObject:@"1"];
                    }else{
                        [array replaceObjectAtIndex:k withObject:@"0"];
                    }
                }
            }
            
            
            
            NSMutableArray *middleArray = [[NSMutableArray alloc] init];
            
            for (int k = 0; k < n; k++) {
                if ([[array objectAtIndex:k] intValue] == 1) {
                    [middleArray addObject:[retArray objectAtIndex:k]];
                }
            }
            
            
            
            [allChooseArray addObject:middleArray];
            
            i = -1;
            count = 0;
        }
    }
    
    return allChooseArray;
}


@end
