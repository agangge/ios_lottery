//
//  JCLotteryManager.h
//  JiCaiLottery
//
//  Created by 风外杏林香 on 2017/4/13.
//  Copyright © 2017年 JiCaiLottery. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface JCLotteryManager : NSObject

/**
 组合方法（）
 @param n 组合下标
 @param m 组合上标
 @return 结果值
 */
+ (NSInteger)Comb :(NSInteger)n Count :(NSInteger)m;

/**
 排列方法
 @param n 排列下标
 @param m 排列上标
 @return 结果值
 */
+ (NSInteger)AComb :(NSInteger)n Count :(NSInteger)m;

//pk10
+ (int )combSelectedArray:(NSArray *)selectArray playIndex:(NSInteger )index;





/**
 组合算法 （返回数组）
 
 @param array 总数组
 @param m 所选的个数
 @return 结果数组
 */
+(NSMutableArray *)CombinationWithTotalArray:(NSMutableArray *)array chooseCount:(NSInteger)m;


@end
