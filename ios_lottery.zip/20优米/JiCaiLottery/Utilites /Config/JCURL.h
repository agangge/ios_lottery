//
//  JCURL.h
//  JiCaiLottery
//
//  Created by 杨鑫 on 2017/4/13.
//  Copyright © 2017年 JiCaiLottery. All rights reserved.
//

#ifndef JCURL_h
#define JCURL_h

//主机域名
#define MAINJIYUNURL  @"http://client.jicai500.com/"

#endif /* JCURL_h */
