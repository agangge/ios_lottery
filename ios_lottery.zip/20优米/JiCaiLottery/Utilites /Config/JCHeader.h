//
//  JCHeader.h
//  JiCaiLottery
//
//  Created by 风外杏林香 on 2017/4/1.
//  Copyright © 2017年 风外杏林香. All rights reserved.
//

#ifndef prefix_h
#define prefix_h


#import "JCLotteryManager.h"
#import "SDAutoLayout.h"
#import "JCRequestNetWork.h"
#import "JCAllUrl.h"
#import "JSONKit.h"
#import "MJRefresh.h"
#import "MJExtension.h"
#import "MBProgressHUD.h"
#import "SDCycleScrollView.h"
#import "JCAllUrl.h"
#import "UIFont+JCFont.h"
#import "UILabel+JCLabel.h"
#import "JCPopObject.h" // 弹出提示
#import "JCTitleView.h"  //pop或presentview头部视图
#import "UIImageView+WebCache.h"
#import "JCSetTagObject.h"
#import "NSMutableArray+JCShffing.h"
#import "JCLotteryManager.h"
#import "JCKSManageSource.h"
#import "JCSelectPopView.h"
#import "JCZSTChooseVC.h"
#import "JCRemainTimeModel.h"
#import "JXTAlertManagerHeader.h"
#import "Masonry.h"
#import "YYModel.h"
//#import <MMKV/MMKV.h>
#import <YBPopupMenu/YBPopupMenu.h>
#import "JCTool.h"
#import "NSString+DecimalNumberTool.h"
#import <Masonry/Masonry.h>
#import "JCLotteryInfo.h"
#import "JCBuySuccessViewController.h"
//用户名、密码、账号、service
#define USER_NAME @"username"
#define PASS_WORD @"password"
#define USER_SESSION @"userSession"
#define USER_SERVICE @"com.PhoneNumber.LogIn"
#define UICOLOR_HEX(hexString) [UIColor colorWithRed:((float)((hexString & 0xFF0000) >> 16))/255.0 green:((float)((hexString & 0xFF00) >> 8))/255.0 blue:((float)(hexString & 0xFF))/255.0 alpha:1.0]
#define allBlueColor       [UIColor colorWithRed:0/255.0 green:160/255.0 blue:255/255.0 alpha:1]
#define allRedColor        [UIColor colorWithRed:230/255.0 green:47/255.0 blue:23/255.0 alpha:1]
#define ColorRGB(r,g,b,a)  [UIColor colorWithRed:r/255.0 green:g/255.0 blue:b/255.0 alpha:a]
#define allLineColor       [UIColor colorWithRed:230/255.0 green:230/255.0 blue:230/255.0 alpha:1]
#define allBackGroundColor [UIColor colorWithRed:245/255.0 green:245/255.0 blue:245/255.0 alpha:1]
#define allWhiteColor [UIColor colorWithRed:255/255.0 green:255/255.0 blue:255/255.0 alpha:1]

#define JCBallBoradColor [UIColor colorWithRed:210/255.0 green:210/255.0 blue:210/255.0 alpha:1]
#define JCTTTColor [UIColor colorWithRed:51/255.0 green:51/255.0 blue:51/255.0 alpha:1]
#define JCXXXColor [UIColor colorWithRed:102/255.0 green:102/255.0 blue:102/255.0 alpha:1]
#define JCNNNColor [UIColor colorWithRed:153/255.0 green:153/255.0 blue:153/255.0 alpha:1]

#define LineColor  UICOLOR_HEX(0xeeeeee)
///颜色随机
#define randomColor        [UIColor colorWithRed:arc4random()%256/255.0 green:arc4random()%256/255.0 blue:arc4random()%256/255.0 alpha:1.0]


#define LineColor  UICOLOR_HEX(0xeeeeee)
/// 获取RGBA颜色
#define RGBA(r,g,b,a)      [UIColor colorWithRed:r/255.0f green:g/255.0f blue:b/255.0f alpha:a]

/// 获取RGB颜色
#define RGB(r,g,b)         RGBA(r,g,b,1.0f)

#define FONT(size)    [UIFont systemFontOfSize:size]


#define UserDefaults [NSUserDefaults standardUserDefaults]
#define ScreenHeight [UIScreen mainScreen].bounds.size.height
#define ScreenWidth  [UIScreen mainScreen].bounds.size.width
#define SCREEN_BOUNDS [UIScreen mainScreen].bounds

#define ScreenScale  (ScreenWidth / 375)

//#define  iPhoneX (ScreenWidth == 375.f && ScreenHeight == 812.f ? YES : NO)

#define  iPhoneX (ScreenHeight == 812.0f || ScreenHeight == 896.0f)
// Status bar height.
#define  StatusBarHeight      (iPhoneX ? 44.f : 20.f)
// Navigation bar height.
#define  NavigationBarHeight  44.f
// Tabbar height.
#define  TabbarHeight         (iPhoneX ? (49.f + 34.f) : 49.f)
// Tabbar safe bottom margin.
#define  TabbarSafeBottomMargin         (iPhoneX ? 34.f : 0.f)
// Status bar & navigation bar height.
#define  StatusBarAndNavigationBarHeight  (iPhoneX ? 88.f : 64.f)


#define ScreenScale  (ScreenWidth / 375)

#define kScale  (ScreenScale>1?ScreenScale:0.9)

#define kFontScale  (ScreenScale>1?ScreenScale:0.9)

#define ViewSafeAreInsets(view) ({UIEdgeInsets insets; if(@available(iOS 11.0, *)) {insets = view.safeAreaInsets;} else {insets = UIEdgeInsetsZero;} insets;})

#define STATUSH [[UIApplication sharedApplication] statusBarFrame].size.height//状态栏高度
#define TABH APPDELEGATE.tabBarVC.tabBar.bounds.size.height//tabbar高度
#define  SCROLLERVIEW_TAG             5000

#define MAINJIYUNURL [[NSUserDefaults standardUserDefaults] objectForKey:@"mainjiyunurl"]

#define JINGCAIBIFENGURLSTRING @"http://h5.leidata.com/index.php/home/Soccerlive/showpage"

#define PgyAPPKey @"8ac9de9132b33267f8d737b2ae060777"

/*
 * dataPicker 用到的
 */
#define HEIGHT_OF_POPBOX (([UIScreen mainScreen].bounds.size.width == 414)?290:280)
#define COLOR_BACKGROUD_GRAY    [UIColor colorWithRed:238/255.0f green:238/255.0f blue:238/255.0f alpha:1]
#define HEIGHT_PICKER HEIGHT_OF_POPBOX - 160 + self.dataSource.count * 20

#define APPVERSION    @"1"
#define REQUESTTYPE   @"1" //请求类型 iOS默认为1，
#define VERSION  [[[NSBundle mainBundle] infoDictionary]objectForKey:(NSString *)kCFBundleVersionKey]


#define JCString [NSString stringWithFormat:@"%s", __FILE__].lastPathComponent
#ifdef DEBUG
#define JCLog(...) printf("%s %d行: %s\n\n",[JCString UTF8String], __LINE__, [[NSString stringWithFormat:__VA_ARGS__] UTF8String]);
#else
#define JCLog(...)
#endif


#endif /* JCHeader */

